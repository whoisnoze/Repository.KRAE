import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
import re 
import datetime
from urllib.parse import urlencode, parse_qsl, urljoin, quote
import xbmcvfs

# --- CONFIGURACIÓN BASE (Estructura Segura) ---
LIBRARIES_ZIP_URL = "https://github.com/Gunter257/repoachannels/raw/refs/heads/main/bibliotecas.zip"

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

try:
    ADDON.setSetting('addon_initialized_test', 'true')
except Exception as e:
    xbmc.log(f"[Acestream Channels] ERROR: Failed to save initial setting: {e}", xbmc.LOGERROR)

# Rutas
LIBRARIES_ZIP_PATH = os.path.join(PROFILE_PATH, 'bibliotecas.zip') 
LIBRARIES_PATH = os.path.join(PROFILE_PATH, 'lib') 

addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

addon_path = ADDON.getAddonInfo('path')
RESOURCES_PATH = os.path.join(addon_path, 'resources')
ICON_AGENDA = os.path.join(RESOURCES_PATH, 'agenda.png') 

# --- CONFIGURACIÓN VISUAL Y URLS ---
COLOR_TIME = "FF87CEEB" 
COLOR_SPORT_CATEGORY = "FF32CD32" 
COLOR_YELLOW = "FFFFFF00"
COLOR_GREEN = "FF00FF00"

AGENDA_URLS = [
    "https://ciriaco.netlify.app/",
    "https://eventos-eight-dun.vercel.app/",
    "https://uk.4everproxy.com/secure/KpUm_WoxDYiMMqOAdEZifdMMb0AJKLdAbBX9Yf65kU_CCoqpUvCnHfFaTVnwEkBz"
]

M3U_URL = "https://ipfs.io/ipns/k51qzi5uqu5di462t7j4vu4akwfhvtjhy88qbupktvoacqfqe9uforjvhyi4wr/hashes_acestream.m3u"

VPN_WARNING = "AVISO: Para el correcto funcionamiento de los enlaces es RECOMENDADO usar VPN o Cloudflare WARP.\n\nSi algún canal no carga, revisa tu conexión."

CHANGELOG = {
    "1.2.7": [
        "Añadida nueva categoría de canales deportivos (Listado M3U).",
        "Añadida la opción de 'Donación al proyecto'.",
        "Corrección de caracteres especiales en enlaces."
    ]
}

# --- 1. INSTALADOR DE LIBRERÍAS ---
def check_and_install_libraries():
    if not os.path.exists(LIBRARIES_PATH):
        xbmc.log("[Acestream Channels] INFO: Library folder not found. Starting download...", xbmc.LOGINFO)
        xbmcgui.Dialog().notification("Configurando", "Descargando componentes...", xbmcgui.NOTIFICATION_INFO)
        try:
            if not os.path.exists(PROFILE_PATH):
                os.makedirs(PROFILE_PATH)
            
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, 'r') as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            
            os.remove(LIBRARIES_ZIP_PATH)
            xbmcgui.Dialog().notification("Éxito", "Componentes instalados.", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmc.log(f"[Acestream Channels] ERROR: Failed to download libraries: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", f"Fallo instalación: {e}", xbmc.NOTIFICATION_ERROR)
            return False
    return True

# --- 2. LÓGICA DEL ADDON ---
if check_and_install_libraries():
    sys.path.insert(0, LIBRARIES_PATH)
    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError:
        xbmcgui.Dialog().ok("Reinicio necesario", "Componentes instalados.\nVuelve a abrir el addon.")
        sys.exit()

    # --- FUNCIONES ---

    def build_url(query):
        return BASE_URL + '?' + urlencode(query)

    def clean_text(text):
        if not text: return ""
        return re.sub(r'\s+', ' ', text).strip()

    def get_acestream_id(url):
        if url.startswith("acestream://"):
            return url.replace("acestream://", "")
        return url

    def check_updates():
        last_version = ADDON.getSetting('last_run_version')
        current_version = ADDON.getAddonInfo('version')
        if last_version != current_version:
            changes = CHANGELOG.get(current_version)
            if not changes: changes = CHANGELOG.get("1.3.0") 
            if changes:
                text = f"[B]Novedades v{current_version}:[/B]\n" + "\n".join(f"- {i}" for i in changes)
                xbmcgui.Dialog().ok(f"{ADDON_NAME}", text)
            ADDON.setSetting('last_run_version', current_version)

    def show_vpn_alert():
        xbmcgui.Dialog().ok("REQUISITO DE CONEXIÓN", VPN_WARNING)

    # --- FUNCIONES NUEVAS: M3U Y DONACIONES ---
    def show_donation():
        mensaje = "¿Te gusta el addon? Puedes apoyar su desarrollo invitándome a un café.\n\nEnlace: [COLOR FF00FF00][B]buymeacoffee.com/gunter257[/B][/COLOR]\n\n"
        
        mostrar_qr = xbmcgui.Dialog().yesno("Apoyar al creador", mensaje, nolabel="Cerrar", yeslabel="Mostrar QR")
        
        if mostrar_qr:
            qr_path = os.path.join(RESOURCES_PATH, 'qr.png')
            if os.path.exists(qr_path):
                xbmc.executebuiltin(f'ShowPicture("{qr_path}")')
            else:
                xbmcgui.Dialog().notification("Error", "Falta el archivo qr.png en resources", xbmcgui.NOTIFICATION_ERROR)

    def list_m3u_channels():
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        # IPFS tarda bastante, avisamos al usuario
        xbmcgui.Dialog().notification("Cargando", "Conectando al servidor (puede tardar)...", xbmcgui.NOTIFICATION_INFO, 3000)
        
        try:
            # Subimos el timeout a 30s por culpa de ipfs.io
            r = requests.get(M3U_URL, headers=headers, timeout=30)
            
            # Forzamos UTF-8 para evitar errores de lectura con caracteres raros
            r.encoding = 'utf-8' 
            
            if r.status_code != 200:
                xbmcgui.Dialog().notification("Error", f"Fallo en servidor ({r.status_code})", xbmcgui.NOTIFICATION_ERROR)
                return
            
            lines = r.text.splitlines()
            channel_name = "Canal Desconocido"
            logo_url = 'DefaultVideo.png'

            # Indicamos a Kodi que es una lista de vídeos para que la formatee bien
            xbmcplugin.setContent(addon_handle, 'videos')

            for line in lines:
                line = line.strip()
                if not line: continue
                
                if line.startswith("#EXTINF"):
                    # Parseo seguro por si alguna línea no tiene comas
                    parts = line.split(",")
                    if len(parts) > 1:
                        channel_name = parts[-1].strip()
                    else:
                        channel_name = "Canal"
                        
                    logo_match = re.search(r'tvg-logo="([^"]+)"', line)
                    if logo_match:
                        logo_url = logo_match.group(1)
                    else:
                        logo_url = 'DefaultVideo.png'
                
                elif line.startswith("http") or line.startswith("acestream://"):
                    stream_url = line
                    
                    if stream_url.startswith("acestream://"):
                        ace_id = get_acestream_id(stream_url)
                        url_item = build_url({'action': 'play_channel', 'id': ace_id})
                    else:
                        # IMPORTANTE: Eliminado el quote() que duplicaba caracteres y corrompía la URL
                        url_item = build_url({'action': 'play_direct', 'url': stream_url})
                    
                    li = xbmcgui.ListItem(label=channel_name)
                    li.setInfo('video', {'title': channel_name, 'mediatype': 'video'})
                    li.setProperty('IsPlayable', 'true')
                    li.setArt({'icon': logo_url, 'thumb': logo_url})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=False)

            xbmcplugin.endOfDirectory(addon_handle)

        except Exception as e:
            xbmc.log(f"[Acestream Channels] M3U Error: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Error", "Tiempo de espera agotado o error de red", xbmcgui.NOTIFICATION_ERROR)

    def play_direct(url):
        li = xbmcgui.ListItem()
        li.setPath(url)
        xbmcplugin.setResolvedUrl(addon_handle, True, li)

    # --- FUNCIONES DE AGENDA DEPORTIVA ---
    def fetch_html_content(target_url, index):
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        xbmcgui.Dialog().notification("Agenda", f"Probando servidor {index + 1}...", xbmcgui.NOTIFICATION_INFO, 1000)

        try:
            r = requests.get(target_url, headers=headers, timeout=10)
            if r.status_code == 200: return r.text
        except: pass
        
        try:
            r = requests.get(f"https://api.allorigins.win/get?url={quote(target_url)}", headers=headers, timeout=10)
            if r.status_code == 200 and 'contents' in r.json(): return r.json()['contents']
        except: pass

        try:
            r = requests.get(f"https://corsproxy.io/?{quote(target_url)}", headers=headers, timeout=10)
            if r.status_code == 200: return r.text
        except: pass

        return None

    def list_agenda_events():
        events_found = False
        
        for i, url in enumerate(AGENDA_URLS):
            html_content = fetch_html_content(url, i)
            if not html_content: continue

            try:
                soup = BeautifulSoup(html_content, 'html.parser')
                today_str = datetime.datetime.now().strftime("%d/%m/%Y")
                table = None
                
                fechas = soup.find_all('h2', class_='fecha')
                if fechas:
                    for h2 in fechas:
                        if today_str in h2.get_text():
                            table = h2.find_next_sibling('table')
                            break
                    if not table:
                        table = soup.find('table')
                else:
                    table = soup.find('table')

                if not table: continue
                
                rows = table.find_all('tr')
                items_count = 0

                for row in rows:
                    cols = row.find_all('td')
                    
                    if not cols or len(cols) < 5: continue 

                    if len(cols) == 5:
                        time = clean_text(cols[0].get_text())
                        sport = clean_text(cols[1].get_text())
                        competition = clean_text(cols[2].get_text())
                        event_name = clean_text(cols[3].get_text())
                        links_col = cols[4]
                    else:
                        time = clean_text(cols[1].get_text())
                        sport = clean_text(cols[2].get_text())
                        competition = clean_text(cols[3].get_text())
                        event_name = clean_text(cols[4].get_text())
                        links_col = cols[5]

                    title_display = f"[COLOR {COLOR_TIME}][{time}][/COLOR] [COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] {event_name} [I]({competition})[/I]"
                    
                    links = []
                    for link in links_col.find_all('a'):
                        href = link.get('href', '')
                        if 'acestream://' in href:
                            ace_id = get_acestream_id(href)
                            name = clean_text(link.get_text()).replace('▶', '').strip()
                            links.append({'name': name, 'id': ace_id})

                    if not links: continue
                    items_count += 1

                    if len(links) == 1:
                        ace_id = links[0]['id']
                        url_item = build_url({'action': 'play_channel', 'id': ace_id})
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': event_name, 'mediatype': 'video', 'plot': competition})
                        li.setProperty('IsPlayable', 'true')
                        li.setArt({'icon': 'DefaultVideo.png'}) 
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=False)
                    else:
                        links_json = json.dumps(links)
                        url_item = build_url({'action': 'list_event_links', 'links': links_json, 'title': event_name})
                        title_display += f" [COLOR {COLOR_YELLOW}]({len(links)} Canales)[/COLOR]"
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': event_name, 'plot': f"Competición: {competition}\nOpciones: {len(links)}"})
                        li.setArt({'icon': 'DefaultFolder.png'})
                        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_item, listitem=li, isFolder=True)
                
                if items_count > 0:
                    events_found = True
                    break 
                    
            except Exception as e:
                xbmc.log(f"[Acestream Channels] Parse Error: {e}", xbmc.LOGERROR)
                continue
        
        if events_found:
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcgui.Dialog().ok("ERROR DE CONEXIÓN", "No se ha podido cargar la agenda.\n\nEs probable que tu operador bloquee la web.\nPor favor, activa tu VPN o WARP e inténtalo de nuevo.")

    def list_event_links(links_json, event_title):
        try:
            links = json.loads(links_json)
            xbmcplugin.setContent(addon_handle, 'videos')
            for link in links:
                name = link['name']
                ace_id = link['id']
                display_name = f"[COLOR {COLOR_GREEN}]Ver en:[/COLOR] {name}"
                url = build_url({'action': 'play_channel', 'id': ace_id})
                li = xbmcgui.ListItem(label=display_name)
                li.setInfo('video', {'title': event_title, 'mediatype': 'video'})
                li.setProperty('IsPlayable', 'true')
                li.setArt({'icon': 'DefaultVideo.png'})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(addon_handle)
        except Exception as e:
            xbmc.log(f"[Acestream Channels] Error links: {e}", xbmc.LOGERROR)

    def play_channel(url_id):
        try:
            use_external = ADDON.getSetting('use_external_player') == 'true'
            if use_external:
                strm_content = f"http://127.0.0.1:6878/ace/getstream?id={url_id}"
                strm_path = os.path.join(PROFILE_PATH, 'temp_acestream.strm')
                with open(strm_path, 'w') as f: f.write(strm_content)
                xbmc.Player().play(strm_path)
            else:
                horus_url = f"plugin://script.module.horus/?action=play&id={url_id}"
                li = xbmcgui.ListItem()
                li.setPath(horus_url)
                xbmcplugin.setResolvedUrl(addon_handle, True, li)
        except Exception as e:
            xbmcgui.Dialog().notification("Error", f"Fallo al reproducir: {e}", xbmc.NOTIFICATION_ERROR)

    # --- ROUTER PRINCIPAL ---
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")
    
    if action is None:
        check_updates()
        show_vpn_alert()
        
        # 1. AGENDA DEPORTIVA
        url_agenda = build_url({'action': 'list_channels', 'category': 'AGENDA'})
        li_agenda = xbmcgui.ListItem(label="[B]AGENDA DEPORTIVA[/B]")
        li_agenda.setArt({'icon': ICON_AGENDA})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_agenda, listitem=li_agenda, isFolder=True)

        # 2. CANALES TV
        url_m3u = build_url({'action': 'list_m3u'})
        li_m3u = xbmcgui.ListItem(label="[B]CANALES DEPORTIVOS[/B]")
        li_m3u.setArt({'icon': 'DefaultMovies.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_m3u, listitem=li_m3u, isFolder=True)

        # 3. DONACIONES
        url_donar = build_url({'action': 'donacion'})
        li_donar = xbmcgui.ListItem(label=f"[COLOR {COLOR_GREEN}][B]APOYAR AL PROYECTO[/B][/COLOR]")
        li_donar.setArt({'icon': 'DefaultAddonProgram.png'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_donar, listitem=li_donar, isFolder=False)

        xbmcplugin.endOfDirectory(addon_handle)

    elif action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()

    elif action == "list_event_links":
        list_event_links(args.get("links"), args.get("title"))

    elif action == "play_channel":
        play_channel(args.get("id"))
        
    elif action == "list_m3u":
        list_m3u_channels()
        
    elif action == "donacion":
        show_donation()
        
    elif action == "play_direct":
        play_direct(args.get("url"))

else:
    sys.exit()