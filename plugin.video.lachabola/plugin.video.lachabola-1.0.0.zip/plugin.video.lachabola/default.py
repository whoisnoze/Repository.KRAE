import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.request
import re
import json
from urllib.parse import urlencode, parse_qsl

# --- CONFIGURACIÓN ---
# La URL raw asegura que siempre leamos el archivo de texto más reciente
M3U_URL = "https://raw.githubusercontent.com/whoisnoze/acesm3u/main/lista.m3u"

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def get_m3u_content(url):
    """Descarga el M3U de GitHub sin usar caché"""
    try:
        # Añadimos un parámetro aleatorio al final de la URL para saltar posibles cachés de servidores intermedios
        import time
        url_fresca = f"{url}?t={int(time.time())}"
        
        req = urllib.request.Request(url_fresca, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=15)
        return response.read().decode('utf-8')
    except Exception as e:
        xbmc.log(f"Error cargando M3U: {str(e)}", xbmc.LOGERROR)
        return None

def parse_m3u_grouped():
    """Analiza el M3U y agrupa por eventos"""
    data = get_m3u_content(M3U_URL)
    if not data:
        return {}

    grupos = {}
    lines = data.splitlines()
    
    current_event = ""
    current_option = ""
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"): continue
        
        if line.startswith("#EXTINF"):
            full_name = line.split(",")[-1].strip()
            
            # Buscamos el formato "Nombre (Opcion)"
            match = re.search(r"^(.*?)\s*\((.*)\)$", full_name)
            if match:
                current_event = match.group(1).strip()
                current_option = match.group(2).strip()
            else:
                current_event = full_name
                current_option = "Enlace Principal"
        
        elif "acestream://" in line:
            ace_id = line.replace("acestream://", "").strip()
            if current_event not in grupos:
                grupos[current_event] = []
            
            grupos[current_event].append({
                'label': current_option,
                'id': ace_id
            })

    return grupos

def list_main_menu():
    """Menú principal: Lee el M3U cada vez que se abre"""
    xbmcplugin.setContent(ADDON_HANDLE, 'folders')
    
    # Notificación visual opcional para saber que está actualizando
    # xbmcgui.Dialog().notification("Addon", "Actualizando lista desde GitHub...", xbmcgui.NOTIFICATION_INFO, 1000)
    
    canales = parse_m3u_grouped()
    
    if not canales:
        xbmcgui.Dialog().ok("Error", "No se encontraron canales en el M3U remoto.")
        return

    for nombre_canal, enlaces in canales.items():
        url = build_url({
            'action': 'list_options', 
            'links': json.dumps(enlaces),
            'title': nombre_canal
        })
        
        li = xbmcgui.ListItem(label=f"[B]{nombre_canal}[/B]")
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'title': nombre_canal, 'plot': f"Opciones disponibles: {len(enlaces)}"})
        
        # cacheToDisc=False asegura que Kodi no guarde esta lista en el disco
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def list_options(links_json, title):
    """Lista las opciones dentro de un evento"""
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    enlaces = json.loads(links_json)
    
    for enlace in enlaces:
        url = build_url({'action': 'play', 'id': enlace['id']})
        
        label = f"[COLOR yellow]▶[/COLOR] {title} ({enlace['label']})"
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        li.setArt({'icon': 'DefaultVideo.png'})
        
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def play_with_horus(ace_id):
    """Ejecuta Horus"""
    horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
    li = xbmcgui.ListItem(path=horus_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

# --- ROUTER ---
args = dict(parse_qsl(sys.argv[2][1:]))
action = args.get("action")

if action is None:
    list_main_menu()
elif action == "list_options":
    list_options(args.get('links'), args.get('title'))
elif action == "play":
    play_with_horus(args.get('id'))