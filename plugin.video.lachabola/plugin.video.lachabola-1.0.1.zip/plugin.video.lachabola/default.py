import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import urllib.request
import re
import json
import time
from urllib.parse import urlencode, parse_qsl

# --- CONFIGURACIÓN ---
M3U_URL = "https://raw.githubusercontent.com/whoisnoze/acesm3u/main/lista.m3u"

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def get_m3u_content(url):
    try:
        url_fresca = f"{url}?t={int(time.time())}"
        req = urllib.request.Request(url_fresca, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req, timeout=15)
        return response.read().decode('utf-8')
    except Exception as e:
        xbmc.log(f"Error cargando M3U: {str(e)}", xbmc.LOGERROR)
        return None

def parse_m3u_grouped():
    data = get_m3u_content(M3U_URL)
    if not data: return {}
    grupos = {}
    lines = data.splitlines()
    current_event = ""
    current_option = ""
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"): continue
        if line.startswith("#EXTINF"):
            full_name = line.split(",")[-1].strip()
            match = re.search(r"^(.*?)\s*\((.*)\)$", full_name)
            if match:
                current_event = match.group(1).strip()
                current_option = match.group(2).strip()
            else:
                current_event = full_name
                current_option = "Enlace Principal"
        elif "acestream://" in line:
            ace_id = line.replace("acestream://", "").strip()
            if current_event not in grupos: grupos[current_event] = []
            grupos[current_event].append({'label': current_option, 'id': ace_id})
    return grupos

def list_main_menu():
    # IMPORTANTE: Declarar el contenido antes de empezar
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "La Chabola - Categorías")
    
    canales = parse_m3u_grouped()
    
    if not canales:
        xbmcgui.Dialog().ok("Error", "No se encontraron canales.")
        return

    for nombre_canal, enlaces in canales.items():
        url = build_url({
            'action': 'list_options', 
            'links': json.dumps(enlaces),
            'title': nombre_canal
        })
        
        # offscreen=True ayuda a la compatibilidad con Skins modernas
        li = xbmcgui.ListItem(label=f"[B]{nombre_canal}[/B]", offscreen=True)
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
        li.setInfo('video', {'title': nombre_canal, 'plot': f"Opciones: {len(enlaces)}", 'mediatype': 'video'})
        
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def list_options(links_json, title):
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    xbmcplugin.setPluginCategory(ADDON_HANDLE, title)
    
    enlaces = json.loads(links_json)
    
    for enlace in enlaces:
        url = build_url({'action': 'play', 'id': enlace['id']})
        label = f"[COLOR yellow]▶[/COLOR] {title} ({enlace['label']})"
        
        li = xbmcgui.ListItem(label=label, offscreen=True)
        # Añadir mediatype 'video' es CRUCIAL para que las skins lo muestren
        li.setInfo('video', {'title': label, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        li.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
        
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def play_with_horus(ace_id):
    horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
    li = xbmcgui.ListItem(path=horus_url)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

# --- ROUTER ---
args = dict(parse_qsl(sys.argv[2][1:]))
action = args.get("action")

if action is None:
    list_main_menu()
elif action == "list_options":
    list_options(args.get('links'), args.get('title'))
elif action == "play":
    play_with_horus(args.get('id'))