# -*- coding: utf-8 -*-
import os
import json
import xbmcaddon
import xbmcvfs

# =============================================================================
# GLOBAL SETTINGS MANAGER
# Centralizes configuration for: Context, Debug, Frozen Mode, etc.
# =============================================================================

# Paths
_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
if not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH)

_CONTEXT_FILE = os.path.join(_PROFILE_PATH, "full_context.json")
_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_FROZEN_FILE = os.path.join(_PROFILE_PATH, 'frozen_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_SNAPSHOT_CTX_FILE = os.path.join(_PROFILE_PATH, 'snapshot_context.json')
_PALANTIR_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'palantir_integration_state.json') # NEW FILE

# --- CONTEXT LEVEL (0, 1, 2, 3) ---
def get_context_level():
    if not os.path.exists(_CONTEXT_FILE): return 1 # Default Level 1
    try:
        with open(_CONTEXT_FILE, 'r') as f:
            data = json.load(f)
            val = data.get("level", 1) # Default Level 1
            # Compatibility with old boolean format
            if isinstance(val, bool): return 1 if val else 0
            return int(val)
    except: return 1 # Default Level 1

def cycle_context_level():
    """Cycles level 0 -> 1 -> 2 -> 3 -> 0 and saves it. Returns new level."""
    current = get_context_level()
    new_level = (current + 1) % 4
    try:
        with open(_CONTEXT_FILE, 'w') as f: json.dump({"level": new_level}, f)
        return new_level
    except:
        return current

# --- SNAPSHOT CONTEXT LEVEL (-1, 0, 1, 2, 3) ---
# -1: Classic (Hardcoded defaults)
# 0-3: Standard Context Levels
def get_snapshot_context_level():
    if not os.path.exists(_SNAPSHOT_CTX_FILE): return -1 # Default: Classic
    try:
        with open(_SNAPSHOT_CTX_FILE, 'r') as f:
            return int(json.load(f).get("level", -1))
    except: return -1

def cycle_snapshot_context():
    """Cycles -1 -> 0 -> 1 -> 2 -> -1"""
    curr = get_snapshot_context_level()
    new_val = curr + 1
    if new_val > 2: new_val = -1
    
    with open(_SNAPSHOT_CTX_FILE, 'w') as f: json.dump({"level": new_val}, f)
    return new_val

def build_query(title, context_data, force_level=None):
    """
    Applies context to a title based on the current level setting.
    context_data can be:
      - A simple string (e.g. "Show Name")
      - A path string separated by '||' (e.g. "Grandparent||Parent")
      
    force_level: If set, uses this level instead of global setting.
    """
    depth = get_context_level() if force_level is None else force_level
    
    if depth == 0: return title.strip()
    if not context_data: return title.strip()

    clean_title = title.strip()
    
    # Calculate Context String
    if "||" in context_data:
        parts = context_data.split("||")
        # Take up to 'depth' items from the end
        if depth > len(parts): depth = len(parts) 
        used = parts[-depth:]
        ctx_str = " ".join(used)
    else:
        # Simple context (treat as Level 1)
        ctx_str = context_data

    # Avoid duplication
    if ctx_str.lower() not in clean_title.lower():
        # Clean potential double spaces
        return f"{ctx_str} {clean_title}".strip()
    
    return clean_title


# --- DEBUG MODE ---
def is_debug_active():
    if not os.path.exists(_DEBUG_FILE): return False
    try:
        with open(_DEBUG_FILE, 'r') as o: return json.load(o).get('active', False)
    except: return False

def set_debug_active(state):
    with open(_DEBUG_FILE, 'w') as o: json.dump({'active': state}, o)


# --- FROZEN (STATIC) MODE ---
def is_frozen_active():
    if not os.path.exists(_FROZEN_FILE): return False
    try:
        with open(_FROZEN_FILE, 'r') as o: return json.load(o).get('active', False)
    except: return False

# --- PRIORITY MODE (Match vs Duration) ---
_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')

def is_prioritize_match_active():
    if not os.path.exists(_PRIORITY_FILE): return False
    try:
        with open(_PRIORITY_FILE, 'r') as o: return json.load(o).get('active', False)
    except: return False

def set_prioritize_match(state):
    with open(_PRIORITY_FILE, 'w') as o: json.dump({'active': state}, o)


# --- RECENT FILTER ---
def is_recent_active():
    if not os.path.exists(_RECENT_FILE): return False
    try:
        with open(_RECENT_FILE, 'r') as o: return json.load(o).get('active', False)
    except: return False

def set_recent_active(state):
    with open(_RECENT_FILE, 'w') as o: json.dump({'active': state}, o)


# --- FAVORITES ---
def get_favorites():
    if not os.path.exists(_FAV_FILE): return []
    try:
        with open(_FAV_FILE, 'r') as f: return json.load(f)
    except: return []

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()
    # Avoid duplicates
    if any(f['url'] == url for f in favs): return False
    favs.append({
        "title": title, "url": url, "icon": icon, 
        "platform": platform, "action": action, "params": params or {}
    })
    with open(_FAV_FILE, 'w') as f: json.dump(favs, f)
    return True

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    with open(_FAV_FILE, 'w') as f: json.dump(new_favs, f)
    return len(favs) != len(new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    changed = False
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            changed = True
            break
    if changed:
        with open(_FAV_FILE, 'w') as f: json.dump(favs, f)
    return changed

def move_favorite(url, direction):
    favs = get_favorites()
    index = -1
    for i, f in enumerate(favs):
        if f['url'] == url:
            index = i
            break
            
    if index == -1: return False
    
    if direction == "up" and index > 0:
        favs[index], favs[index-1] = favs[index-1], favs[index]
        with open(_FAV_FILE, 'w') as f: json.dump(favs, f)
        return True
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index+1] = favs[index+1], favs[index]
        with open(_FAV_FILE, 'w') as f: json.dump(favs, f)
        return True
        
    return False


# --- DOWNLOADS HISTORY ---
def get_downloads():
    if not os.path.exists(_DL_FILE): return []
    try:
        with open(_DL_FILE, 'r') as f: return json.load(f)
    except: return []

def log_download(title, path, vid):
    dls = get_downloads()
    # Check if exists and update or add
    entry = {"title": title, "path": path, "vid": vid, "date": xbmcaddon.Addon().getLocalizedString(32000)} # Placeholder for real date if needed
    import time
    entry["date"] = time.strftime("%d/%m/%Y %H:%M")
    dls.insert(0, entry) # Most recent first
    dls = dls[:50] # Keep last 50
    with open(_DL_FILE, 'w') as f: json.dump(dls, f)

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    with open(_DL_FILE, 'w') as f: json.dump(new_dls, f)

# --- DURATION FILTER ---
def get_min_duration():
    if not os.path.exists(_DURATION_FILE): return 0
    try:
        with open(_DURATION_FILE, 'r') as f: return json.load(f).get('minutes', 0)
    except: return 0

def set_min_duration(minutes):
    with open(_DURATION_FILE, 'w') as f: json.dump({'minutes': minutes}, f)

# --- ADVANCED SEARCH MODE ---
def is_advanced_search_active():
    if not os.path.exists(_ADVANCED_SEARCH_FILE): return False
    try:
        with open(_ADVANCED_SEARCH_FILE, 'r') as o: return json.load(o).get('active', False)
    except: return False

def set_advanced_search_active(state):
    with open(_ADVANCED_SEARCH_FILE, 'w') as o: json.dump({'active': state}, o)

# --- PALANTIR SEARCH INTEGRATION ---
_PALANTIR_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'palantir_search_state.json')

def is_palantir_search_active():
    if not os.path.exists(_PALANTIR_SEARCH_FILE): return False
    try:
        with open(_PALANTIR_SEARCH_FILE, 'r') as o: return json.load(o).get('active', False)
    except: return False

def set_palantir_search_active(state):
    with open(_PALANTIR_SEARCH_FILE, 'w') as o: json.dump({'active': state}, o)

# --- PALANTIR GLOBAL INTEGRATION TOGGLE ---
def is_palantir_integration_enabled():
    """If True, shows options to search in Palantir 3 generally. Default: True"""
    if not os.path.exists(_PALANTIR_INTEGRATION_FILE): return True
    try:
        with open(_PALANTIR_INTEGRATION_FILE, 'r') as o: return json.load(o).get('active', True)
    except: return True

def set_palantir_integration_enabled(state):
    with open(_PALANTIR_INTEGRATION_FILE, 'w') as o: json.dump({'active': state}, o)
