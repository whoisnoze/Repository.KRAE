# -*- coding: utf-8 -*-
"""
Filosofía
Este proyecto nace con la intención de facilitar el acceso a la cultura audiovisual y no de sustituir a los servicios oficiales. Cabe destacar que la gran mayoría de los enlaces encontrados por esta herramienta apuntan a contenidos de baja resolución (frecuentemente inferiores a 720p), lo que dista mucho de la experiencia premium que ofrecen las plataformas de pago.

Publicidad y Marketing Orgánico
Paradójicamente, este tipo de acceso actúa a menudo como una puerta de entrada y una potente herramienta de publicidad gratuita. Ver un episodio suelto o un programa a través de estas vías puede llevar al usuario a comentarlo y compartirlo en redes sociales, generando un ruido digital y un marketing orgánico para la cadena original que, de otro modo, no existiría. Muchos usuarios descubren contenido aquí y, al engancharse, buscan una experiencia superior y mayor comodidad, terminando por migrar a servicios de suscripción oficiales.

Accesibilidad y Realidad Económica
Quienes deciden permanecer consumiendo en baja calidad suelen hacerlo por barreras económicas, no por elección; esto significa que rara vez representan una pérdida real de clientes comerciales. Restringir este acceso no convierte a estos usuarios en suscriptores, sino que simplemente amplía la brecha cultural y limita el acceso a la información.

Cuando la oferta oficial es sencilla, asequible y de calidad, el usuario tiende a elegirla naturalmente por encima de cualquier otra opción.

Preservación Histórica
Finalmente, la presencia de estos archivos en la red cumple una función involuntaria de preservación histórica. Actúa como una "cápsula del tiempo" para contenido antiguo, descatalogado o de nicho que ya ha desaparecido de los catálogos comerciales, asegurando que estas obras no se pierdan para siempre en el olvido digital.

Addon desarrollado por fullstackcurso - RSDFA1labernt
"""
import sys

import os
import time
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import xbmcvfs
import json
import difflib
import base64
import zipfile
import re
import core_settings
import category_manager
import exploration_history
import estuary_palantir_compatibility
try:
    estuary_palantir_compatibility.patch_palantir_skin()
except Exception as e:
    xbmc.log(f"EspaDaily: Error applying Palantir skin patch: {str(e)}", xbmc.LOGWARNING)
try:
    import rtve_extended
except ImportError:
    rtve_extended = None
    xbmc.log("EspaDaily: rtve_extended module not found or failed to import", xbmc.LOGWARNING) # Keep lightweight log for optional modules

try:
    import mediaset_extended
except ImportError:
    mediaset_extended = None
    xbmc.log("EspaDaily: mediaset_extended module not found or failed to import", xbmc.LOGWARNING)

try:
    import requests
except ImportError:
    _log_error("[EspaDaily] Failed to import requests module")
    sys.exit(1)

# Encoded configuration
def _d(s): return base64.b64decode(s).decode('utf-8')
_c = lambda x: ''.join([chr(ord(c) ^ 0x1F) for c in x])

_E0 = _d("aHR0cHM6Ly9hcGkuYXRyZXNwbGF5ZXIuY29t")
_E1 = _d("NWE2YjMyNjY3ZWQxYTgzNDQ5M2VjMDNi")
_E2 = {"a": _d("NWE2YTFiMjI5ODZiMjgxZDE4YTUxMmI4"), "b": _d("NWE2YTFiYTA5ODZiMjgxZDE4YTUxMmI5"), 
       "c": _d("NWIwNjdiZjM5ODZiMjhiMGEyN2MyZjQy"), "d": _d("NWE2YTI0YjE5ODZiMjgxZDE4YTUxMmMw"),
       "e": _d("NWE2YTIxNWU5ODZiMjgxZDE4YTUxMmJj"), "f": _d("NWI1ZjJmNzc3ZWQxYTg2ODYwMTAyMTQ0")}
_E3 = _d("aHR0cHM6Ly9hcGkuZGFpbHltb3Rpb24uY29tL3ZpZGVvcw==")
_E4 = _d("aHR0cHM6Ly93d3cuZGFpbHltb3Rpb24uY29tL3BsYXllci9tZXRhZGF0YS92aWRlby8=")

# URL del archivo de estado en GitHub (CAMBIAR ESTO POR LA URL REAL RAW)
# El formato del JSON debe ser: {"allowed": true} o {"allowed": false}
_STATUS_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/status.json" 

# URL del archivo de mensajes (Avisos/Novedades)
_MESSAGES_URL = "https://raw.githubusercontent.com/fullstackcurso/espadaily/main/messages.json"

_H = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Origin": _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29t"),
    "Referer": _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29tLw==")
}

def _l(m): xbmc.log(f"[EspaDaily] {m}", xbmc.LOGINFO)
def _u(**k): return sys.argv[0] + "?" + urllib.parse.urlencode(k)

def _fix_img(t):
    if not t: return ""
    if t.startswith("//"): t = "https:" + t
    elif t.startswith("/"): t = _d("aHR0cHM6Ly93d3cuYXRyZXNwbGF5ZXIuY29t") + t
    if t.endswith("/"): t += "1280x720.jpg"
    return t

def _get_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'search_history.json')

def _load_history():
    f = _get_history_file()
    if not os.path.exists(f): return []
    try:
        with open(f, 'r', encoding='utf-8') as o: return json.load(o)
    except Exception as e:
        _log_error(f"Error loading history: {str(e)}")
        return []

def _add_to_history(q):
    q = q.strip()
    if not q: return
    h = _load_history()
    if q in h: h.remove(q)
    h.insert(0, q)
    h = h[:50]
    with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)

def _show_history():
    h = _load_history()
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    palantir_active = core_settings.is_palantir_search_active()
    
    # BOTÓN CONFIGURACIÓN PALANTIR
    p_status = "[COLOR green]ACTIVADO[/COLOR]" if palantir_active else "[COLOR gray]DESACTIVADO[/COLOR]"
    li = xbmcgui.ListItem(label=f"Búsqueda en Palantir: {p_status}")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Si se activa, al pulsar en un elemento del historial se buscará automáticamente en el addon Palantir 3.\n\nPulsa para cambiar."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_palantir_search"), listitem=li, isFolder=False)

    # BOTÓN CATEGORÍAS SIEMPRE VISIBLE
    li = xbmcgui.ListItem(label="[COLOR yellow][B][Categorías / Carpetas][/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li, isFolder=True)
    
    # BOTÓN HISTORIAL DE EXPLORACIÓN
    li = xbmcgui.ListItem(label="[COLOR cyan][Historial de Exploración][/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Muestra las últimas 50 rutas de navegación que llegaron a mostrar resultados en la red.\n\nPuedes editar palabras clave o añadirlas al historial de búsquedas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="exp_menu"), listitem=li, isFolder=True)
    
    if not h:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial reciente[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for q in h:
            li = xbmcgui.ListItem(label=q)
            li.setArt({'thumb': icon, 'icon': 'DefaultFolder.png'})
            try:
                cm = [
                    ("Editar y buscar", f"RunPlugin({_u(action='edit_and_search', q=q, ot=icon)})"),
                    ("Añadir a Categoría...", f"RunPlugin({_u(action='cat_add_item_dialog', q=q)})"),
                    ("Eliminar de este historial", f"RunPlugin({sys.argv[0]}?action=remove_history_item&q={urllib.parse.quote(q)})")
                ]
                
                # Add to Favorites
                fav_params = json.dumps({'q': q, 'ot': icon})
                cm.append(("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=q, fav_url=f'lfr_{q}', icon=icon, platform='search', fav_action='lfr', params=fav_params)})"))
                
                # Siempre añadir opción manual de Palantir en el menú contextual SI está habilitado
                if core_settings.is_palantir_integration_enabled():
                    cm.append(("Buscar en Palantir", f"RunPlugin({_u(action='palantir_search', q=q)})"))
                li.addContextMenuItems(cm)
            except Exception as e:
                _log_error(f"Error adding CM to history item: {str(e)}")
            
            # URL de acción: normal o Palantir según ajuste
            if palantir_active:
                target_url = _u(action="palantir_search", q=q)
            else:
                target_url = _u(action="lfr", q=q, ot=icon, nh=1)
                
            is_folder = not palantir_active
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=target_url, listitem=li, isFolder=is_folder)
        
        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: Puedes borrar elementos individuales con clic derecho[/I][/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: En esta lista solo se guardan 50 elementos[/I][/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR red]Borrar Historial...[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_history"), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clear_history():
    h = _load_history()
    if not h: return
    
    opts = ["Borrar TODO el historial", "Elegir elementos a borrar", "[COLOR red]Cancelar[/COLOR]"]
    sel = xbmcgui.Dialog().select("Limpiar Historial de Búsquedas", opts)
    
    if sel == 0:
        if xbmcgui.Dialog().yesno("Confirmar", "¿Estás seguro de que quieres vaciar TODO el historial?"):
            with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump([], o)
            xbmcgui.Dialog().notification("EspaDaily", "Historial vaciado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif sel == 1:
        chosen = xbmcgui.Dialog().multiselect("Marca las búsquedas a eliminar", h)
        if chosen:
            new_h = [item for i, item in enumerate(h) if i not in chosen]
            with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(new_h, o)
            xbmc.executebuiltin("Container.Refresh")

def _remove_history_item(q):
    h = _load_history()
    if q in h:
        h.remove(q)
        with open(_get_history_file(), 'w', encoding='utf-8') as o: json.dump(h, o)
        # We don't necessarily need a notification for single skip but...
        xbmc.executebuiltin("Container.Refresh")

def atresplayer_menu():
    cats = [
        {"title": "Series", "id": _E2["a"], "icon": "DefaultTVShows.png"},
        {"title": "Programas", "id": _E2["b"], "icon": "DefaultFolder.png"},
        {"title": "Documentales", "id": _E2["c"], "icon": "DefaultMovies.png"},
        {"title": "Infantil", "id": _E2["d"], "icon": "DefaultFolder.png"},
        {"title": "Actualidad", "id": _E2["e"], "icon": "DefaultIconInfo.png"},
    ]

    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': c.get("icon", 'DefaultFolder.png')})
        # FAVORITOS (Sección)
        _add_fav_cm(li, f"Atresplayer: {c['title']}", "atresplayer", "ls", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls", cid=c["id"]), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def rtve_menu():
    cats = [
        {"title": "Series", "id": "864", "icon": "DefaultTVShows.png"},
        {"title": "Cine", "id": "866", "icon": "DefaultMovies.png"},
        {"title": "Documentales", "id": "863", "icon": "DefaultMovies.png"},
        {"title": "Programas", "id": "102610", "icon": "DefaultFolder.png"},
        {"title": "Deportes", "id": "867", "icon": "DefaultIconInfo.png"},
        {"title": "Informativos", "id": "862", "icon": "DefaultIconInfo.png"},
        {"title": "Infantil (Clan)", "id": "865", "icon": "DefaultFolder.png"},
        {"title": "Archivo RTVE", "id": "102611", "icon": "DefaultAddonRepository.png"},
    ]

    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': c.get("icon", 'DefaultFolder.png')})
        # FAVORITOS (Sección)
        _add_fav_cm(li, f"RTVE: {c['title']}", "rtve", "ls_rtve", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_rtve", cid=c["id"]), listitem=li, isFolder=True)

    # Extra
    li = xbmcgui.ListItem(label="[COLOR yellow]Explorar Todo (Extra)[/COLOR]")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="rtve_ext_router", rtve_action="main_list"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls_rtve(cid):
    # HYBRID CACHE LOGIC
    if _is_frozen_active():
        d = _load_cache(f"rtve_{cid}")
        if d: 
            _process_rtve_items(d)
            return

    u = f"https://api.rtve.es/api/tematicas/{cid}/programas.json"
    try:
        r = requests.get(u, params={"size": 50}, timeout=10)
        r.raise_for_status(); d = r.json()
        r.raise_for_status(); d = r.json()
    except Exception as e:
        _log_error(f"Error RTVE API: {str(e)}")
        xbmcgui.Dialog().ok("Error RTVE", f"No se pudo conectar: {str(e)}")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    items = d.get("page", {}).get("items", [])
    
    # CACHE SAVE LOGIC
    # Mode 1 (Recording) or Mode 2 (Hybrid) -> Save
    if _get_cache_mode() > 0:
        _save_cache(f"rtve_{cid}", items)

    _process_rtve_items(items)

def _process_rtve_items(items):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon')
    for i in items:
        tt = i.get("title", "Sin título"); th = i.get("imagen", ai); pid = i.get("id")
        li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th})
        
        # FAVORITOS
        _add_fav_cm(li, tt, "rtve", "fs_rtve", {"pid": pid, "st": tt, "sth": th})
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs_rtve", pid=pid, st=tt, sth=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _fs_rtve(pid, st, sth):
    u = f"https://api.rtve.es/api/programas/{pid}/videos.json"
    try:
        r = requests.get(u, params={"size": 50}, timeout=10)
        r.raise_for_status(); d = r.json()
        r.raise_for_status(); d = r.json()
    except Exception as e: 
        _log_error(f"Error fetching RTVE videos for pid {pid}: {str(e)}")
        _fb(st, sth); return
    items = d.get("page", {}).get("items", [])
    if not items: _fb(st, sth); return
    for i in items:
        tt = i.get("title", "Video"); th = i.get("imagen", sth)
        li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th})
        # Apply global context to RTVE Classic
        # We manually add RTVE prefix because _bi handles the show title vs episode title
        sq = f"RTVE {_bi(st, tt)}"
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


# =================================================================================================
# MEDIASET INFINITY INTEGRATION
# =================================================================================================

def mediaset_menu():
    cats = [
        {"title": "Programas TV", "id": "programas-tv", "icon": "DefaultFolder.png"},
        {"title": "Series", "id": "series-online", "icon": "DefaultTVShows.png"},
        {"title": "Miniseries", "id": "miniseries", "icon": "DefaultTVShows.png"},
        {"title": "Cine", "id": "peliculas", "icon": "DefaultMovies.png"},
        {"title": "Documentales", "id": "documentales", "icon": "DefaultMovies.png"},
        {"title": "Música", "id": "musica", "icon": "DefaultAudio.png"},
        {"title": "Deportes", "id": "deportes", "icon": "DefaultFolder.png"},
    ]

    for c in cats:
        li = xbmcgui.ListItem(label=c["title"])
        li.setArt({'icon': c.get("icon", 'DefaultFolder.png')})
        # FAVORITOS (Sección)
        _add_fav_cm(li, f"Mediaset: {c['title']}", "mediaset", "ls_mediaset", {"cid": c["id"]})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="ls_mediaset", cid=c["id"]), listitem=li, isFolder=True)

    # EXTRA: Explorar Todo
    if mediaset_extended:
        li = xbmcgui.ListItem(label="Explorar Todo [COLOR yellow](MENU EXTENDIDO)[/COLOR]")
        li.setArt({'icon': 'DefaultFolder.png'})
        li.setInfo('video', {'plot': "Navega por la estructura completa de Mediaset Infinity (Programas, Series, Informativos, etc.)\nutilizando la API extendida.\n\nContenido extraído directamente de servidores oficiales."})
        # We route this to 'mediaset_ext_router' with 'main_list' action
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="mediaset_ext_router", ms_action="main_list"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

    return None, None

def _ls_mediaset(cid):
    # HYBRID CACHE LOGIC:
    # If Cache Mode is ON, first try to load from disk.
    if _is_frozen_active():
        d = _load_cache(f"mediaset_{cid}")
        if d: 
            _process_mediaset_items(d)
            return
            
    # If not on cache mode OR cache miss, fetch from API

    # Custom encoding helper for MAB API
    # Dots, slashes, and hyphens need to be double encoded: %252E, %252F, %252D
    def _mab_encode(s):
        res = ""
        for char in s:
            if char == '.': res += "%252E"
            elif char == '/': res += "%252F"
            elif char == '-': res += "%252D"
            else: res += char
        return res

    # Construct EID param manuallly
    base_val = f"www.mitele.es/{cid}/"
    encoded_target = _mab_encode(base_val)
    
    eid_val = f"/automaticIndex/mtweb?url={encoded_target}&page=1&id=a-z&size=50"
    
    # URL encode the entire EID value to be safe for transport
    eid_final = urllib.parse.quote(eid_val, safe='')
    
    u_final = f"https://mab.mediaset.es/1.0.0/get?oid=bitban&eid={eid_final}"
    
    h = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3",
        "Origin": "https://www.mitele.es",
        "Referer": "https://www.mitele.es/"
    }

    try:
        # Pass URL directly strings to avoid re-encoding by requests
        r = requests.get(u_final, headers=h, timeout=15, verify=False)
        if r.status_code != 200:
             # Basic error handling
             li = xbmcgui.ListItem(label=f"Error API: Status {r.status_code}")
             li.setArt({'icon': 'DefaultIconError.png'})
             xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
             xbmcplugin.endOfDirectory(int(sys.argv[1]))
             return
             
        d = r.json()
        d = r.json()
    except Exception as e:
         _log_error(f"Error MAB API: {str(e)}")
         li = xbmcgui.ListItem(label=f"Error API: {str(e)}")
         li.setArt({'icon': 'DefaultIconError.png'})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
         xbmcplugin.endOfDirectory(int(sys.argv[1]))
         return

    # MAB structure: {'editorialObjects': [...]} or {'children': [...]}
    items = d.get("editorialObjects", [])
    if not items and "children" in d:
        items = d["children"] # Fallback
        
    formatted_items = []
    for i in items:
        # Map MAB item to _process_mediaset_items expectation
        # It expects "title" and "images": {"landscape": ...}
        # MAB has "title" and "image": {"src": ...}
        
        img = i.get("image", {}).get("src", "")
        # Create dict structure
        formatted_items.append({
            "title": i.get("title"),
            "images": {"main": img, "poster": img}
        })

    # CACHE SAVE LOGIC
    if _get_cache_mode() > 0:
        _save_cache(f"mediaset_{cid}", formatted_items)

    _process_mediaset_items(formatted_items)

def _process_mediaset_items(items):
    addon = xbmcaddon.Addon()
    ai = addon.getAddonInfo('icon')

    for i in items:
        # Extraer datos
        tt = i.get("title", "Sin título")
        
        # Intentar extraer imagen (la estructura varia)
        th = ai
        imgs = i.get("images", {})
        if imgs:
            # Preferencias de imagen
            for k in ["landscape", "main", "poster", "thumbnail"]:
                if k in imgs:
                    th = imgs[k]
                    # A veces es una lista o dict
                    if isinstance(th, list) and th: th = th[0]
                    if isinstance(th, dict): th = th.get("url") or th.get("href")
                    if th: break
        
        if not th: th = ai
        if th.startswith("//"): th = "https:" + th

        # Al hacer click, BUSCAR en internet (filosofía del addon)
        li = xbmcgui.ListItem(label=tt)
        li.setArt({'thumb': th, 'icon': th})
        
        cid_fav = i.get("url", "").split("/")[-1]
        if not cid_fav:
             # Try formatted_items fallback (Mediaset standard uses different key sometimes)
             cid_fav = tt.lower().replace(" ","-")
        
        # FAVORITOS
        _add_fav_cm(li, tt, "mediaset", "ls_mediaset", {"cid": cid_fav})
        
        # If Full Context is Active: Mediaset {tt}
        # If Inactive: {tt} (Just title)
        sq = f"Mediaset {tt}" if _is_full_context_active() else tt
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _catalog_menu():
    # 1. Plataformas principales
    li = xbmcgui.ListItem(label="Atresplayer")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="atresplayer_menu"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="RTVE Play")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="rtve_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Mediaset Infinity")
    li.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="mediaset_menu"), listitem=li, isFolder=True)
    
    # 2. Otros contenidos
    li = xbmcgui.ListItem(label="Películas (Top Historia/Populares)")
    li.setArt({'icon': 'DefaultMovies.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=1), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def main_menu():
    # 1. Búsqueda
    li = xbmcgui.ListItem(label="Buscar manualmente...")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="manual_search"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Historial de Búsquedas")
    li.setArt({'icon': 'DefaultAddonRepository.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_history"), listitem=li, isFolder=True)

    # 2. Catálogo (Agrupado)
    li = xbmcgui.ListItem(label="Catálogo")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Explora los contenidos de Atresplayer, RTVE Play, Mediaset y nuestra selección de Películas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="catalog_menu"), listitem=li, isFolder=True)
    
    # 3. Instantáneas
    li = xbmcgui.ListItem(label="Instantáneas")
    li.setArt({'icon': 'DefaultPicture.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshots_menu"), listitem=li, isFolder=True)

    # 4. Mis Favoritos
    li = xbmcgui.ListItem(label="Mis Favoritos")
    li.setArt({'icon': 'DefaultSets.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_favorites"), listitem=li, isFolder=True)
    
    # 5. Mis Descargas
    li = xbmcgui.ListItem(label="Mis Descargas")
    li.setArt({'icon': 'DefaultHardDisk.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="show_downloads"), listitem=li, isFolder=True)

    # 7. OPCIONES (ANTES DE INFO)
    li = xbmcgui.ListItem(label="[B][COLOR orange]OPCIONES[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="advanced_menu"), listitem=li, isFolder=True)

    # 8. Información
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Hecho por RubénSDFA1labernt")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="sanitized_info"), listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="Información del Addon")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="info"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="Mas en: https://github.com/fullstackcurso")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="web_info"), listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="v1.0.0 - [COLOR blue]Versión inicial[/COLOR] [COLOR green](Clic para ver notas)[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="version_notes"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def advanced_menu():
    # 0. Contexto Completo (A petición del usuario: PRIMERA OPCIÓN)
    lvl = _get_context_level()
    if lvl == 0:
        label = "Contexto Completo: [COLOR red]DESACTIVADO[/COLOR]"
        plot = "MODO SIMPLE: Busca usando SOLO el 'Título del Capítulo'.\n\nEjemplo: 'Capítulo 1' (Resultados mezclados).\n\n[COLOR blue][I]Pulsa para activar NIVEL 1[/I][/COLOR]"
    elif lvl == 1:
        label = "Contexto Completo: [COLOR green]NIVEL 1 (Padre)[/COLOR]"
        plot = "MODO RECOMENDADO: Busca usando 'Programa + Título'.\n\nEjemplo: 'Saber y Ganar Capítulo 1'.\n\n[COLOR blue][I]Pulsa para EXTENDER nivel[/I][/COLOR]"
    elif lvl == 2:
        label = "Contexto Completo: [COLOR green]NIVEL 2 (Padre + Abuelo)[/COLOR]"
        plot = "MODO EXTENDIDO: Incluye dos niveles de categorías superiores.\n\nEjemplo: 'Concursos Saber y Ganar Capítulo 1'.\n\n[COLOR blue][I]Pulsa para nivel MÁXIMO[/I][/COLOR]"
    else:
        label = "Contexto Completo: [COLOR green]NIVEL 3 (MAX)[/COLOR]"
        plot = "MODO MÁXIMO: Incluye toda la ruta de navegación.\n\nÚtil para estructuras muy complejas.\n\n[COLOR red][I]Pulsa para DESACTIVAR[/I][/COLOR]"

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_full_context"), listitem=li, isFolder=False)

    # 1. Búsqueda Avanzada
    if core_settings.is_advanced_search_active():
        label = "Menú de Búsqueda: [COLOR green]AVANZADO (Submenú)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá un menú intermedio con opciones de búsqueda especializada (Cine, Exacta, etc.).\n\n[COLOR blue][I]Pulsa para volver a Búsqueda Directa[/I][/COLOR]"
    else:
        label = "Menú de Búsqueda: [COLOR grey]SIMPLE (Directa)[/COLOR]"
        plot = "Al pulsar 'Buscar manualmente', se abrirá directamente el teclado para escribir.\n\n[COLOR blue][I]Pulsa para activar el Menú Avanzado[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_advanced_search"), listitem=li, isFolder=False)

    # 3. Integración Palantir (MOVIDO)
    if core_settings.is_palantir_integration_enabled():
        label = "Integración Palantir 3: [COLOR green]ACTIVADO[/COLOR]"
        plot = "Muestra accesos directos para buscar en Palantir 3 desde el historial, favoritos y resultados.\n\n[B]AVISO:[/B] EspaDaily no tiene relación con Palantir ni sus creadores. Esta función es solo un atajo externo.\n\n[COLOR blue][I]Pulsa para DESACTIVAR esta integración[/I][/COLOR]"
    else:
        label = "Integración Palantir 3: [COLOR grey]DESACTIVADO[/COLOR]"
        plot = "Oculta todas las opciones relacionadas con Palantir 3.\n\n[COLOR blue][I]Pulsa para ACTIVAR[/I][/COLOR]"
        
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_palantir_integration"), listitem=li, isFolder=False)

    # 4. Refrescar
    li = xbmcgui.ListItem(label="Refrescar Addon / Ver Cambios")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Recarga los menús y la configuración del addon sin necesidad de reiniciar Kodi.\n\nÚtil si notas que algo no carga correctamente o para aplicar cambios recientes."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="refresh_main"), listitem=li, isFolder=False)

    # 2. Debug
    if _is_debug_active():
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR green]ACTIVADO[/COLOR]")
    else:
        li = xbmcgui.ListItem(label="Modo Debug: [COLOR red]DESACTIVADO[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Activa el registro detallado de errores.\n\nPuedes generar un archivo de log interno y leerlo directamente desde este menú para solucionar problemas. Puede ralentizar el addon."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_debug"), listitem=li, isFolder=False)

    # 2b. View Log Button (If exists)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'espadaily_errors.log')
    if os.path.exists(log_file):
        li = xbmcgui.ListItem(label="[COLOR green]>> VER LOG DE ERRORES[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Abre y lee el archivo de errores 'espadaily_errors.log' generado por el addon.\n\nPuedes elegir ver solo las últimas líneas."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_error_log"), listitem=li, isFolder=False)

    # 3. Control de Caché (3 Estados)
    cmode = _get_cache_mode()
    if cmode == 0:
        label = "Caché: [COLOR grey]APAGADO (Estándar)[/COLOR]"
        plot = "MODO CLÁSICO (Por Defecto): El addon no guarda nada en el disco. Siempre descarga la información fresca de internet.\n\nEs el comportamiento original de Kodi. Más lento pero ahorra espacio."
    elif cmode == 1:
        label = "Caché: [COLOR yellow]GRABANDO (Segundo Plano)[/COLOR]"
        plot = "MODO PREPARACIÓN: El addon descarga de internet pero va guardando una copia en el disco silenciosamente.\n\nÚtil para ir construyendo tu librería local antes de activar el modo rápido."
    else:
        label = "Caché: [COLOR cyan]ACTIVADO (Híbrido)[/COLOR]"
        plot = "MODO ULTRA RÁPIDO: Carga los menús desde el disco al instante.\n\nSolo conecta a internet si es algo nuevo. Es la mejor experiencia de usuario."

    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_frozen"), listitem=li, isFolder=False)
        
    # 4. Backup (Import/Export)
    li = xbmcgui.ListItem(label="Exportar Backup (Historial + Favoritos + Categorías)")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Crea un archivo ZIP con una copia de seguridad TOTAL (Historial, Favoritos, Categorías e Instantáneas).\n\nPodrás restaurarlo luego o en otro dispositivo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="export_backup"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Importar Backup")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Restaura una copia de seguridad previa (archivo ZIP) de tu historial y snapshots.\n\nPuedes elegir qué restaurar.\n\nEsta opción también puede ser interesante para cargar backups o listas personalizadas compartidas por otros usuarios."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="import_backup"), listitem=li, isFolder=False)

    # 5. Priorizar por Ajuste (Match) vs Duración
    if core_settings.is_prioritize_match_active():
        label = "Priorizar: [COLOR green]AJUSTE AL CONTEXTO[/COLOR]"
        plot = "MODO PRECISIÓN: Los resultados se ordenan según cuánto se parecen las palabras clave al título buscado.\n\nIdeal si te aparecen vídeos largos que no tienen nada que ver con lo que buscas.\n\n[COLOR blue][I]Pulsa para priorizar por DURACIÓN (Estándar)[/I][/COLOR]"
    else:
        label = "Priorizar: [COLOR grey]DURACIÓN (ESTÁNDAR)[/COLOR]"
        plot = "MODO CLÁSICO: Se da mucha importancia a la duración del vídeo para encontrar capítulos completos.\n\nPuede causar que aparezcan vídeos largos que no coinciden bien con el nombre.\n\n[COLOR blue][I]Pulsa para priorizar por PRECISIÓN[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_prioritize_match"), listitem=li, isFolder=False)

    # 6. Priorizar Contenido Reciente
    if core_settings.is_recent_active():
        label = "Filtro Temporal: [COLOR green]RECIENTES PRIMERO[/COLOR]"
        plot = "MODO NOTICIAS: Los vídeos se ordenan por FECHA DE SUBIDA.\n\nIdeal para ver informativos de hoy o programas diarios.\n\n[COLOR blue][I]Pulsa para desactivar[/I][/COLOR]"
    else:
        label = "Filtro Temporal: [COLOR grey]RELEVANCIA (POR DEFECTO)[/COLOR]"
        plot = "MODO MIXTO: El orden depende de cuánto se parezca el título, sin importar si el vídeo es de ayer o de hace meses.\n\n[COLOR blue][I]Pulsa para activar orden RECIENTE[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_recent"), listitem=li, isFolder=False)

    # 7. Filtro Anti-Trailers (Minutos)
    min_m = core_settings.get_min_duration()
    if min_m > 0:
        label = f"Anti-Trailers: [COLOR green]SOLO +{min_m} MIN[/COLOR]"
        plot = f"MODO CAPÍTULO: Oculta automáticamente cualquier vídeo de menos de {min_m} minutos.\n\nIdeal para limpiar trailers, clips y avances de los resultados de búsqueda.\n\n[COLOR blue][I]Pulsa para cambiar o desactivar[/I][/COLOR]"
    else:
        label = "Anti-Trailers: [COLOR grey]DESACTIVADO[/COLOR]"
        plot = "MODO TODOS: Muestra todos los resultados encontrados, sin importar su duración.\n\n[COLOR blue][I]Pulsa para filtrar por duración mínima[/I][/COLOR]"
    
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="set_min_duration"), listitem=li, isFolder=False)

    # 8. Borrar Caché
    li = xbmcgui.ListItem(label="[COLOR red]¡BORRAR TODA LA CACHÉ![/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    li.setInfo('video', {'plot': "Elimina todos los datos temporales e imágenes guardadas.\nSOLUCIONA PROBLEMAS.\n\nÚtil si los menús muestran información antigua, imágenes rotas o comportamientos extraños."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_cache"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _get_debug_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'debug_state.json')

def _is_debug_active():
    f = _get_debug_state_file()
    if not os.path.exists(f): return False
    try:
        with open(f, 'r') as o: return json.load(o).get('active', False)
    except: return False

def _toggle_debug():
    NewState = not _is_debug_active()
    
    # Advertencia de seguridad SIEMPRE (tanto al activar como al desactivar)
    action_str = "activar" if NewState else "desactivar"
    if not xbmcgui.Dialog().yesno("ADVERTENCIA DE SEGURIDAD", 
        f"[COLOR red]ALERTA:[/COLOR] Vas a {action_str} el Modo Debug.\n\n"
        "Si no sabes lo que estás haciendo, esto podría causar errores o inestabilidad en el addon.\n"
        "¿Estás seguro de continuar?"):
        return

    # Check for custom log file generation if activating
    log_to_file = False
    if NewState:
        if xbmcgui.Dialog().yesno("Generar Log de Errores", 
            "¿Quieres generar un archivo LOG en la raíz del addon con los errores del addon?\n\n"
            "Esto creará 'espadaily_errors.log' en la carpeta del plugin."):
            log_to_file = True
            # Create file immediately with header
            try:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'espadaily_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] --- INICIO DE SESIÓN DE DEBUG ---\n")
            except: pass
    else:
        # Deactivating: Delete log file
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            log_file = os.path.join(base_dir, 'espadaily_errors.log')
            if os.path.exists(log_file):
                os.remove(log_file)
        except: pass

    with open(_get_debug_state_file(), 'w') as o: json.dump({'active': NewState, 'log_to_file': log_to_file}, o)
    
    msg = "ACTIVADO" if NewState else "DESACTIVADO"
    if log_to_file: msg += " (Con Log Propio)"
    xbmcgui.Dialog().notification("EspaDaily", f"Modo Debug {msg}", xbmcgui.NOTIFICATION_INFO)
    # Forzamos viaje al menu principal rompiendo la cache con un timestamp
    xbmc.executebuiltin(f"Container.Update({sys.argv[0]}?reload={int(time.time())}, replace)")

def _log_error(msg):
    # Always log to Kodi log
    xbmc.log(f"[EspaDaily ERROR] {msg}", xbmc.LOGERROR)
    
    # Check if we should log to custom file
    try:
        f = _get_debug_state_file()
        if os.path.exists(f):
            st = json.load(open(f, 'r'))
            if st.get('active') and st.get('log_to_file'):
                # Write to addon root
                base_dir = os.path.dirname(os.path.abspath(__file__))
                log_file = os.path.join(base_dir, 'espadaily_errors.log')
                ts = time.strftime('%Y-%m-%d %H:%M:%S')
                with open(log_file, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{ts}] {msg}\n")
    except: pass

def _view_error_log():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    log_file = os.path.join(base_dir, 'espadaily_errors.log')
    
    if not os.path.exists(log_file):
        xbmcgui.Dialog().ok("Error", "No existe el archivo de log.\nActiva el Modo Debug y genera errores primero.")
        return

    opts = ["Ver archivo completo", "Últimas 50 líneas", "Últimas 20 líneas", "Últimas 10 líneas"]
    sel = xbmcgui.Dialog().select("¿Qué deseas ver?", opts)
    if sel < 0: return
    
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            
        content = ""
        if not lines:
            content = "[El archivo está vacío]"
        else:
            if sel == 0: # Todo
                content = "".join(lines)
            elif sel == 1: # 50
                content = "".join(lines[-50:])
            elif sel == 2: # 20
                content = "".join(lines[-20:])
            elif sel == 3: # 10
                content = "".join(lines[-10:])
                
        xbmcgui.Dialog().textviewer("Log de Errores - EspaDaily", content)
    except Exception as e:
        xbmcgui.Dialog().ok("Error Leyendo Log", str(e))

def _get_frozen_state_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    return os.path.join(p, 'frozen_state.json')

def _is_frozen_active():
    # Helper for legacy checks, returns true if mode is 2 (Hybrid)
    return _get_cache_mode() == 2

def _get_cache_mode():
    f = _get_frozen_state_file()
    if not os.path.exists(f): return 0 # Default OFF
    try:
        data = json.load(open(f, 'r'))
        # Handle migration from boolean
        val = data.get('active', 0)
        if val is True: return 2
        if val is False: return 0
        return int(val)
    except: return 0

def _toggle_frozen():
    curr = _get_cache_mode()
    # Cycle: 0 -> 1 -> 2 -> 0
    new_mode = (curr + 1) % 3
    
    with open(_get_frozen_state_file(), 'w') as o: json.dump({'active': new_mode}, o)
    
    if new_mode == 0:
        msg = "Caché APAGADA: Datos temporales eliminados"
        # Borrar caché API automáticamente al apagar
        _clear_api_cache_only()
    elif new_mode == 1:
        msg = "Caché: GRABANDO en segundo plano"
    else:
        msg = "Caché: HÍBRIDA (Ultra Rápida)"
        
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _clear_api_cache_only():
    # Only delete files in api_cache dir, preserve history/settings
    try:
        cd = _get_cache_dir()
        if os.path.exists(cd):
            for f in os.listdir(cd):
                if f.endswith(".json"):
                    os.remove(os.path.join(cd, f))
    except: pass

def _toggle_prioritize_match():
    NewState = not core_settings.is_prioritize_match_active()
    core_settings.set_prioritize_match(NewState)
    msg = "MODO PRECISIÓN ACTIVADO" if NewState else "MODO DURACIÓN (ESTÁNDAR)"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _toggle_recent():
    NewState = not core_settings.is_recent_active()
    core_settings.set_recent_active(NewState)
    msg = "ORDEN RECIENTE ACTIVADO" if NewState else "ORDEN RELEVANCIA REINSTAURADO"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _set_min_duration_filter():
    opts = ["Desactivado", "Más de 2 min", "Más de 5 min", "Más de 10 min", "Más de 20 min (Solo Full)"]
    vals = [0, 2, 5, 10, 20]
    sel = xbmcgui.Dialog().select("Ocultar vídeos más cortos que...", opts)
    if sel < 0: return
    core_settings.set_min_duration(vals[sel])
    xbmc.executebuiltin("Container.Refresh")

def _toggle_palantir_integration():
    NewState = not core_settings.is_palantir_integration_enabled()
    core_settings.set_palantir_integration_enabled(NewState)
    
    if NewState:
        xbmcgui.Dialog().ok("Integración Palantir", "AVISO IMPORTANTE:\n\nEspaDaily NO está afiliado ni relacionado con el addon Palantir 3 ni sus desarrolladores.\n\nEsta función es simplemente un ATRAJO de búsqueda externa para facilitar la navegación.")
        
    msg = "Integración Palantir: ACTIVADA" if NewState else "Integración Palantir: DESACTIVADA"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

# Helper for building context queries
def _bi(context, title):
    return core_settings.build_query(title, context)

def _is_full_context_active():
    return core_settings.get_context_level() > 0

def _get_context_level():
    return core_settings.get_context_level()

def _toggle_full_context():
    new_level = core_settings.cycle_context_level()
    
    if new_level == 0:
         msg = "[COLOR red]DESACTIVADO[/COLOR]"
         detail = "Búsqueda simple: Solo Título.\n\n[COLOR blue][I]Pulsa otra vez para NIVEL 1[/I][/COLOR]"
    elif new_level == 1:
         msg = "[COLOR green]NIVEL 1 (Padre)[/COLOR]"
         detail = "Búsqueda: Padre + Título (ej. Serie + Capítulo).\n\n[COLOR blue][I]Pulsa otra vez para EXTENDER nivel[/I][/COLOR]"
    elif new_level == 2:
         msg = "[COLOR green]NIVEL 2 (Padre + Abuelo)[/COLOR]"
         detail = "Búsqueda: Abuelo + Padre + Título.\n\n[COLOR blue][I]Pulsa otra vez para nivel MÁXIMO[/I][/COLOR]"
    else:
         msg = "[COLOR green]NIVEL 3 (MAX)[/COLOR]"
         detail = "Búsqueda: Ruta completa + Título.\n\n[COLOR red][I]Pulsa otra vez para DESACTIVAR[/I][/COLOR]"

    xbmcgui.Dialog().ok("EspaDaily", f"Contexto Completo: {msg}\n{detail}")
    xbmc.executebuiltin("Container.Refresh")

def _get_cache_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    cd = os.path.join(p, 'api_cache')
    if not os.path.exists(cd): os.makedirs(cd)
    return cd

def _save_cache(key, data):
    try:
        f = os.path.join(_get_cache_dir(), f"{key}.json")
        with open(f, 'w', encoding='utf-8') as o: json.dump(data, o)
    except: pass

def _load_cache(key):
    f = os.path.join(_get_cache_dir(), f"{key}.json")
    if os.path.exists(f):
        try:
            with open(f, 'r', encoding='utf-8') as o: return json.load(o)
        except: pass
    return None

def _sanitized_info():
    t = (
        "[B]EspaDaily[/B]\nAddon desarrollado por RubénSDFA1labernt\n\n"
        
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con Atresplayer, RTVE, Mediaset ni ninguna entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"
        
        "[B]2. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de los servidores de las cadenas oficiales.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"
        
        "[B]4. Propósito:[/B]\n"
        "Es GRATUITO, sin ánimo de lucro y está desarrollado de buena fe con fines de preservación y acceso cultural.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y desea bloquear términos de búsqueda específicos, puede solicitarlo a través del canal de Telegram o GitHub.\n\n"
        
        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• Es posible encontrar capítulos o películas completas.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red."
    )
    xbmcgui.Dialog().textviewer("Información - RubénSDFA1labernt", t)

def _info():
    t = (
        "[B]EspaDaily[/B]\nAddon desarrollado por RubénSDFA1labernt\n"
        "Canal de Telegram: https://t.me/espadaily\n"
        "GitHub: https://github.com/fullstackcurso\n"
        "Contacto: https://fullstackcurso.github.io/donaciones/#mensaje\n"
        "[I](Nota: No se piden donaciones por ponerse en contacto; es por no hacer una web a propósito.)[/I]\n\n"
        
        "[B]AVISO LEGAL Y TÉCNICO IMPORTANTE:[/B]\n\n"
        
        "[B]1. No Afiliación:[/B]\n"
        "Este proyecto es independiente. NO tiene ninguna afiliación, acuerdo ni vinculación con Atresplayer, RTVE, Mediaset ni ninguna entidad oficial. Las marcas comerciales se utilizan con fin únicamente descriptivo para organizar los menús de búsqueda.\n\n"
        
        "[B]2. Naturaleza Técnica (Agregador de Búsqueda):[/B]\n"
        "Este software actúa exclusivamente como una herramienta de automatización. NO contiene, aloja ni sube contenido protegido.\n"
        "• El addon nunca interactúa, descifra ni elude la seguridad de los servidores de las cadenas oficiales.\n"
        "• Funciona realizando búsquedas de texto en servidores públicos de terceros, mostrando resultados que ya son accesibles públicamente en cualquier navegador web.\n\n"
        
        "[B]3. Responsabilidad del Usuario:[/B]\n"
        "El desarrollador no tiene control sobre los resultados encontrados en servidores externos. El usuario es el único responsable de verificar la legalidad del acceso a dichos contenidos según las leyes de su país de residencia. Este addon se proporciona \"tal cual\", sin garantías de ningún tipo.\n\n"
        
        "[B]4. Propósito:[/B]\n"
        "Es GRATUITO, sin ánimo de lucro y está desarrollado de buena fe con fines de preservación y acceso cultural.\n\n"
        
        "[B]Contacto y Retirada:[/B]\n"
        "Si usted es titular de derechos y desea bloquear términos de búsqueda específicos, puede solicitarlo a través del canal de Telegram o GitHub.\n\n"
        
        "[B]¿Qué puedo encontrar?[/B]\n"
        "El addon intenta filtrar los resultados con la mayor precisión posible, pero la precisión depende totalmente del contenido disponible públicamente en ese momento.\n"
        "• Es posible encontrar capítulos o películas completas.\n"
        "• A veces solo aparecerán tráilers, resúmenes o clips.\n"
        "• En ocasiones pueden aparecer resultados solo relacionados o similares.\n"
        "El addon NO garantiza qué resultados aparecen, ya que depende exclusivamente de lo que otros usuarios hayan compartido en la red."
    )
    xbmcgui.Dialog().textviewer("Información de EspaDaily", t)

def _web_info():
    t = (
        "https://github.com/fullstackcurso\n\n"
        "------------------------------------------------\n\n"
        "[B]Visita mi GitHub para más proyectos como este.[/B]\n\n"
        "Allí encontrarás mis otros trabajos y actualizaciones.\n"
        "Cualquier apoyo o difusión de mis proyectos se agradece enormemente.\n\n"
    )
    xbmcgui.Dialog().textviewer("Más en...", t)

def _version_notes():
    t = (
        "[B]GUÍA DE USUARIO & NOTAS V1.0.0[/B]\n\n"
        "¡Bienvenido a EspaDaily! Aquí tienes todo lo que necesitas saber para sacarle el máximo partido.\n\n"
        "------------------------------------------------\n"
        "[B]¿CÓMO FUNCIONA?[/B]\n"
        "EspaDaily es un explorador de catálogos. Tú navegas por los menús de Atresplayer, RTVE o Mediaset y, al elegir un contenido, el addon [B]busca automáticamente[/B] enlaces públicos en internet que coincidan.\n\n"
        "------------------------------------------------\n"
        "[B]HERRAMIENTAS PRINCIPALES[/B]\n\n"
        "• [B]Mis Favoritos:[/B] Guarda programas o series para acceder rápido. Pulsa clic derecho en cualquier ítem y elige 'Añadir a Favoritos'.\n"
        "• [B]Historial:[/B] Guarda tus últimas 50 búsquedas automáticamente.\n"
        "• [B]Instantáneas:[/B] Crea una copia de seguridad local de TODOS los menús del addon. Útil para navegar si falla internet o los servidores.\n"
        "• [B]Mis Descargas:[/B] Gestiona los vídeos que hayas guardado localmente.\n\n"
        "------------------------------------------------\n"
        "[B]GUÍA DE OPCIONES AVANZADAS[/B]\n\n"
        "• [B]Contexto Completo:[/B] Es la opción más importante. Define qué texto se busca en internet.\n"
        "   - [I]Desactivado:[/I] Busca solo el título del capítulo (Ej: 'Capítulo 1').\n"
        "   - [I]Nivel 1 (Recomendado):[/I] Busca Serie + Capítulo (Ej: 'Cuéntame Capítulo 1').\n"
        "   - [I]Nivel 2/MAX:[/I] Añade más datos de la ruta para búsquedas muy específicas.\n\n"
        "• [B]Priorizar Ajuste vs Duración:[/B]\n"
        "   - [I]Duración:[/I] Prefiere vídeos largos (evita clips cortos).\n"
        "   - [I]Ajuste:[/I] Prefiere títulos que coincidan exactamente, aunque sean cortos.\n\n"
        "• [B]Filtro Anti-Trailers:[/B] Oculta automáticamente vídeos de menos de X minutos.\n\n"
        "• [B]Filtro Temporal:[/B] Decide si prefieres ver primero los resultados más nuevos (Reciente) o los que mejor coinciden (Relevancia).\n\n"
        "• [B]Control de Caché:[/B]\n"
        "   - [I]Apagado:[/I] Siempre carga de internet (más lento, menos espacio).\n"
        "   - [I]Híbrido:[/I] Guarda los menús en disco para que navegar sea instantáneo.\n\n"
        "• [B]Otras Utilidades:[/B]\n"
        "   - [I]Refrescar:[/I] Recarga el addon si notas que algún menú no se actualiza.\n"
        "   - [I]Backup:[/I] Exporta tu historial e instantáneas a un archivo ZIP para llevarlos a otro Kodi.\n"
        "   - [I]Modo Debug:[/I] Actívalo solo si tienes problemas graves para generar un registro de errores.\n"
        "   - [I]Borrar Caché:[/I] Elimina datos temporales. Úsalo si tienes problemas de espacio o errores visuales.\n\n"
        "------------------------------------------------\n"
        "¡Que disfrutes de esta primera versión!"
    )
    xbmcgui.Dialog().textviewer("Guía y Notas v1.0.0", t)

def _manual_search():
    if core_settings.is_advanced_search_active():
        _advanced_search_menu()
        return

    kb = xbmc.Keyboard('', 'Introduce el nombre a buscar')
    kb.doModal()
    if kb.isConfirmed():
        q = kb.getText()
        if q:
            _add_to_history(q)
            _lfd(q, "", nh=True)

def _get_movies_list():
    return [
        "Avatar", "Vengadores: Endgame", "Avatar: El sentido del agua", "Titanic", "Star Wars: El despertar de la fuerza",
        "Vengadores: Infinity War", "Spider-Man: No Way Home", "Jurassic World", "El rey león", "Los Vengadores",
        "Fast & Furious 7", "Top Gun: Maverick", "Frozen II", "Barbie", "Vengadores: La era de Ultrón",
        "Super Mario Bros.: La película", "Black Panther", "Harry Potter y las Reliquias de la Muerte - Parte 2",
        "Star Wars: Los últimos Jedi", "Jurassic World: El reino caído", "Frozen", "La bella y la bestia",
        "Los Increíbles 2", "El destino de los furiosos", "Iron Man 3", "Minions", "Capitán América: Civil War",
        "Aquaman", "El Señor de los Anillos: El retorno del Rey", "Spider-Man: Lejos de casa", "Capitana Marvel",
        "Transformers: El lado oscuro de la luna", "Skyfall", "Transformers: La era de la extinción",
        "El caballero oscuro: La leyenda renace", "Joker", "Star Wars: El ascenso de Skywalker", "Toy Story 4",
        "Toy Story 3", "Piratas del Caribe: El cofre del hombre muerto", "El rey león (1994)", "Buscando a Dory",
        "Star Wars: La amenaza fantasma", "Alicia en el país de las maravillas", "Zootrópolis", "Harry Potter y la piedra filosofal",
        "Gru, mi villano favorito 3", "Buscando a Nemo", "Harry Potter y la Orden del Fénix", "Harry Potter y el misterio del príncipe",
        "El Señor de los Anillos: Las dos torres", "Shrek 2", "Bohemian Rhapsody", "El Señor de los Anillos: La comunidad del anillo",
        "Harry Potter y las Reliquias de la Muerte - Parte 1", "El Hobbit: Un viaje inesperado", "El caballero oscuro",
        "Jumanji: Bienvenidos a la jungla", "Harry Potter y el cáliz de fuego", "Spider-Man 3", "Transformers: La venganza de los caídos",
        "Spider-Man: Homecoming", "Ice Age 3: El origen de los dinosaurios", "Ice Age 4: La formación de los continentes",
        "El libro de la selva", "Batman v Superman: El amanecer de la justicia", "El Hobbit: La desolación de Smaug",
        "El Hobbit: La batalla de los cinco ejércitos", "Thor: Ragnarok", "Guardianes de la Galaxia Vol. 2",
        "Inside Out (Del revés)", "Venom", "Thor: Love and Thunder", "Deadpool 2", "Deadpool", "Star Wars: La venganza de los Sith",
        "Spider-Man", "Wonder Woman", "Independence Day", "Animales fantásticos y dónde encontrarlos", "Shrek Tercero",
        "Coco", "Jumanji: Siguiente nivel", "Harry Potter y la cámara secreta", "Star Wars: Una nueva esperanza",
        "ET El extraterrestre", "Misión Imposible: Fallout", "2012", "Indiana Jones y el reino de la calavera de cristal",
        "Fast & Furious 6", "Piratas del Caribe: En el fin del mundo", "El código Da Vinci", "X-Men: Días del futuro pasado",
        "Madagascar 3: De marcha por Europa", "Las crónicas de Narnia: El león, la bruja y el armario", "Man of Steel",
        "Monstruos University", "Matrix Reloaded", "Up", "Gravity", "Capitán América: El Soldado de Invierno",
        "La saga Crepúsculo: Amanecer - Parte 2", "La saga Crepúsculo: Amanecer - Parte 1", "La saga Crepúsculo: Luna nueva",
        "La saga Crepúsculo: Eclipse", "Forrest Gump", "El sexto sentido", "Interestelar", "Origen", "Gladiator",
        "Salvar al soldado Ryan", "La lista de Schindler", "El Padrino", "El Padrino Parte II", "Cadena perpetua",
        "Pulp Fiction", "El club de la lucha", "Matrix", "Goodfellas (Uno de los nuestros)", "Seven", "El silencio de los corderos",
        "La vida es bella", "Ciudad de Dios", "El viaje de Chihiro", "Parásitos", "Psicosis", "Casablanca",
        "El bueno, el feo y el malo", "12 hombres sin piedad", "La milla verde", "El gran dictador", "Cinema Paradiso",
        "Regreso al futuro", "Terminator 2: El juicio final", "Alien, el octavo pasajero", "Apocalypse Now",
        "Django desencadenado", "El resplandor", "WALL-E", "La princesa Mononoke", "Oldboy", "Amélie", "El laberinto del fauno"
    ]

"""
INSTRUCCIONES DE USO PARA EL ARCHIVO status.json
================================================

El archivo "status.json" sirve para controlar el addon a distancia una vez que los usuarios lo tienen instalado.
Para que funcione hay un arhivo en el repositorio de GitHub (en la misma ruta que configuré en el código).

EXPLICACIÓN DE LOS CAMPOS:
--------------------------

1. "allowed" (true / false)
   - true: El addon funciona con normalidad.
   - false: "KILL SWITCH". El addon deja de funcionar inmediatamente para todos los usuarios.
     Sirve para apagarlo por emergencia legal o técnica.

2. "min_version" (Ejemplo: "1.0.5")
   - Indica la versión mínima requerida para que el addon funcione.
   - Si un usuario tiene la versión "1.0.2" y pone aquí "1.0.5", el addon dejará de funcionarles
     y les obligará a actualizar.
   - Para no forzar actualizaciones, se deja en una versión baja (ej. "0.0.0").

3. "message"
   - Es el texto que le saldrá en pantalla al usuario si su versión es antigua o si el addon está desactivado.
   - Se puede cambiar para dar avisos (ej: "Mantenimiento", "Actualiza ya", etc).
"""
def _check_validity():
    # Sistema de seguridad para validar el addon remotamente
    pd = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(pd): os.makedirs(pd)
    sf = os.path.join(pd, 'status_check.json')
    
    now = time.time()
    st = {'last_check': 0, 'disabled': False}
    
    # Cargar estado local
    if os.path.exists(sf):
        try:
            with open(sf, 'r') as f: st = json.load(f)
        except: pass
    
    # If marked as disabled locally, block
    if st.get('disabled', False):
        return False
        
    # Saltarse comprobación si el modo estático está activo
    if _is_frozen_active():
        return True
        
    # Check only if 7 days have passed (604800 seconds)
    if now - st.get('last_check', 0) > 604800:
        try:
            r = requests.get(_STATUS_URL, timeout=10)
            
            # Si el archivo no existe (404) o hay error de servidor, IGNORAR (Fail Open)
            if r.status_code != 200:
                return True 
                
            data = r.json()
                
            # 1. Comprobacion Global (Kill Switch)
            if not data.get('allowed', True):
                st['disabled'] = True
                with open(sf, 'w') as f: json.dump(st, f)
                return False
            
            # 2. Comprobacion de Version Minima
            min_v = data.get('min_version', '0.0.0')
            cur_v = xbmcaddon.Addon().getAddonInfo('version')
            
            def pv(v): return [int(x) for x in v.replace('v','').split('.') if x.isdigit()]
            
            if pv(cur_v) < pv(min_v):
                # La version actual es inferior a la minima requerida
                msg = data.get('message', "Tu versión está obsoleta. Por favor actualiza el addon.")
                xbmcgui.Dialog().ok("EspaDaily", msg)
                st['disabled'] = True
                with open(sf, 'w') as f: json.dump(st, f)
                return False
            
            # Todo ok
            st['last_check'] = now
            st['disabled'] = False
            with open(sf, 'w') as f: json.dump(st, f)
        except Exception as e:
            _log_error(f"Error in validity check: {str(e)}")
            
    return True

"""
SISTEMA DE MENSAJES / AVISOS (messages.json)
============================================

Este sistema comprueba si hay novedades en el archivo "messages.json" de mi GitHub
y muestra una ventana emergente al usuario cuando entra al addon.

Configuración en messages.json:
-------------------------------
1. "id": ¡IMPORTANTE! Es el identificador del mensaje (ej: "aviso_v2").
   - El addon guarda qué IDs ya ha visto el usuario.
   - Para que salga un mensaje NUEVO, cambiar el "id" (ej: de "aviso_v1" a "aviso_v2").
   
2. "title": El título de la ventana emergente.

3. "message": El texto del aviso. Usa \n para saltos de línea.

4. "repeat": Cuántas veces se mostrará este mensaje al usuario.
   - 1  -> Se muestra solo la primera vez que entre (y nunca más).
   - 3  -> Se muestra las primeras 3 veces (para asegurar que lo lea).
   - -1 -> Se muestra SIEMPRE (infinito) cada vez que entre.
   - 0  -> Mensaje desactivado (no lo muestra nadie).

Ejemplo:
  {
    "id": "noticia_importante_enero",
    "title": "Mantenimiento",
    "message": "Mañana habrá cortes por mantenimiento.",
    "repeat": 1
  }
"""
def _check_messages():
    # Comprobar si hay mensajes remotos para mostrar
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p): os.makedirs(p)
    sf = os.path.join(p, 'messages_state.json')
    
    try:
        r = requests.get(_MESSAGES_URL, timeout=5)
        # Fail Open: Si no hay fichero o error, no hacemos nada y seguimos
        if r.status_code != 200: return
        
        data = r.json()
        
        # Support both old single-object format and new list format
        if isinstance(data, dict) and "messages" in data:
            msgs = data["messages"]
        elif isinstance(data, list):
            msgs = data
        else:
            msgs = [data] # Treat as single message object
            
        # Cargar estado local (cuantas veces se ha visto cada ID)
        st = {}
        if os.path.exists(sf):
            try:
                with open(sf, 'r') as f: st = json.load(f)
            except: pass
            
        params_changed = False
        
        for msg in msgs:
            mid = msg.get("id")
            # Default repeat to 1 if not present
            mrep = msg.get("repeat", 1) 
            
            # Si no hay ID o repeat es 0, saltamos este mensaje
            if not mid or mrep == 0: continue
            
            # Vemos cuantas veces ha visto este mensaje concreto
            views = st.get(mid, 0)
            
            show_it = False
            if mrep == -1: show_it = True    # Siempre
            elif views < mrep: show_it = True # Aun no ha llegado al limite
            
            if show_it:
                # Mostrar Dialogo
                # Support 'text' key as well as 'message'
                body = msg.get("text") or msg.get("message", "")
                title = msg.get("title", "Aviso EspaDaily")
                
                # Usar Dialog().ok para tener botón de aceptar/cerrar
                # Mantenemos el formateo de color que pediste
                color = msg.get("color", "white")
                formatted_text = f"[COLOR {color}][B]{title}[/B][/COLOR]\n\n{body}"
                
                xbmcgui.Dialog().ok("Aviso EspaDaily", formatted_text)
                
                # Incrementar contador y guardar
                st[mid] = views + 1
                params_changed = True
        
        if params_changed:
            with open(sf, 'w') as f: json.dump(st, f)
            
    except Exception as e:
        _log_error(f"Error checking messages: {str(e)}")
        pass

def _top_movies(page):
    try: page = int(page)
    except: page = 1
    per_page = 50
    movies = _get_movies_list()
    total = len(movies)
    start = (page - 1) * per_page
    end = start + per_page
    page_items = movies[start:end]

    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')

    for m in page_items:
        li = xbmcgui.ListItem(label=m)
        li.setArt({'thumb': icon, 'icon': icon})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=m, ot=icon, mode="movie"), listitem=li, isFolder=True)
    
    if end < total:
        li = xbmcgui.ListItem(label=f"Siguiente Página ({page + 1}) >>")
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="top_movies", page=page+1), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _ls(cid):
    # HYBRID CACHE LOGIC
    if _is_frozen_active():
        d = _load_cache(f"atres_{cid}")
        if d: 
            _process_atres_items(d, cid)
            return

    u = f"{_E0}/client/v1/row/search"
    p = {"entityType": "ATPFormat", "sectionCategory": "true", "mainChannelId": _E1, "categoryId": cid, "sortType": "THE_MOST", "size": 50, "page": 0}
    try:
        r = requests.get(u, params=p, headers=_H); r.raise_for_status(); d = r.json()
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    items = d.get("itemRows", [])
    
    # CACHE SAVE LOGIC
    if _get_cache_mode() > 0:
        _save_cache(f"atres_{cid}", items)

    _process_atres_items(items, cid)

def _process_atres_items(items, cid):
    addon = xbmcaddon.Addon(); ai = addon.getAddonInfo('icon'); af = addon.getAddonInfo('fanart')
    for i in items:
        try:
            tt = i.get("title", "Sin título"); im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr)
            if not th:
                try: dr = _sr(tt); th = dr[0].get("thumbnail_720_url") or dr[0].get("thumbnail_360_url") if dr else ai
                except: th = ai
            if not th: th = ai
            fa = th if th != ai else af
            lk = i.get("link", {}); au = lk.get("href")
            if not au: continue
            li = xbmcgui.ListItem(label=tt); li.setArt({'thumb': th, 'icon': th, 'fanart': fa})
            li.setInfo('video', {'title': tt, 'plot': i.get('description', '')})
            
            # FAVORITOS
            _add_fav_cm(li, tt, "atresplayer", "fs", {"au": au, "st": tt, "sth": th})
            
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=au, st=tt, sth=th), listitem=li, isFolder=True)
        except: continue
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)

def _clear_cache():
    if not xbmcgui.Dialog().yesno("EspaDaily", "¿Borrar TODA la caché?\n\nEsto eliminará el historial de búsquedas, configuración de debug y mensajes vistos.\n¿Estás seguro?"):
        return

    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if os.path.exists(p):
        for f in os.listdir(p):
            if f.endswith(".json"):
                try: os.remove(os.path.join(p, f))
                except: pass
    xbmcgui.Dialog().notification("EspaDaily", "Caché borrada", xbmcgui.NOTIFICATION_INFO)
    # Refrescar para reflejar cambios (ej: debug desactivado)
    xbmc.executebuiltin("Container.Refresh")

def _fs(au, st, sth="", pu=""):
    if pu and au == pu: _fb(st, sth); return
    try: r = requests.get(au, headers=_H); r.raise_for_status(); d = r.json()
    except: _fb(st, sth); return
    ss = d.get("seasons", []); rw = d.get("rows", []); id_ = d.get("items", [])
    erh = None
    for ro in rw:
        if ro.get("type") == "EPISODE": erh = ro.get("href"); break
    if erh: _lfr(erh, st, sth); return
    if id_: _rel(id_, st, sth); return
    if len(ss) > 1:
        for s in ss:
            t = s.get("title", "Temporada"); sh = s.get("link", {}).get("href")
            if sh and sh != au:
                li = xbmcgui.ListItem(label=t); li.setArt({'thumb': sth, 'icon': sth})
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fs", au=sh, st=st, sth=sth, pu=au), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(int(sys.argv[1])); return
    elif len(ss) == 1:
        sh = ss[0].get("link", {}).get("href")
        if sh and sh != au: _fs(sh, st, sth, pu=au); return
    _fb(st, sth)

def _fb(st, sth):
    li = xbmcgui.ListItem(label=f"Buscar '{st}' en Internet..."); li.setArt({'thumb': sth, 'icon': sth})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=st, ot=sth), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _lfr(ru, st, sth=""):
    try: r = requests.get(ru, headers=_H); d = r.json(); _rel(d.get("itemRows", []), st, sth)
    except: pass

def _rel(items, st, sth=""):
    for i in items:
        tt = i.get("title", "Capítulo"); en = i.get("name", ""); dt = f"{en} - {tt}" if en else tt
        # Apply global context
        sq = _bi(st, f"{tt} {en}" if en else tt)
        im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical"); th = _fix_img(tr) or sth
        li = xbmcgui.ListItem(label=dt); li.setArt({'thumb': th, 'icon': th, 'fanart': th})
        li.setInfo('video', {'title': dt, 'plot': i.get('description', '')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=sq, ot=th), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _clean_title(t):
    # Si hay dos partes separadas por " : ", quedarse con la segunda (suele ser el titulo real)
    if " : " in t: parts = t.split(" : "); t = parts[1] if len(parts[1]) > len(parts[0]) else parts[0]
    return t.strip() # Devolver limpio

def _lfd(q, ot, mode="", extra_params=None, nh=None):
    cq = _clean_title(q)
    rs = []
    
    if mode == "movie":
        # Intentar varias combinaciones para encontrar contenido en español
        variations = [
            f"{cq} pelicula completa castellano",
            f"{cq} pelicula completa español",
            f"{cq} pelicula completa",
            f"{cq} completa español",
            f"{cq} castellano",
            cq # Como ultimo recurso, el titulo limpio a secas
        ]
        
        for v in variations:
            rs = _sr(v, extra_params)
            if rs: break # Si encontramos algo, nos quedamos con ello
            
    elif mode == "exact":
        # Busca exactamente lo que el usuario escribió
        rs = _sr(q, extra_params)

    elif mode == "keywords":
        # Busca solo por palabras clave de más de 3 letras
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)

    else:
        # Logica estandar para series/programas (o User, Long, Short)
        # Si es modo User/Long/Short, el 'q' puede ser el termino de busqueda normal, y 'extra_params' lleva el filtro.
        # Intentamos con titulo limpio primero
        rs = _sr(cq, extra_params) 
        if not rs and cq != q: rs = _sr(q, extra_params) # Intentar con el original si el limpio falla
    
    if not rs and mode not in ["exact", "keywords"]: 
        # Ultimo intento: buscar solo palabras clave (mayores de 3 letras)
        kw = " ".join([w for w in re.findall(r'\w+', q) if len(w) > 3])
        if kw: rs = _sr(kw, extra_params)
    
    # OPCIÓN DIRECTA PARA PALANTIR SIEMPRE VISIBLE (Solo si la integración está activada)
    if core_settings.is_palantir_integration_enabled():
        li_p = xbmcgui.ListItem(label=f"[COLOR yellow][B]¿No es lo que buscas? Buscar '{cq}' en Palantir 3[/B][/COLOR]")
        li_p.setArt({'icon': 'DefaultAddonService.png', 'thumb': ot})
        li_p.setInfo('video', {'plot': f"Pulsa aquí para buscar directamente '{cq}' en Palantir 3 y obtener mejores calidades."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="palantir_search", q=cq), listitem=li_p, isFolder=False)

    if not rs: 
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    sr = _gsr(cq, rs, mode)[:25] # Aumentamos un poco el limite para tener mas donde ordenar
    
    if not sr: 
        # Modificación Petición Usuario: Dialogo para editar si no hay resultados
        if xbmcgui.Dialog().yesno("EspaDaily", "No se encontraron coincidencias relevantes.\n\n¿Quieres editar las palabras clave y probar otra vez?"):
             kb = xbmc.Keyboard(q, 'Editar Búsqueda')
             kb.doModal()
             if kb.isConfirmed():
                 nq = kb.getText()
                 if nq:
                     xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        return
    
    # GUARDAR RUTA DE EXPLORACIÓN (solo si hay resultados válidos y no viene del historial)
    if not nh:
        exploration_history.add_exploration(q)
    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except: du = 0
        
        # FILTRO ESTRICTO DE DURACIÓN
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        # En modo pelicula mostramos el titulo completo del video encontrado
        if mode == "movie":
             lb = vt
        else:
             lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        # MENU CONTEXTUAL PARA DESCARGAR Y PALANTIR
        cm = []
        if core_settings.is_palantir_integration_enabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=vt)})"))
            
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _pv(vid):
    mu = f"{_E4}{vid}"
    try:
        r = requests.get(mu); d = r.json(); qs = d.get("qualities", {}); murl = ""
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL": murl = s.get("url"); break
        if not murl: xbmcgui.Dialog().notification("EspaDaily", "No se encontró stream válido", xbmcgui.NOTIFICATION_ERROR); return
        try: m3c = requests.get(murl).text
        except: li = xbmcgui.ListItem(path=murl); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li); return
        vs = []; ls = m3c.splitlines()
        for i, l in enumerate(ls):
            if l.startswith("#EXT-X-STREAM-INF"):
                u = ls[i+1] if i+1 < len(ls) else ""
                if not u or u.startswith("#"): continue
                rm = re.search(r'RESOLUTION=(\d+x\d+)', l); bm = re.search(r'BANDWIDTH=(\d+)', l)
                rs = rm.group(1) if rm else "Unknown"; bw = int(bm.group(1)) if bm else 0
                vs.append({'label': f"{rs} ({int(bw/1024)} kbps)", 'url': u, 'bandwidth': bw})
        vs.sort(key=lambda x: x['bandwidth'], reverse=True)
        if not vs: li = xbmcgui.ListItem(path=murl); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li); return
        lbs = [v['label'] for v in vs]; rt = xbmcgui.Dialog().select("Selecciona Calidad", lbs)
        su = vs[rt]['url'] if rt >= 0 else vs[0]['url']
        if rt < 0: xbmcgui.Dialog().notification("EspaDaily", "Reproduciendo máxima calidad...", xbmcgui.NOTIFICATION_INFO)
        li = xbmcgui.ListItem(path=su); xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
    except Exception as e: _l(f"Play Error: {e}"); xbmcgui.Dialog().ok("Error", str(e))

def _download_video(vid, title):
    if not vid: return
    
    mu = f"{_E4}{vid}"
    try:
        # Resolve quality metadata
        r = requests.get(mu, headers=_H, timeout=12)
        r.raise_for_status()
        d = r.json()
        qs = d.get("qualities", {})
        
        all_links = []
        
        # 1. Search for direct MP4 links (Best for descending)
        for res_key, formats in qs.items():
            if res_key == "auto": continue
            for f in formats:
                u = f.get("url")
                if not u: continue
                if f.get("type") == "video/mp4":
                    res_val = int(res_key) if res_key.isdigit() else 0
                    all_links.append({'label': f"{res_key}p (Descarga Directa MP4)", 'url': u, 'res': res_val, 'type': 'mp4'})
        
        # 2. Search for HLS (M3U8) as fallback
        if "auto" in qs:
            for s in qs["auto"]:
                if s.get("type") == "application/x-mpegURL":
                    murl = s.get("url")
                    try:
                        m3c = requests.get(murl, timeout=10).text
                        ls = m3c.splitlines()
                        for i, l in enumerate(ls):
                            if l.startswith("#EXT-X-STREAM-INF"):
                                u = ls[i+1] if i+1 < len(ls) else ""
                                if not u or u.startswith("#"): continue
                                rm = re.search(r'RESOLUTION=(\d+x\d+)', l)
                                rs_str = rm.group(1) if rm else "Unknown"
                                res_val = int(rs_str.split('x')[1]) if 'x' in rs_str else 0
                                all_links.append({'label': f"{rs_str} (HLS por Segmentos .TS)", 'url': u, 'res': res_val, 'type': 'hls'})
                    except: pass

        # Sort all by resolution
        all_links.sort(key=lambda x: x['res'], reverse=True)

        if not all_links:
            xbmcgui.Dialog().ok("EspaDaily", "No se han encontrado enlaces de descarga para este contenido.\n\nEl servidor puede estar bloqueando el acceso directo a este video.")
            return

        # Interfaz de usuario
        lbs = [l['label'] for l in all_links]
        sel = xbmcgui.Dialog().select("Selecciona Calidad de Descarga", lbs)
        if sel < 0: return
        
        target = all_links[sel]
        
        # Ask for target directory
        path = xbmcgui.Dialog().browse(3, 'Selecciona dónde guardar el video', 'video', '', False, False, '')
        if not path: return
        
        # Confirm HLS if applicable
        if target['type'] == 'hls':
            if not xbmcgui.Dialog().yesno("Descarga HLS", "Este video no tiene enlace directo.\nSe bajará por segmentos y se unirán al final.\n\nEs un proceso lento. ¿Continuar?"):
                return

        # Prepare filenames
        safe_title = "".join([c for c in title if c.isalnum() or c in ' -_']).strip()
        if not safe_title: safe_title = vid
        ext = ".mp4" if target['type'] == 'mp4' else ".ts"
        dest = os.path.join(path, f"{safe_title}{ext}")
        
        # Trigger download
        if target['type'] == 'mp4':
            _do_download_direct(target['url'], dest, title)
        else:
            _do_download_hls(target['url'], dest, title)
            
    except Exception as e:
        _log_error(f"Download Error video {vid}: {str(e)}")
        xbmcgui.Dialog().ok("EspaDaily Error", f"Error al preparar descarga: {str(e)}")

def _do_download_direct(url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando MP4", f"Conectando: {title}")
    try:
        r = requests.get(url, stream=True, timeout=30)
        total = int(r.headers.get('content-length', 0))
        done = 0
        with open(dest, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024*256):
                if dp.iscanceled(): break
                f.write(chunk)
                done += len(chunk)
                if total > 0:
                    percent = int(done * 100 / total)
                    msg = f"Descargado: {done/(1024*1024):.1f}MB / {total/(1024*1024):.1f}MB"
                    dp.update(percent, msg)
        dp.close()
        if not dp.iscanceled():
            core_settings.log_download(title, dest, vid)
            xbmcgui.Dialog().ok("¡Éxito!", f"Video guardado correctamente en:\n{dest}")
        elif os.path.exists(dest):
            os.remove(dest)
    except Exception as e:
        if 'dp' in locals(): dp.close()
        _log_error(f"Error Direct DL: {str(e)}")
        xbmcgui.Dialog().ok("Error", f"Error en transferencia: {str(e)}")

def _do_download_hls(playlist_url, dest, title):
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    try:
        if '?' in playlist_url:
            base_url = playlist_url.split('?')[0].rsplit('/', 1)[0] + '/'
            params = '?' + playlist_url.split('?')[1]
        else:
            base_url = playlist_url.rsplit('/', 1)[0] + '/'
            params = ''

        m3u8_content = requests.get(playlist_url, timeout=15).text
        segments = [l for l in m3u8_content.splitlines() if l and not l.startswith('#')]
        total_seg = len(segments)
        
        if total_seg == 0:
            xbmcgui.Dialog().ok("Error", "La lista de reproducción está vacía."); return

        with open(dest, 'wb') as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled(): break
                
                if seg_name.startswith('http'):
                    seg_url = seg_name
                else:
                    seg_url = base_url + seg_name + params
                
                success = False
                for attempt in range(3):
                    try:
                        seg_data = requests.get(seg_url, timeout=12).content
                        f_out.write(seg_data)
                        success = True
                        break
                    except: continue
                
                if not success: raise Exception(f"Fallo crítico en segmento {idx+1}")
                
                percent = int((idx + 1) * 100 / total_seg)
                msg = f"Segmento {idx+1}/{total_seg} - {title}"
                dp.update(percent, msg)
        
        dp.close()
        if not dp.iscanceled():
            core_settings.log_download(title, dest, "HLS")
            xbmcgui.Dialog().ok("¡Completado!", f"El video HLS se ha unido y guardado en:\n{dest}")
        elif os.path.exists(dest):
            os.remove(dest)
        elif os.path.exists(dest):
            os.remove(dest)
    except Exception as e:
        if 'dp' in locals(): dp.close()
        _log_error(f"HLS Merge Error: {str(e)}")
        xbmcgui.Dialog().ok("Error Union HLS", f"Fallo: {str(e)}")

def _sr(q, extra_params=None):
    try:
        p = {"search": q, "fields": "id,title,owner.username,duration,thumbnail_360_url,thumbnail_720_url", "limit": 50}
        if core_settings.is_recent_active():
            p["sort"] = "recent"
        
        # Merge extra params (e.g. owner, longer_than)
        if extra_params:
            p.update(extra_params)

        r = requests.get(_E3, params=p, headers={"User-Agent": _H["User-Agent"]}); return r.json().get("list", [])
    except: return []

def _gsr(q, rs, mode=""):
    if not rs: return []
    sc = []; ql = q.lower().strip(); qn = re.findall(r'(\d+)', ql)
    for r in rs:
        t = r.get("title", "").strip(); tl = t.lower()
        if not t: continue
        
        # Base Similarity Score
        rt = difflib.SequenceMatcher(None, ql, tl).ratio(); s = rt
        
        # FILTRO ESTRICTO: Si no contiene las palabras clave de la busqueda, penalizar fuertemente
        # (Esto evita que salgan resultados random como 'La Monja' buscando 'Top Gun')
        q_words = [w for w in ql.split() if len(w) > 3] # Palabras importantes (>3 letras)
        if q_words:
            matches = sum(1 for w in q_words if w in tl)
            if matches == 0: 
                s -= 1.0 # Penalizacion masiva si no coincide ninguna palabra clave
            elif matches < len(q_words):
                s -= 0.1 # Pequeña penalizacion si faltan palabras

        if ql in tl: s += 0.35 # Match contenido exacto
        
        # Word Overlap Score
        words_q = set(ql.split())
        words_t = set(tl.split())
        common = words_q.intersection(words_t)
        if len(common) > 0: s += (len(common) / len(words_q)) * 0.2
        
        # Number Match Score
        tn = re.findall(r'(\d+)', tl)
        if qn and tn:
            if qn[-1] in tn: s += 0.4
            if set(qn).issubset(set(tn)): s += 0.1
            
        # Duration Score (Prioritize Full Movies/Episodes)
        # IMPORTANTE: Solo aplicamos bonus de duracion si el titulo coincide razonablemente bien (s > 0.3)
        # Esto evita que 'La Monja' (larga) gane a 'Iron Man 3' (corto) si el titulo no se parece.
        du = r.get("duration", 0)
        try: du = int(du)
        except: du = 0
        
        if s > 0.3: # Solo si hay match de titulo decente
            if not core_settings.is_prioritize_match_active():
                # Modo ESTÁNDAR: Fuerte bonus por duración
                if du > 600: s += 0.6    # Gran bonus si coincide titulo y es larga
                elif du > 300: s += 0.2
            else:
                # Modo PRECISIÓN: Bonus por duración mínimo
                if du > 600: s += 0.05
            
            if du < 180: s -= 0.1  # Penalizacion leve por ser muy corto (trailer)
        else:
            # Si el titulo no coincide bien, la duracion NO ayuda.
            pass
        
        # Language Bonus (Spanish preference)
        if any(w in tl for w in ["español", "castellano", "spanish"]):
            s += 0.15

        # Movie specific filtering
        if mode == "movie":
            # Penalize non-movie content
            if any(w in tl for w in ["trailer", "avance", "entrevista", "making", "detras", "clip", "promo"]):
                s -= 0.5
            # Bonus for explicit movie indicators
            if any(w in tl for w in ["pelicula", "completa", "movie", "film"]):
                s += 0.2

        sc.append((s, r))
    sc.sort(key=lambda x: x[0], reverse=True); return sc

# =================================================================================================
# FAVORITES & DOWNLOADS VIEWS
# =================================================================================================

def _show_fav_news():
    """Agregador: Busca contenido reciente de los favoritos con margen dinámico."""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No tienes favoritos guardados", xbmcgui.NOTIFICATION_WARNING)
        return
        
    # 1. Preguntar margen
    opts = [
        "Últimas 24 horas",
        "Últimas 48 horas (Recomendado)",
        "Última semana (7 días)",
        "Último mes (30 días - Lento)"
    ]
    sel = xbmcgui.Dialog().select("Margen de búsqueda de Novedades", opts)
    if sel < 0: return # Cancelado
    
    margins = [86400, 172800, 604800, 2592000]
    time_limit = int(time.time()) - margins[sel]
    sel_label = opts[sel]

    pdp = xbmcgui.DialogProgress()
    pdp.create("Novedades de mis Favoritos", f"Buscando: {sel_label}...")
    
    all_results = []
    
    queries = []
    seen = set()
    for f in favs:
        q = None
        if f.get('action') == 'lfr':
            q = f.get('params', {}).get('q')
        elif f.get('action') in ['ls', 'ls_rtve', 'ls_mediaset', 'fs', 'fs_rtve']:
            q = f['title']
            if ": " in q: q = q.split(": ")[-1]
        
        if q and q.lower() not in seen:
            queries.append(q)
            seen.add(q.lower())
            
    if not queries:
        pdp.close()
        xbmcgui.Dialog().ok("Mi Periódico", "No hay series o búsquedas en favoritos para analizar.")
        return

    total = len(queries)
    for i, q in enumerate(queries):
        if pdp.iscanceled(): break
        pdp.update(int((i/total)*100), f"Analizando: [B]{q}[/B]")
        
        rs = _sr(q, {"created_after": time_limit})
        if rs:
            sr = _gsr(q, rs, mode="keywords") 
            for score, v in sr:
                if score > 0.35: # Filtro de calidad para evitar basura
                    vid = v.get("id")
                    if not any(r[1].get("id") == vid for r in all_results):
                        all_results.append((score, v, q))

    pdp.close()
    
    if not all_results:
        xbmcgui.Dialog().ok("Novedades de mis Favoritos", f"No se han encontrado novedades en '{sel_label}' para tus favoritos.")
        return

    # Mostrar resultados consolidados
    h = int(sys.argv[1])
    all_results.sort(key=lambda x: x[0], reverse=True)
    xbmcplugin.setContent(h, 'videos')
    
    for score, v, origin in all_results:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except: du = 0
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url")
        
        label = f"[COLOR yellow][{origin}][/COLOR] {vt}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Favorito: {origin}\nSubido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        
        cm = []
        if core_settings.is_palantir_integration_enabled():
            cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=vt)})"))
        cm.append(("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})"))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(h)

def _show_favorites():
    favs = core_settings.get_favorites()
    
    # --- ADD Custom Categories LINK ---
    import category_manager
    cats = category_manager.load_cats()
    if cats:
         li_c = xbmcgui.ListItem(label=f"[COLOR yellow][B]Mis Categorías ({len(cats)})[/B][/COLOR]")
         li_c.setArt({'icon': 'DefaultAddonService.png'})
         li_c.setInfo('video', {'plot': "Accede a tus carpetas y listas personalizadas ('Infantil', 'Noticias', etc).\n\nPuedes crear nuevas categorías desde el menú principal."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li_c, isFolder=True)
    
    # --- ADD "NOVEDADES DE MIS FAVORITOS" LINK ---
    if favs:
         li_n = xbmcgui.ListItem(label="[COLOR yellow][B]Novedades de mis Favoritos[/B][/COLOR]")
         li_n.setArt({'icon': 'DefaultAddonService.png'})
         li_n.setInfo('video', {'plot': "Analiza automáticamente tus favoritos y busca contenido subido recientemente.\n\nPodrás elegir el margen de tiempo (24h, 48h, 7 días...).\n\nIdeal para ver qué hay de nuevo sin ir sección por sección."})
         xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_news"), listitem=li_n, isFolder=True)
    # ------------------------------------------

    if not favs:
        if not cats: # Only show 'empty' if no cats either
             li = xbmcgui.ListItem(label="No tienes favoritos guardados")
             li.setArt({'icon': 'DefaultIconInfo.png'})
             li.setInfo('video', {'plot': "Haz clic derecho en cualquier programa o serie y selecciona 'Añadir a Mis Favoritos' para guardarlo aquí."})
             xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for f in favs:
            li = xbmcgui.ListItem(label=f['title'])
            li.setArt({'icon': f['icon'], 'thumb': f['icon']})
            # Context menu items
            cm = []
            
            # 1. Palantir (Top Priority)
            if core_settings.is_palantir_integration_enabled():
                cm.append(("Buscar en Palantir 3", f"RunPlugin({_u(action='palantir_search', q=f['title'])})"))
            
            # 2. Management
            cm.append(("Editar nombre y buscar", f"RunPlugin({_u(action='edit_and_search', q=f['title'], ot=f['icon'])})"))
            cm.append(("Renombrar...", f"RunPlugin({_u(action='fav_rename', fav_url=f['url'], old_title=f['title'])})"))
            cm.append(("Mover arriba", f"RunPlugin({_u(action='fav_move_up', fav_url=f['url'])})"))
            cm.append(("Mover abajo", f"RunPlugin({_u(action='fav_move_down', fav_url=f['url'])})"))
            
            # 3. Categories
            # Usar 'cat_move_from_favs' para MOVER (borra de favs y añade a cat) en lugar de solo añadir.
            cm.append(("Mover a Categoría...", f"RunPlugin({_u(action='cat_move_from_favs', fav_url=f['url'], q=f['title'])})"))
            
            # 4. Remove (Destructive)
            cm.append(("Eliminar de Favoritos", f"RunPlugin({_u(action='remove_favorite', fav_url=f['url'])})"))
            
            li.addContextMenuItems(cm)
            
            # Re-build the original URL using saved action and params
            # We must reconstruct the URL. The stored "action" is just the suffix (e.g. ls_rtve) or the full action?
            # Stored: action="fs_rtve", params={"pid":...}
            # We need to construct sys.argv[0]?action=fav_action&...params...
            # Actually, the original code used a helper to run the plugin.
            # But here we want to List Item.
            
            # The URL to open when clicking the favorite:
            u_params = f"action={f['action']}"
            for k,v in f.get('params', {}).items():
                u_params += f"&{k}={urllib.parse.quote(str(v))}"
            
            # Explicitly avoid adding favorite-clicks to exploration history
            if f['action'] == 'lfr' and '&nh=' not in u_params:
                u_params += "&nh=1"
            
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sys.argv[0]+"?"+u_params, listitem=li, isFolder=True)

    # --- EXPORT / IMPORT FAVORITES ---
    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Favoritos...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Guarda tus favoritos principales en un archivo JSON para compartirlos."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_export"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="[COLOR cyan]Importar Favoritos...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Carga favoritos desde un archivo JSON."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="fav_import"), listitem=li, isFolder=False)
    # ---------------------------------

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _show_downloads():
    dls = core_settings.get_downloads()
    if not dls:
        li = xbmcgui.ListItem(label="No hay historial de descargas")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "Cuando descargues un vídeo con éxito, aparecerá aquí.\n\nPuedes descargar vídeos desde los resultados de búsqueda pulsando clic derecho."})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        for d in dls:
            path = d['path']
            if not os.path.exists(path):
                label = f"[COLOR grey][ELIMINADO][/COLOR] {d['title']}"
                is_valid = False
            else:
                label = f"{d['title']} ({d['date']})"
                is_valid = True
                
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': d['title'], 'plot': f"Archivo: {path}\nDescargado el: {d['date']}"})
            
            cm = [("Quitar del historial", f"RunPlugin({_u(action='remove_download', dl_path=path)})")]
            if is_valid:
                 li.setProperty("IsPlayable", "true")
                 cm.append(("[COLOR red]ELIMINAR ARCHIVO DEL DISCO[/COLOR]", f"RunPlugin({_u(action='delete_download_file', dl_path=path, title=d['title'])})"))
                 # Playing a local file
                 u = path
            else:
                 u = ""
                 
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=False if is_valid else True)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _add_fav_cm(li, title, platform, action, params):
    # Prepare URL for favorites (re-entrant call)
    # Mejorar la unicidad del ID para evitar duplicados falsos (especialmente en Atresplayer que usa 'au')
    id_val = params.get('cid') or params.get('pid') or params.get('url') or params.get('au') or params.get('q')
    if not id_val:
        # Fallback critico: Usar hash de params si no hay ID claro
        id_val = str(hash(json.dumps(params, sort_keys=True)))
        
    fav_url = f"{action}_{id_val}"
    params_json = json.dumps(params)
    li.addContextMenuItems([
        ("Añadir a Mis Favoritos", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=fav_url, icon=li.getArt('icon'), platform=platform, fav_action=action, params=params_json)})")
    ])

def _delete_download_file(path, title):
    if xbmcgui.Dialog().yesno("Eliminar Archivo", f"¿Estás seguro de que quieres eliminar físicamente el archivo?\n\n[B]{title}[/B]\n\nEsta acción eliminará el archivo de tu disco duro para siempre."):
        try:
            if os.path.exists(path):
                os.remove(path)
                core_settings.remove_download(path)
                xbmcgui.Dialog().notification("EspaDaily", "Archivo eliminado satisfactoriamente", xbmcgui.NOTIFICATION_INFO)
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().ok("EspaDaily", "El archivo ya no existe en esa ruta.")
                core_settings.remove_download(path)
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            xbmcgui.Dialog().ok("EspaDaily Error", f"No se pudo eliminar: {str(e)}")

# =================================================================================================
# SNAPSHOTS / INSTANTÁNEAS SYSTEM
# =================================================================================================

def _get_snapshot_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    sd = os.path.join(p, 'snapshots')
    if not os.path.exists(sd): os.makedirs(sd)
    return sd

def _get_platform_cats(platform):
    if platform == "atresplayer":
        return [
            {"title": "Series", "id": _E2["a"], "icon": "DefaultTVShows.png"},
            {"title": "Programas", "id": _E2["b"], "icon": "DefaultFolder.png"},
            {"title": "Documentales", "id": _E2["c"], "icon": "DefaultMovies.png"},
            {"title": "Infantil", "id": _E2["d"], "icon": "DefaultFolder.png"},
            {"title": "Actualidad", "id": _E2["e"], "icon": "DefaultIconInfo.png"},
        ]
    elif platform == "rtve":
        return [
            {"title": "Series", "id": "864", "icon": "DefaultTVShows.png"},
            {"title": "Cine", "id": "866", "icon": "DefaultMovies.png"},
            {"title": "Documentales", "id": "863", "icon": "DefaultMovies.png"},
            {"title": "Programas", "id": "102610", "icon": "DefaultFolder.png"},
            {"title": "Deportes", "id": "867", "icon": "DefaultIconInfo.png"},
            {"title": "Informativos", "id": "862", "icon": "DefaultIconInfo.png"},
            {"title": "Infantil (Clan)", "id": "865", "icon": "DefaultFolder.png"},
            {"title": "Archivo RTVE", "id": "102611", "icon": "DefaultAddonRepository.png"},
        ]
    elif platform == "mediaset":
        return [
            {"title": "Programas TV", "id": "programas-tv", "icon": "DefaultFolder.png"},
            {"title": "Series", "id": "series-online", "icon": "DefaultTVShows.png"},
            {"title": "Miniseries", "id": "miniseries", "icon": "DefaultTVShows.png"},
            {"title": "Cine", "id": "peliculas", "icon": "DefaultMovies.png"},
            {"title": "Documentales", "id": "documentales", "icon": "DefaultMovies.png"},
            {"title": "Música", "id": "musica", "icon": "DefaultAudio.png"},
            {"title": "Deportes", "id": "deportes", "icon": "DefaultFolder.png"},
        ]
    return []

def _fetch_list_data(platform, cid):
    items_out = []
    try:
        if platform == "atresplayer":
            u = f"{_E0}/client/v1/row/search"
            p = {"entityType": "ATPFormat", "sectionCategory": "true", "mainChannelId": _E1, "categoryId": cid, "sortType": "THE_MOST", "size": 50, "page": 0}
            r = requests.get(u, params=p, headers=_H, timeout=15)
            if r.status_code == 200:
                rows = r.json().get("itemRows", [])
                for i in rows:
                    im = i.get("image", {}); tr = im.get("pathHorizontal") or im.get("pathVertical")
                    lk = i.get("link", {}); href = lk.get("href", "")
                    tt = i.get("title", "Sin título")
                    th = _fix_img(tr)
                    items_out.append({
                        "title": tt,
                        "image": th,
                        "plot": i.get('description', ''),
                        "action_type": "fs",
                        "params": {"au": href, "st": tt, "sth": th}
                    })

        elif platform == "rtve":
            u = f"https://api.rtve.es/api/tematicas/{cid}/programas.json"
            r = requests.get(u, params={"size": 50}, timeout=15)
            if r.status_code == 200:
                rows = r.json().get("page", {}).get("items", [])
                for i in rows:
                    tt = i.get("title", "Sin título")
                    th = i.get("image", "") or i.get("imagen", "")
                    pid = str(i.get("id", ""))
                    items_out.append({
                        "title": tt,
                        "image": th,
                        "plot": i.get("description", ""),
                        "action_type": "fs_rtve",
                        "params": {"pid": pid, "st": tt, "sth": th}
                    })

        elif platform == "mediaset":
            def _me(s):
                res = ""
                for char in s:
                    if char == '.': res += "%252E"
                    elif char == '/': res += "%252F"
                    elif char == '-': res += "%252D"
                    else: res += char
                return res
            
            base_val = f"www.mitele.es/{cid}/"
            encoded_target = _me(base_val)
            eid_val = f"/automaticIndex/mtweb?url={encoded_target}&page=1&id=a-z&size=50"
            eid_final = urllib.parse.quote(eid_val, safe='')
            u_final = f"https://mab.mediaset.es/1.0.0/get?oid=bitban&eid={eid_final}"
            
            h = {
                "User-Agent": _H["User-Agent"],
                "Accept": "*/*",
                "Origin": "https://www.mitele.es",
                "Referer": "https://www.mitele.es/"
            }
            r = requests.get(u_final, headers=h, timeout=15, verify=False)
            if r.status_code == 200:
                d = r.json()
                rows = d.get("editorialObjects", []) or d.get("children", [])
                for i in rows:
                    tt = i.get("title", "Sin título")
                    img = i.get("image", {}).get("src", "")
                    items_out.append({
                        "title": tt,
                        "image": img,
                        "plot": "",
                        "action_type": "lfr",  # Mediaset siempre busca en la red
                        "params": {"q": f"Mediaset {tt}", "ot": img}
                    })
    except Exception as e:
        _log_error(f"Error fetching snapshot data ({platform}/{cid}): {str(e)}")
    
    return items_out
    
def _toggle_snapshot_context():
    core_settings.cycle_snapshot_context()
    xbmc.executebuiltin("Container.Refresh")

def _snapshot_context_help():
    t = (
        "[B]CONTEXTO DE BÚSQUEDA EN INSTANTÁNEAS[/B]\n\n"
        "Define cómo se construye la búsqueda al abrir contenido guardado.\n\n"
        
        "[B]Ejemplo: 'El Hormiguero' en 'Programas' de 'Atresplayer'[/B]\n\n"
        
        "[B]• CLÁSICO (Recomendado):[/B]\n"
        "  - Atresplayer: 'El Hormiguero'\n"
        "  - RTVE: 'RTVE El Hormiguero'\n"
        "  - Mediaset: 'Mediaset El Hormiguero'\n\n"
        
        "[B]• Nivel 0 (Solo Título):[/B]\n"
        "  - 'El Hormiguero'\n\n"
        
        "[B]• Nivel 1 (Categoría):[/B]\n"
        "  - 'Programas El Hormiguero'\n\n"
        
        "[B]• Nivel 2 (Plataforma+Categoría):[/B]\n"
        "  - 'Atresplayer Programas El Hormiguero'\n\n"
        
        "[B]¿CUÁL ELEGIR?[/B]\n"
        "CLÁSICO es la opción más segura y probada. Los niveles avanzados "
        "pueden mejorar la precisión en algunos casos, pero también pueden "
        "fallar si no hay vídeos con esas palabras exactas en el título."
    )
    xbmcgui.Dialog().textviewer("Ayuda: Contexto de Búsqueda", t)

def _snapshot_info():
    t = (
        "Es recomendable crear una instantánea periódicamente.\n\n"
        "Esto te permite acceder a los menús guardados incluso si se corta el acceso "
        "a las listas online, el servidor falla o el addon deja de recibir actualizaciones de contenido.\n\n"
        "Esta opción también puede ser interesante para cargar backups o listas compartidas por otros usuarios."
    )
    xbmcgui.Dialog().textviewer("Recomendación de Instantáneas", t)

def snapshots_menu():
    # INFO HEADER
    msg = "Es recomendable crear una instantánea periódicamente por si se corta el acceso a las listas online, falla el servidor o el contenido deja de actualizarse."
    li = xbmcgui.ListItem(label=f"[COLOR cyan][B]RECOMENDACIÓN:[/B][/COLOR] {msg}")
    li.setInfo('video', {'plot': "Es recomendable crear una instantánea periódicamente. Esto te permite acceder a los menús guardados incluso si se corta el acceso a las listas online, el servidor falla o el addon deja de recibir actualizaciones de contenido.\n\nEsta opción también puede ser interesante para cargar backups o listas compartidas por otros usuarios."})
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshot_info"), listitem=li, isFolder=False)

    # 1. Crear
    li = xbmcgui.ListItem(label="[COLOR green][B]+ CREAR NUEVA INSTANTÁNEA[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="create_snapshot"), listitem=li, isFolder=False)

    # 2. Borrar (listar para borrar)
    li = xbmcgui.ListItem(label="[COLOR red]BORRAR INSTANTÁNEAS...[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="delete_snapshot_menu"), listitem=li, isFolder=True)

    # 3. Exportar (NUEVO)
    li = xbmcgui.ListItem(label="[COLOR yellow]EXPORTAR INSTANTÁNEAS...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="export_snapshot_menu"), listitem=li, isFolder=True)

    # 4. Importar (NUEVO)
    li = xbmcgui.ListItem(label="[COLOR orange]IMPORTAR INSTANTÁNEA...[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="import_snapshot_menu"), listitem=li, isFolder=True)
    
    # 5. Contexto de Búsqueda (INDEPENDIENTE)
    curr_ctx = core_settings.get_snapshot_context_level()
    ctx_labels = {-1: "CLÁSICO (Recomendado)", 0: "APAGADO (Solo Título)", 1: "Nivel 1 (Categoría)", 2: "Nivel 2 (Plataforma+Cat)"}
    label_txt = ctx_labels.get(curr_ctx, "Desconocido")
    
    li = xbmcgui.ListItem(label=f"Contexto de Búsqueda: [COLOR yellow]{label_txt}[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Pulsa para cambiar el modo. Ver [?] Ayuda para más detalles."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="toggle_snapshot_context"), listitem=li, isFolder=False)

    # 4. Botón de Ayuda
    li = xbmcgui.ListItem(label="[COLOR blue][?] Ayuda: ¿Qué es el Contexto de Búsqueda?[/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="snapshot_context_help"), listitem=li, isFolder=False)

    # 5. Listar existentes
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')

    for f in files:
        # Format: snapshot_YYYYMMDD_HHMMSS.json
        try:
            ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
            # Simple parsing manually
            date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
            li = xbmcgui.ListItem(label=f"Instantánea: {date_str}")
            li.setArt({'icon': 'DefaultFolder.png', 'thumb': icon})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path="root"), listitem=li, isFolder=True)
        except: continue

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _create_snapshot():
    # 1. Elegir alcance (Scope)
    scope_opts = ["Todo el Catálogo (Atresplayer + RTVE + Mediaset)", "Seleccionar plataformas..."]
    scope_sel = xbmcgui.Dialog().select("¿Qué quieres guardar?", scope_opts)
    if scope_sel < 0: return

    platforms = ["atresplayer", "rtve", "mediaset"]
    selected_platforms = []
    
    if scope_sel == 0:
        selected_platforms = platforms
    else:
        # Multiselect dialog
        labels = ["Atresplayer", "RTVE Play", "Mediaset Infinity"]
        # Pre-select all by default? Or none? Let's pre-select all.
        initial_sel = [0, 1, 2] 
        ms_res = xbmcgui.Dialog().multiselect("Selecciona plataformas", labels, preselect=initial_sel)
        if not ms_res: return # Cancelled or empty
        
        for idx in ms_res:
            selected_platforms.append(platforms[idx])

    if not selected_platforms: return

    # 2. Elegir Tipo
    opts = ["Actualizable (Conectada)", "Independiente (Desconectada)"]
    sel = xbmcgui.Dialog().select("Tipo de Instantánea", opts)
    if sel < 0: return
    
    is_dynamic = (sel == 0)
    
    # Confirmacion final
    plat_str = ", ".join([p.upper() for p in selected_platforms])
    if not xbmcgui.Dialog().yesno("Crear Instantánea", f"Se guardarán: {plat_str}.\n\nEste proceso puede tardar unos segundos.\n¿Continuar?"):
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Creando Instantánea', 'Inicializando...')
    
    data = {
        "timestamp": int(time.time()),
        "type": "dynamic" if is_dynamic else "static",
        "content": {}
    }
    
    total_steps = 0
    for p in selected_platforms: total_steps += len(_get_platform_cats(p))
    
    current_step = 0
    
    for plt in selected_platforms:
        data["content"][plt] = {}
        cats = _get_platform_cats(plt)
        
        for c in cats:
            if pDialog.iscanceled(): 
                pDialog.close()
                return
            
            percentage = int((current_step / total_steps) * 100)
            pDialog.update(percentage, f"Escaneando {plt}...\nCategoría: {c['title']}")
            
            items = _fetch_list_data(plt, c["id"])
            data["content"][plt][c["title"]] = {
                "icon": c.get("icon"),
                "items": items
            }
            current_step += 1

    pDialog.update(100, "Guardando archivo...")
    
    # Save
    ts = time.strftime("%Y%m%d_%H%M%S")
    fname = f"instantaneas_espadaily_{ts}.json"
    fpath = os.path.join(_get_snapshot_dir(), fname)
    
    with open(fpath, 'w', encoding='utf-8') as f:
        json.dump(data, f)
        
    pDialog.close()
    xbmcgui.Dialog().notification("EspaDaily", "Instantánea creada correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _view_snapshot(f, path):
    fpath = os.path.join(_get_snapshot_dir(), f)
    if not os.path.exists(fpath): return
    
    with open(fpath, 'r', encoding='utf-8') as fo:
        data = json.load(fo)
        
    content = data.get("content", {})
    
    if path == "root":
        # Show Platforms
        platforms = [
            {"id": "atresplayer", "label": "Atresplayer", "icon": "DefaultFolder.png"},
            {"id": "rtve", "label": "RTVE Play", "icon": "DefaultFolder.png"},
            {"id": "mediaset", "label": "Mediaset Infinity", "icon": "DefaultFolder.png"},
        ]
        for p in platforms:
            li = xbmcgui.ListItem(label=p["label"])
            li.setArt({'icon': p['icon']})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path=p["id"]), listitem=li, isFolder=True)
            
    elif "/" not in path:
        # Path is just platform e.g. "atresplayer" -> Show Categories
        plt = path
        cats_data = content.get(plt, {})
        for cat_title, cat_data in cats_data.items():
            li = xbmcgui.ListItem(label=cat_title)
            li.setArt({'icon': cat_data.get("icon", "DefaultFolder.png")})
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="view_snapshot", file=f, path=f"{plt}/{cat_title}"), listitem=li, isFolder=True)
            
    else:
        # Path is platform/category -> Show Items
        parts = path.split("/")
        plt = parts[0]
        cat = parts[1]
        
        items = content.get(plt, {}).get(cat, {}).get("items", [])
        
        for i in items:
            tt = i.get("title")
            th = i.get("image")
            
            # Action: Search context managed dynamically
            
            # 1. Determine Context Mode (Independent)
            snap_mode = core_settings.get_snapshot_context_level()
            
            q = tt
            
            if snap_mode == -1:
                # CLASSIC LOGIC (Legacy defaults)
                if plt == "mediaset": q = f"Mediaset {tt}"
                elif plt == "rtve": q = f"RTVE {tt}"
                else: q = tt # Atresplayer default
                
            else:
                # ADVANCED LEVELS (0, 1, 2, 3)
                # Construct context string: "Platform || Category"
                
                plt_clean = plt
                if plt == "mediaset": plt_clean = "Mediaset"
                elif plt == "rtve": plt_clean = "RTVE"
                elif plt == "atresplayer": plt_clean = "Atresplayer"
                
                ctx_data = f"{plt_clean}||{cat}"
                
                # Force the specific level from snapshot settings
                q = core_settings.build_query(tt, ctx_data, force_level=snap_mode)
            
            li = xbmcgui.ListItem(label=tt)
            li.setArt({'thumb': th, 'icon': th})
            li.setInfo('video', {'title': tt, 'plot': i.get('plot', '')})
            
            # CHECK TYPE: Dynamic or Static
            snap_type = data.get("type", "static")
            
            if snap_type == "dynamic" and i.get("action_type"):
                # DYNAMIC: Reconnect to platform
                at = i.get("action_type")
                pm = i.get("params", {})
                
                # Special handling for Mediaset href
                if at == "ls_mediaset" and i.get("href"):
                     # Extract CID from href for mediaset logic if needed, or pass href directly if adapted
                     # Current ls_mediaset expects 'cid'. Let's try to parse or pass what we have.
                     # Simplified: If we have enough data, use it.
                     pass 
                
                # Build URL with original parameters
                url_params = {"action": at}
                url_params.update(pm)
                
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(**url_params), listitem=li, isFolder=True)
            
            else:
                # STATIC: Buscar en la red
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="lfr", q=q, ot=th), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _delete_snapshot_menu():
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    for f in files:
        ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
        date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
        
        li = xbmcgui.ListItem(label=f"[BORRAR] {date_str}")
        li.setArt({'icon': 'DefaultIconError.png'})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="delete_snapshot", file=f), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _delete_snapshot(f):
    if xbmcgui.Dialog().yesno("Borrar Instantánea", "¿Estás seguro de querer borrar esta instantánea?"):
        try:
            os.remove(os.path.join(_get_snapshot_dir(), f))
            xbmcgui.Dialog().notification("EspaDaily", "Borrada correctamente", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except: pass

def _export_backup():
    # Fix filename logic with timestamp
    ts = time.strftime("%Y%m%d_%H%M")
    default_name = f"espadaily_backup_{ts}.zip"
    
    d = xbmcgui.Dialog().browse(3, 'Guardar Backup', 'files', '', False, False, default_name)
    if not d: return
    
    if os.path.isdir(d):
        d = os.path.join(d, default_name)
    elif not d.lower().endswith(".zip"):
        d += ".zip"
    
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    
    files_added = 0
    snapshots_added = 0
    history_added = False
    categories_added = False
    
    try:
        with zipfile.ZipFile(d, 'w', zipfile.ZIP_DEFLATED) as zf:
            # 1. History
            hf = os.path.join(p, 'search_history.json')
            if os.path.exists(hf):
                zf.write(hf, arcname='search_history.json')
                history_added = True
            
            # 2. Categories
            cf = os.path.join(p, 'custom_categories.json')
            if os.path.exists(cf):
                zf.write(cf, arcname='custom_categories.json')
                categories_added = True
            
            # 2b. Favorites (NEW)
            fav = os.path.join(p, 'favorites.json')
            if os.path.exists(fav):
                zf.write(fav, arcname='favorites.json')
                favorites_added = True
            else:
                favorites_added = False
                
            # 3. Snapshots
            sd = os.path.join(p, 'snapshots')
            if os.path.exists(sd):
                for f in os.listdir(sd):
                    if f.endswith(".json"):
                        zf.write(os.path.join(sd, f), arcname=f"snapshots/{f}")
                        snapshots_added += 1
                        
        msg = f"Backup guardado en:\n{os.path.basename(d)}\n\n"
        msg += f"Historial: {'SÍ' if history_added else 'NO'}\n"
        msg += f"Categorías de Favoritos: {'SÍ' if categories_added else 'NO'}\n"
        msg += f"Favoritos: {'SÍ' if favorites_added else 'NO'}\n"
        msg += f"Instantáneas: {snapshots_added}"
        
        xbmcgui.Dialog().ok("EspaDaily Backup", msg)
        
    except Exception as e:
        xbmcgui.Dialog().ok("Error Backup", str(e))

def _import_backup():
    # 1. Ask for source
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Backup', 'files', '.zip', False, False, '')
    if not f: return
    
    # 2. Ask what to import
    opts = ["Todo (Historial + Favoritos + Categorías de Favoritos + Instantáneas)", "Solo Historial", "Solo Favoritos", "Solo Categorías de Favoritos", "Solo Instantáneas"]
    sel = xbmcgui.Dialog().select("¿Qué deseas importar?", opts)
    if sel < 0: return

    import_hist = (sel == 0 or sel == 1)
    import_favs = (sel == 0 or sel == 2)
    import_cats = (sel == 0 or sel == 3)
    import_snap = (sel == 0 or sel == 4)
    
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    
    count_snap = 0
    did_hist = False
    did_favs = False
    did_cats = False
    
    try:
        with zipfile.ZipFile(f, 'r') as zf:
            file_list = zf.namelist()
            
            # Import History
            if import_hist and 'search_history.json' in file_list:
                zf.extract('search_history.json', p)
                did_hist = True
            
            # Import Categories
            if import_cats and 'custom_categories.json' in file_list:
                zf.extract('custom_categories.json', p)
                did_cats = True
                
            # Import Favorites
            if import_favs and 'favorites.json' in file_list:
                zf.extract('favorites.json', p)
                did_favs = True
                
            # Import Snapshots
            if import_snap:
                sd = os.path.join(p, 'snapshots')
                if not os.path.exists(sd): os.makedirs(sd)
                
                for zn in file_list:
                    if zn.startswith("snapshots/") and zn.endswith(".json"):
                        # Extract directly to snapshots dir, avoiding subdirectory creation if possible
                        # zf.extract creates dirs.
                        # Let's read and write to avoid path issues
                        data = zf.read(zn)
                        fname = os.path.basename(zn)
                        with open(os.path.join(sd, fname), 'wb') as f_out:
                            f_out.write(data)
                        count_snap += 1
                        
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Fallo al importar:\n{str(e)}")
        return

    msg = []
    if did_hist: msg.append("- Historial restaurado")
    if did_cats: msg.append("- Categorías de Favoritos restauradas")
    if did_favs: msg.append("- Favoritos restaurados")
    if count_snap > 0: msg.append(f"- {count_snap} instantáneas restauradas")
    
    if not msg: msg.append("No se importó nada.")
    
    xbmcgui.Dialog().ok("Importación Completa", "\n".join(msg))
    xbmc.executebuiltin("Container.Refresh")

def _export_snapshot_menu():
    # 1. Listar disponibles
    sd = _get_snapshot_dir()
    files = sorted([f for f in os.listdir(sd) if f.endswith('.json')], reverse=True)
    
    if not files:
        xbmcgui.Dialog().notification("EspaDaily", "No hay instantáneas para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    # Formatear nombres para el diálogo
    display_list = []
    for f in files:
        ts_str = f.replace("instantaneas_espadaily_", "").replace("snapshot_", "").replace(".json", "")
        # Intentar formatear fecha si es posible
        try:
             date_str = f"{ts_str[6:8]}/{ts_str[4:6]}/{ts_str[0:4]} {ts_str[9:11]}:{ts_str[11:13]}"
             display_list.append(date_str)
        except:
             display_list.append(f) # Fallback

    # 2. Selección múltiple
    sel = xbmcgui.Dialog().multiselect("Seleccionar instantáneas a exportar", display_list)
    if not sel: return
    
    # 3. Elegir destino
    dest_folder = xbmcgui.Dialog().browse(0, 'Exportar a...', 'files', '', False, False, '')
    if not dest_folder: return
    
    # 4. Copiar archivos
    count = 0
    import shutil
    try:
        for idx in sel:
            filename = files[idx]
            src = os.path.join(sd, filename)
            dst = os.path.join(dest_folder, filename)
            shutil.copy2(src, dst)
            count += 1
        
        xbmcgui.Dialog().notification("EspaDaily", f"{count} instantáneas exportadas", xbmcgui.NOTIFICATION_INFO)
        
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al exportar:\n{str(e)}")

def _export_favorites():
    """Exporta solo la lista de favoritos principales (favorites.json)"""
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaDaily", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_INFO)
        return
        
    ts = time.strftime("%Y%m%d_%H%M")
    default_name = f"espadaily_favoritos_{ts}.json"
    
    d = xbmcgui.Dialog().browse(3, 'Guardar Favoritos', 'files', '', False, False, default_name)
    if not d: return
    
    if os.path.isdir(d):
        d = os.path.join(d, default_name)
    elif not d.lower().endswith(".json"):
        d += ".json"
        
    try:
        with open(d, 'w', encoding='utf-8') as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
        
        xbmcgui.Dialog().ok("Exportar Favoritos", f"Guardado correctamente:\n{os.path.basename(d)}\n\nElementos: {len(favs)}")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _import_favorites():
    """Importa lista de favoritos desde JSON"""
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de favoritos', 'files', '.json', False, False, '')
    if not f: return
    
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            new_favs = json.load(fp)
        
        if not isinstance(new_favs, list):
            xbmcgui.Dialog().ok("Error", "El archivo no es una lista válida de favoritos.")
            return

        # Simple verification of structure
        if new_favs and not 'url' in new_favs[0]:
            xbmcgui.Dialog().ok("Error", "El formato del JSON no parece ser de favoritos de EspaDaily.")
            return

        opts = ["Fusionar (Añadir nuevos)", "Reemplazar lista completa"]
        sel = xbmcgui.Dialog().select("¿Cómo importar?", opts)
        if sel < 0: return
        
        if sel == 0:
            # Merge
            added = 0
            for item in new_favs:
                if core_settings.add_favorite(item['title'], item['url'], item['icon'], item['platform'], item['action'], item['params']):
                    added += 1
            xbmcgui.Dialog().notification("EspaDaily", f"{added} favoritos añadidos", xbmcgui.NOTIFICATION_INFO)
            
        else:
            # Replace logic manually since core_settings doesn't expose set_favorites
            # We can overwrite the file manually
            profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            fav_file = os.path.join(profile, 'favorites.json')
            with open(fav_file, 'w') as out:
                json.dump(new_favs, out)
            xbmcgui.Dialog().notification("EspaDaily", "Lista reemplazada", xbmcgui.NOTIFICATION_INFO)
            
        xbmc.executebuiltin("Container.Refresh")
            
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))

def _import_snapshot_menu():
    # 1. Seleccionar archivo .json
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Instantánea', 'files', '.json', False, False, '')
    if not f: return
    
    # Validate filename if strict checks are needed? Or just let it be.
    # Just copy it to snapshots folder
    
    sd = _get_snapshot_dir()
    fname = os.path.basename(f)
    dest = os.path.join(sd, fname)
    
    # Ask overwrite if exists
    if os.path.exists(dest):
        if not xbmcgui.Dialog().yesno("EspaDaily", "Esta instantánea ya existe.\n¿Sobrescribir?"):
            return
            
    try:
        import shutil
        shutil.copy2(f, dest)
        xbmcgui.Dialog().notification("EspaDaily", "Instantánea importada con éxito", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Error al importar:\n{str(e)}")
        
def _toggle_advanced_search():
    NewState = not core_settings.is_advanced_search_active()
    core_settings.set_advanced_search_active(NewState)
    msg = "MENÚ AVANZADO ACTIVADO" if NewState else "BÚSQUEDA DIRECTA (SIMPLE)"
    xbmcgui.Dialog().notification("EspaDaily", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def _advanced_search_menu():
    # === BÚSQUEDAS BÁSICAS ===
    li = xbmcgui.ListItem(label="[B]— BÚSQUEDAS BÁSICAS —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda Estándar (Por Título)")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    _add_fav_cm(li, "Búsqueda Estándar", "search", "execute_adv_search", {"mode": ""})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode=""), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Películas (Modo Cine)")
    li.setArt({'icon': 'DefaultMovies.png'})
    li.setInfo('video', {'plot': "Optimiza la búsqueda para encontrar películas completas en castellano.\nPrueba variantes como 'pelicula completa', 'castellano', etc."})
    _add_fav_cm(li, "Búsqueda de Películas", "search", "execute_adv_search", {"mode": "movie"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="movie"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Series (Temporada + Capítulo)")
    li.setArt({'icon': 'DefaultTVShows.png'})
    li.setInfo('video', {'plot': "Introduce el nombre de la serie y el addon te pedirá número de temporada y capítulo.\nConstruye automáticamente la mejor query posible."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="series"), listitem=li, isFolder=True)

    # === FILTROS DE DURACIÓN ===
    li = xbmcgui.ListItem(label="[B]— FILTROS DE DURACIÓN —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Largos (+20 min)")
    li.setArt({'icon': 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de más de 20 minutos.\nIdeal para encontrar episodios completos o películas."})
    _add_fav_cm(li, "Vídeos Largos (+20 min)", "search", "execute_adv_search", {"mode": "long"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="long"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda de Vídeos Cortos (-10 min)")
    li.setArt({'icon': 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Filtra los resultados para mostrar solo vídeos de menos de 10 minutos.\nIdeal para buscar clips, canciones o sketches."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="short"), listitem=li, isFolder=True)

    # === FILTROS TEMPORALES ===
    li = xbmcgui.ListItem(label="[B]— FILTROS TEMPORALES —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Contenido de Hoy (Últimas 24h)")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en las últimas 24 horas.\nPerfecto para informativos y programas diarios."})
    _add_fav_cm(li, "Contenido de Hoy (24h)", "search", "execute_adv_search", {"mode": "recent_24h"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_24h"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Esta Semana")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 7 días."})
    _add_fav_cm(li, "Contenido de esta Semana", "search", "execute_adv_search", {"mode": "recent_week"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_week"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Contenido de Este Mes")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Muestra solo vídeos subidos en los últimos 30 días."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="recent_month"), listitem=li, isFolder=True)

    # === FILTROS DE CALIDAD E IDIOMA ===
    li = xbmcgui.ListItem(label="[B]— CALIDAD E IDIOMA —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Solo HD (Alta Definición)")
    li.setArt({'icon': 'DefaultVideo.png'})
    li.setInfo('video', {'plot': "Filtra para mostrar únicamente vídeos en HD (720p o superior)."})
    _add_fav_cm(li, "Solo HD", "search", "execute_adv_search", {"mode": "hd"})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="hd"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Solo Contenido en Español")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Filtra para mostrar solo vídeos con idioma español configurado."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="spanish"), listitem=li, isFolder=True)

    # === FILTROS AVANZADOS ===
    li = xbmcgui.ListItem(label="[B]— FILTROS AVANZADOS —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Búsqueda por Usuario / Canal")
    li.setArt({'icon': 'DefaultFolder.png'})
    li.setInfo('video', {'plot': "Busca contenido subido ÚNICAMENTE por un usuario específico (ej: 'rtve', 'atresplayer').\n\nPuedes filtrar por texto dentro del canal."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="user"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda Inversa (Excluir palabras)")
    li.setArt({'icon': 'DefaultIconError.png'})
    li.setInfo('video', {'plot': "Busca X pero EXCLUYENDO resultados que contengan ciertas palabras.\nÚtil para evitar 'trailer', 'making of', 'clip', etc."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exclude"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda Exacta (Sin limpieza)")
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Busca EXACTAMENTE lo que escribas, sin intentar limpiar el título ni quitar paréntesis."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="exact"), listitem=li, isFolder=True)
    
    li = xbmcgui.ListItem(label="Búsqueda por Palabras Clave")
    li.setArt({'icon': 'DefaultAddonWebSkin.png'})
    li.setInfo('video', {'plot': "Extrae solo las palabras importantes (más de 3 letras) y busca por ellas. Útil si el título oficial es muy largo o complejo."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="keywords"), listitem=li, isFolder=True)

    # === UTILIDADES ===
    li = xbmcgui.ListItem(label="[B]— UTILIDADES —[/B]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="Repetir Última Búsqueda (con filtros)")
    li.setArt({'icon': 'DefaultAddonRepository.png'})
    li.setInfo('video', {'plot': "Toma la última búsqueda de tu historial y te permite ejecutarla con cualquiera de los filtros anteriores."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="execute_adv_search", mode="repeat_last"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _execute_adv_search(mode):
    ep = None
    exclude_words = None
    q = ""
    
    # ===== SPECIAL INPUTS BY MODE =====
    
    # --- USER SEARCH (ask for username first) ---
    if mode == "user":
        kb = xbmc.Keyboard('', 'Introduce el ID de Usuario/Canal')
        kb.doModal()
        if not kb.isConfirmed(): return
        user = kb.getText()
        if not user: return
        ep = {"owner": user}
        
        # Now ask for search term within that channel
        kb = xbmc.Keyboard('', f'Buscar en canal de {user} (Opcional, vacío = últimos vídeos)')
        kb.doModal()
        if kb.isConfirmed():
            q = kb.getText()
        # If empty, we'll search latest from that user
        if q: _add_to_history(q)
        _lfd(q if q else " ", "", mode=mode, extra_params=ep, nh=True)
        return
    
    # --- SERIES SEARCH (ask for name, season, episode) ---
    if mode == "series":
        kb = xbmc.Keyboard('', 'Nombre de la Serie')
        kb.doModal()
        if not kb.isConfirmed(): return
        series_name = kb.getText()
        if not series_name: return
        
        # Ask for season
        kb = xbmc.Keyboard('', 'Número de Temporada (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        season = kb.getText()
        
        # Ask for episode
        kb = xbmc.Keyboard('', 'Número de Capítulo (vacío = cualquiera)')
        kb.doModal()
        if not kb.isConfirmed(): return
        episode = kb.getText()
        
        # Build optimized query
        q = series_name
        if season:
            q += f" T{season}" # Format: T1, T2, etc.
        if episode:
            q += f" Capitulo {episode}"
            # Also try alternate formats
        
        _add_to_history(q)
        _lfd(q, "", mode="", extra_params=None, nh=True)
        return
    
    # --- EXCLUDE SEARCH (ask for search + words to exclude) ---
    if mode == "exclude":
        kb = xbmc.Keyboard('', '¿Qué quieres buscar?')
        kb.doModal()
        if not kb.isConfirmed(): return
        q = kb.getText()
        if not q: return
        
        kb = xbmc.Keyboard('trailer, clip, making of', 'Palabras a EXCLUIR (separadas por coma)')
        kb.doModal()
        if not kb.isConfirmed(): return
        exclude_text = kb.getText()
        if exclude_text:
            exclude_words = [w.strip().lower() for w in exclude_text.split(",") if w.strip()]
        
        _add_to_history(q)
        _lfd_with_exclusions(q, "", exclude_words)
        return
    
    # --- REPEAT LAST (take from history) ---
    if mode == "repeat_last":
        h = _load_history()
        if not h:
            xbmcgui.Dialog().notification("EspaDaily", "No hay historial", xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Show filter selection
        filters = [
            ("Sin filtros (Estándar)", "", None),
            ("Modo Cine (Películas)", "movie", None),
            ("Solo +20 min", "", {"longer_than": 20}),
            ("Solo -10 min", "", {"shorter_than": 10}),
            ("Solo HD", "", {"hd": 1}),
            ("Solo Español", "", {"language": "es"}),
            ("Últimas 24h", "", {"created_after": int(time.time()) - 86400}),
            ("Última Semana", "", {"created_after": int(time.time()) - 604800}),
        ]
        
        opts = [f[0] for f in filters]
        sel = xbmcgui.Dialog().select(f"Repetir: '{h[0]}' con filtro...", opts)
        if sel < 0: return
        
        chosen_mode, chosen_ep = filters[sel][1], filters[sel][2]
        _lfd(h[0], "", mode=chosen_mode, extra_params=chosen_ep, nh=True)
        return
    
    # ===== STANDARD QUERY INPUT =====
    title = 'Búsqueda Avanzada'
    kb = xbmc.Keyboard('', title)
    kb.doModal()
    if not kb.isConfirmed(): return
    q = kb.getText()
    if not q: return
    
    _add_to_history(q)
    
    # ===== APPLY FILTERS BY MODE =====
    if mode == "long":
        ep = {"longer_than": 20}
    elif mode == "short":
        ep = {"shorter_than": 10}
    elif mode == "recent_24h":
        ep = {"created_after": int(time.time()) - 86400, "sort": "recent"}
    elif mode == "recent_week":
        ep = {"created_after": int(time.time()) - 604800, "sort": "recent"}
    elif mode == "recent_month":
        ep = {"created_after": int(time.time()) - 2592000, "sort": "recent"}
    elif mode == "hd":
        ep = {"hd": 1}
    elif mode == "spanish":
        ep = {"language": "es"}
    
    ep = {} if ep is None else ep
    _lfd(q, "", mode=mode, extra_params=ep, nh=True)

def _lfd_with_exclusions(q, ot, exclude_words):
    """Special version of _lfd that filters out results containing excluded words."""
    cq = _clean_title(q)
    rs = _sr(cq)
    if not rs and cq != q: rs = _sr(q)
    
    if not rs:
        xbmcgui.Dialog().notification("EspaDaily", "No se encontraron resultados", xbmcgui.NOTIFICATION_ERROR)
        return
    
    # Filter out excluded words
    if exclude_words:
        filtered = []
        for r in rs:
            title_lower = r.get("title", "").lower()
            if not any(ex in title_lower for ex in exclude_words):
                filtered.append(r)
        rs = filtered
    
    if not rs:
        xbmcgui.Dialog().notification("EspaDaily", "Todos los resultados fueron excluidos", xbmcgui.NOTIFICATION_WARNING)
        return
    
    sr = _gsr(cq, rs, "")[:25]
    
    if not sr:
        xbmcgui.Dialog().notification("EspaDaily", "Sin coincidencias relevantes", xbmcgui.NOTIFICATION_ERROR)
        return
    
    min_dur = core_settings.get_min_duration() * 60
    for sc, v in sr:
        vt = v.get("title", "Video"); vi = v.get("id"); ow = v.get("owner.username", "Unknown"); du = v.get("duration", 0)
        try: du = int(du)
        except: du = 0
        
        if min_dur > 0 and du < min_dur: continue
        dth = v.get("thumbnail_url") or v.get("thumbnail_360_url") or ot
        
        lb = f"{vt} ({int(sc*100)}% match)"

        li = xbmcgui.ListItem(label=lb); li.setArt({'thumb': dth, 'icon': dth})
        li.setInfo('video', {'title': vt, 'plot': f"Subido por: {ow}\nDuración: {du}s", 'duration': du})
        li.setProperty("IsPlayable", "true")
        li.addContextMenuItems([("Descargar Video", f"RunPlugin({_u(action='download_video', vid=vi, title=vt)})")])

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="pv", vid=vi), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def _toggle_palantir_search():
    current = core_settings.is_palantir_search_active()
    core_settings.set_palantir_search_active(not current)
    xbmc.executebuiltin("Container.Refresh")

def _p3_b64encode(value):
    """Implementación local de la codificación de Palantir 3"""
    if not isinstance(value, bytes):
        value = str(value).encode()
    value = base64.b64encode(value)
    length = len(value)
    part = int(length / 4)
    value = re.sub(b'=', b'', value)
    # Palantir reversible encoding: reverse 1/4 and 3/4
    encoded = value[:part][::-1] + value[part:][::-1]
    return urllib.parse.quote(encoded.decode())

def _search_palantir(query):
    if not query: return
    
    # Comprobar si Palantir está instalado
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.palantir3)"):
        xbmcgui.Dialog().ok("EspaDaily", "El addon Palantir 3 no parece estar instalado.\n\nEsta función requiere Palantir 3 para funcionar.")
        return

    # Preparar el objeto ITEM que espera Palantir
    # Palantir 3 espera un objeto P3Item serializado
    item_dict = {
        "action": "buscar3",
        "sql": f"rebuscar {query}",
        "label": query
    }
    
    # IMPORTANTE: Palantir 3 usa su propia codificación reversible
    # El formato del item debe ser un string repr de un diccionario
    encoded_item = _p3_b64encode(str(item_dict))
    
    # Palantir 3 usa la ventana HOME (10000) para sus propiedades de estado
    # Configuramos las propiedades que Palantir comprueba para saltarse el teclado
    window = xbmcgui.Window(10000)
    window.setProperty("p3_play", "true")
    window.setProperty("p3_item_buscar", encoded_item)
    
    # Lanzar la búsqueda. Palantir 3 prefiere el formato plugin://addond/?encoded_item
    # Probamos con ActivateWindow para abrir la carpeta de resultados
    plugin_url = f"plugin://plugin.video.palantir3/?{encoded_item}"
    
    _l(f"Enviando búsqueda a Palantir 3: {query}")
    _l(f"URL generada: {plugin_url}")
    
    # Usamos Container.Update en lugar de ActivateWindow para que al volver atrás 
    # regrese correctamente a nuestro addon en lugar de al menú de Palantir o al de Kodi.
    xbmc.executebuiltin(f"Container.Update({plugin_url})")

    # Monitor para detectar si Palantir falla (Petición usuario)
    # Si aparece un diálogo de OK y no ha cambiado el contenedor, es que ha fallado
    start_watch = time.time()
    while time.time() - start_watch < 15: # 15 segundos de margen
        xbmc.sleep(500)
        
        # Si el contenedor ya es Palantir, es que ha tenido éxito (está listando resultados)
        if xbmc.getInfoLabel("Container.PluginName") == "plugin.video.palantir3":
            return

        # Si detectamos un diálogo de aviso (probablemente el de "No results found")
        if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
            # Esperamos a que el usuario cierre ese diálogo
            while xbmc.getCondVisibility("Window.IsActive(okdialog)"):
                xbmc.sleep(500)
            
            # Tras cerrarlo, si seguimos en EspaDaily, preguntamos si quiere editar
            xbmc.sleep(500)
            if xbmc.getInfoLabel("Container.PluginName") != "plugin.video.palantir3":
                if xbmcgui.Dialog().yesno("EspaDaily", f"Palantir no ha encontrado resultados para:\n[B]{query}[/B]\n\n¿Quieres editar el texto y reintentar?"):
                    kb = xbmc.Keyboard(query, 'Editar búsqueda Palantir')
                    kb.doModal()
                    if kb.isConfirmed():
                        nq = kb.getText()
                        if nq: _search_palantir(nq) # Reintento recursivo
            return

def router(ps):
    if not _check_validity():
        xbmcgui.Dialog().ok("EspaDaily", "Esta versión del addon ha sido desactivada remotamente.\nPor favor, busca una actualización.")
        return

    p = dict(urllib.parse.parse_qsl(ps)); a = p.get("action")
    if a == "ls": _ls(p.get("cid"))
    elif a == "fs": _fs(p.get("au"), p.get("st"), p.get("sth", ""), p.get("pu", ""))
    elif a == "lfr": _lfd(p.get("q"), p.get("ot"), p.get("mode", ""), nh=p.get("nh"))
    elif a == "pv": _pv(p.get("vid"))
    elif a == "catalog_menu": _catalog_menu()
    elif a == "info": _info()
    elif a == "web_info": _web_info()
    elif a == "atresplayer_menu": atresplayer_menu()
    elif a == "rtve_menu": rtve_menu()
    elif a == "ls_rtve": _ls_rtve(p.get("cid"))
    elif a == "fs_rtve": _fs_rtve(p.get("pid"), p.get("st"), p.get("sth", ""))
    elif a == "manual_search": _manual_search()
    elif a == "top_movies": _top_movies(p.get("page"))
    elif a == "mediaset_menu": mediaset_menu()
    elif a == "advanced_menu": advanced_menu()
    elif a == "ls_mediaset":
        if _is_frozen_active():
            d = _load_cache(f"mediaset_{p.get('cid')}")
            if d: _process_mediaset_items(d); return
        _ls_mediaset(p.get("cid"))
    elif a == "show_history": _show_history()
    elif a == "clear_history": _clear_history()
    elif a == "remove_history_item": _remove_history_item(p.get("q"))
    elif a == "snapshots_menu": snapshots_menu()
    elif a == "create_snapshot": _create_snapshot()
    elif a == "view_snapshot": _view_snapshot(p.get("file"), p.get("path"))
    elif a == "delete_snapshot_menu": _delete_snapshot_menu()
    elif a == "delete_snapshot": _delete_snapshot(p.get("file"))
    elif a == "export_backup": _export_backup()
    elif a == "import_backup": _import_backup()
    elif a == "toggle_debug": _toggle_debug()
    elif a == "toggle_frozen": _toggle_frozen()
    elif a == "toggle_recent": _toggle_recent()
    elif a == "set_min_duration": _set_min_duration_filter()
    elif a == "toggle_prioritize_match": _toggle_prioritize_match()
    elif a == "show_favorites": _show_favorites()
    elif a == "add_favorite": 
         core_settings.add_favorite(p.get("title"), p.get("fav_url"), p.get("icon"), p.get("platform"), p.get("fav_action"), json.loads(p.get("params", "{}")))
    elif a == "remove_favorite":
         core_settings.remove_favorite(p.get("fav_url"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
         kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
         kb.doModal()
         if kb.isConfirmed():
             new_t = kb.getText()
             if new_t:
                 core_settings.rename_favorite(p.get("fav_url"), new_t)
                 xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "remove_favorite":
         core_settings.remove_favorite(p.get("fav_url"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_rename":
         kb = xbmc.Keyboard(p.get("old_title"), 'Renombrar Favorito')
         kb.doModal()
         if kb.isConfirmed():
             new_t = kb.getText()
             if new_t:
                 core_settings.rename_favorite(p.get("fav_url"), new_t)
                 xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_up":
         if core_settings.move_favorite(p.get("fav_url"), "up"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_move_down":
         if core_settings.move_favorite(p.get("fav_url"), "down"):
             xbmc.executebuiltin("Container.Refresh")
    elif a == "fav_news": _show_fav_news()
    elif a == "fav_export": _export_favorites()
    elif a == "fav_import": _import_favorites()
    elif a == "show_downloads": _show_downloads()
    elif a == "remove_download":
         core_settings.remove_download(p.get("dl_path"))
         xbmc.executebuiltin("Container.Refresh")
    elif a == "delete_download_file":
         _delete_download_file(p.get("dl_path"), p.get("title"))
    elif a == "clear_cache": _clear_cache()
    elif a == "refresh_main": xbmc.executebuiltin("Container.Refresh")
    elif a == "toggle_full_context": _toggle_full_context()
    elif a == "toggle_snapshot_context": _toggle_snapshot_context()
    elif a == "snapshot_context_help": _snapshot_context_help()
    elif a == "download_video": _download_video(p.get("vid"), p.get("title"))
    elif a == "toggle_advanced_search": _toggle_advanced_search()
    elif a == "advanced_search_menu": _advanced_search_menu()
    elif a == "execute_adv_search": _execute_adv_search(p.get("mode", ""))
    elif a == "toggle_palantir_integration": _toggle_palantir_integration()
    elif a == "snapshot_info": _snapshot_info()
    elif a == "export_snapshot_menu": _export_snapshot_menu() # NUEVO
    elif a == "import_snapshot_menu": _import_snapshot_menu()
    
    # --- CATEGORY MANAGER ROUTES ---
    elif a == "cat_menu": category_manager.main_menu()
    elif a == "cat_create": category_manager.create_category()
    elif a == "cat_delete": category_manager.delete_category(p.get("name"))
    elif a == "cat_rename": category_manager.rename_category(p.get("name"))
    elif a == "cat_view": category_manager.view_category(p.get("name"))
    elif a == "cat_add_item_dialog": category_manager.add_item_dialog(p.get("q"))
    elif a == "cat_remove_item": category_manager.remove_item(p.get("cat"), p.get("q"))
    elif a == "cat_move_item": category_manager.move_item(p.get("from_cat"), p.get("q"))
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_export": category_manager.export_categories()
    elif a == "cat_import": category_manager.import_categories()
    elif a == "cat_move_from_favs": 
         # Acción compuesta: Añadir a categoría -> Si éxito -> Borrar de favoritos
         if category_manager.add_item_dialog(p.get("q")):
             import time
             removed = core_settings.remove_favorite(p.get("fav_url"))
             if not removed:
                 # Debug: Avisar si falla el borrado
                 xbmcgui.Dialog().notification("EspaDaily", "Error: No se pudo quitar de favoritos", xbmcgui.NOTIFICATION_ERROR)
             else:
                 time.sleep(0.2) # Pequeña pausa para asegurar escritura
                 xbmc.executebuiltin("Container.Refresh")
    
    elif a == "toggle_palantir_search": _toggle_palantir_search()
    elif a == "palantir_search": _search_palantir(p.get("q"))
    
    elif a == "exp_menu": exploration_history.show_menu()
    elif a == "exp_edit": exploration_history.edit_query(p.get("q"))
    elif a == "exp_to_search": exploration_history.add_to_search_history(p.get("q"))
    elif a == "exp_delete": exploration_history.delete_entry(p.get("q"))
    elif a == "exp_clear_all": exploration_history.clear_all()
    elif a == "exp_set_depth": exploration_history.set_depth()
    elif a == "exp_search_direct": exploration_history.search_direct(p.get("q"))
    elif a == "rtve_ext_router" or a == "chopo_router": # backwards compatibility for cached menus
        if rtve_extended:
            c_act = p.get("rtve_action") or p.get("chopo_action")
            if hasattr(rtve_extended, c_act):
                getattr(rtve_extended, c_act)(p)
        else:
             xbmcgui.Dialog().notification("EspaDaily", "Módulo Extra no cargado", xbmcgui.NOTIFICATION_ERROR)
    elif a == "mediaset_ext_router":
        if mediaset_extended:
            ms_act = p.get("ms_action")
            if hasattr(mediaset_extended, ms_act):
                getattr(mediaset_extended, ms_act)(p)
        else:
             xbmcgui.Dialog().notification("EspaDaily", "Módulo Mediaset Extended no cargado", xbmcgui.NOTIFICATION_ERROR)
    elif a == "sanitized_info": _sanitized_info()
    elif a == "version_notes": _version_notes()
    elif a == "view_error_log": _view_error_log()
    elif a == "edit_and_search":
        # Global helper for "Edit and Search" context menu action
        q = p.get("q", "")
        ot = p.get("ot", "")
        kb = xbmc.Keyboard(q, 'Editar y Buscar')
        kb.doModal()
        if kb.isConfirmed():
             nq = kb.getText()
             if nq:
                 # Redirect to search with new query
                 xbmc.executebuiltin(f"Container.Update({_u(action='lfr', q=nq, ot=ot)})")

    else: 
        # Solo comprobar mensajes si estamos en el menu principal
        _check_messages()
        main_menu()

if __name__ == "__main__":
    try:
        router(sys.argv[2][1:])
    except Exception as e:
        import traceback
        _log_error(f"Unhandled exception: {str(e)}\n{traceback.format_exc()}")
        xbmcgui.Dialog().ok("EspaDaily - Error", "Ocurrió un error inesperado al procesar la ruta.\n\nConsulta el log de errores en Ajustes Avanzados.")
