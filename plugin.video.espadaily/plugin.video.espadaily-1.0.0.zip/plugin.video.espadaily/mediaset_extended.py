# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmcgui
import xbmcplugin
import core_settings
import json

try:
    import requests
except ImportError:
    requests = None

# =============================================================================
# MÓDULO EXTENDIDO MEDIASET (API MAB)
# =============================================================================
# Usando API MAB (mab.mediaset.es) porque es la única verificada 

import base64
_d = lambda s: base64.b64decode(s).decode()

MAB_BASE = _d("aHR0cHM6Ly9tYWIubWVkaWFzZXQuZXMvMS4wLjAvZ2V0P29pZD1iaXRiYW4mZWlkPQ==")
MAB_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Origin": _d("aHR0cHM6Ly93d3cubWl0ZWxlLmVz"),
    "Referer": _d("aHR0cHM6Ly93d3cubWl0ZWxlLmVzLw==")
}

class PluginTools:
    def get_params(self):
        return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

    def _mab_encode(self, s):
        res = ""
        for char in s:
            if char == '.': res += "%252E"
            elif char == '/': res += "%252F"
            elif char == '-': res += "%252D"
            else: res += char
        return res

    def add_item(self, action="", title="", thumbnail="", fanart="", url="", plot="", folder=True, isPlayable=False, show_title="", context_pass=False, main_action=None):
        base_url = sys.argv[0]
        handle = int(sys.argv[1])
        
        next_context = show_title
        if context_pass and title:
             clean_t = title.replace('[B]', '').replace('[/B]', '').replace('[COLOR yellow]', '').replace('[/COLOR]', '').strip()
             if next_context:
                 next_context += "||" + clean_t
             else:
                 next_context = clean_t
        
        if main_action:
            q = core_settings.build_query(url, show_title) if main_action == "lfr" else url
            params = {"action": main_action, "q": q, "ot": thumbnail}
        else:
            params = {
                "action": "mediaset_ext_router",
                "ms_action": action,
                "url": url,
                "thumbnail": thumbnail,
                "title": title,
                "show_title": next_context
            }
        
        params = {k: v for k, v in params.items() if v}
        u = base_url + "?" + urllib.parse.urlencode(params)
        
        li = xbmcgui.ListItem(label=title)
        if thumbnail: li.setArt({'icon': thumbnail, 'thumb': thumbnail})
        if fanart: li.setArt({'fanart': fanart})
        if plot: li.setInfo('video', {'plot': plot})
        
        # MENÚ CONTEXTUAL DE FAVORITOS
        if folder and action == "list_mab":
             # Esto es un nivel de programa/categoría
             cid = url.split("url=")[-1].split("&")[0]
             fav_url = f"list_mab_{cid}"
             p_json = json.dumps({"action": "mediaset_ext_router", "ms_action": "list_mab", "url": url, "title": title, "show_title": next_context})
             li.addContextMenuItems([
                 ("Añadir a Mis Favoritos", f"RunPlugin({base_url}?action=add_favorite&title={urllib.parse.quote(title)}&fav_url={fav_url}&icon={urllib.parse.quote(thumbnail)}&platform=mediaset&fav_action=mediaset_ext_router&params={urllib.parse.quote(p_json)})")
             ])

        xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=li, isFolder=folder)

    def close_item_list(self):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

pt = PluginTools()

def main_list(params):
    # Lista de categorías expandida
    cats = [
        {"title": "Programas TV", "id": "programas-tv"},
        {"title": "Series Online", "id": "series-online"},
        {"title": "Telenovelas", "id": "telenovelas"},
        {"title": "Miniseries", "id": "miniseries"},
        {"title": "Cine / Películas", "id": "peliculas"},
        {"title": "Documentales", "id": "documentales"},
        {"title": "Deportes", "id": "deportes"},
        {"title": "Informativos", "id": "informativos"},
        {"title": "Música", "id": "musica"},
        {"title": "TV Movies", "id": "tv-movies"}
    ]
    
    for c in cats:
        target = f"www.mitele.es/{c['id']}/"
        encoded_target = pt._mab_encode(target)
        eid_val = f"/automaticIndex/mtweb?url={encoded_target}&page=1&id=a-z&size=100"
        eid_final = urllib.parse.quote(eid_val, safe='')
        u = MAB_BASE + eid_final
        pt.add_item(action="list_mab", title=f"[B]{c['title']}[/B]", url=u, folder=True, context_pass=True)
    
    pt.close_item_list()

def list_mab(params):
    url = params.get("url")
    show_title = params.get("show_title", "")
    
    if not url: return

    try:
        r = requests.get(url, headers=MAB_HEADERS, timeout=12, verify=False)
        r.raise_for_status()
        d = r.json()
    except Exception as e:
        msg = str(e)[:50]
        xbmcgui.Dialog().notification("EspaDaily", f"Error Mediaset: {msg}", xbmcgui.NOTIFICATION_ERROR)
        pt.close_item_list()
        return

    items = d.get("editorialObjects", [])
    if not items and "children" in d: items = d["children"]

    for i in items:
        title = i.get("title", "Sin Título")
        desc = i.get("description", "")
        
        img_src = ""
        img_obj = i.get("image", {})
        if isinstance(img_obj, dict):
             img_src = img_obj.get("src", "")
        
        if img_src and img_src.startswith("//"): img_src = "https:" + img_src

        # LÓGICA DE NAVEGACIÓN:
        # Si el elemento tiene una 'url' (como /series-online/la-que-se-avecina/), podríamos intentar navegar más profundo.
        # Pero MAB generalmente solo proporciona el índice.
        # Para Mitele, la mejor UX es buscar directamente en la red desde estos títulos.
        
        pt.add_item(main_action="lfr", title=title, url=title, thumbnail=img_src, plot=desc, 
                     show_title=show_title)
        
    pt.close_item_list()
