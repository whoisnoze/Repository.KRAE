# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import re

def patch_palantir_skin():
    """
    Parchea el skin skin.estuary.palantir para permitir visualizar contenido genérico 
    y tipo 'videos' cuando se navega dentro de Palantir, evitando la pantalla negra.
    """
    # 1. Verificar si el skin actual es el problemático
    skin_id = xbmc.getSkinDir()
    if skin_id != 'skin.estuary.palantir':
        return False

    # 2. Obtener ruta del archivo Includes.xml del skin
    skin_path = xbmcvfs.translatePath('special://skin/')
    includes_xml = os.path.join(skin_path, 'xml', 'Includes.xml')

    if not os.path.exists(includes_xml):
        return False

    try:
        with open(includes_xml, 'r', encoding='utf-8') as f:
            content = f.read()

        # Marcador para evitar reaplicar el parche y recargas infinitas del skin
        patch_marker = '<!-- ESPADAILY_PATCH_VIDEOS -->'
        if patch_marker in content:
            return False

        modified = False
        
        # Expresiones de vista a parchear para incluir videos y contenido genérico vacío
        vistas_palantir = ['Vista50', 'Vista54', 'Vista55', 'Vista500', 'Vista504', 'Vista505', 'Vista506', 'Vista507']
        
        for vista in vistas_palantir:
            # Patrón para encontrar el inicio de la condición IsPalantirVistas dentro de la expresión
            # Buscamos: [ $EXP[IsPalantirVistas] +  o  [$EXP[IsPalantirVistas] +
            pattern = r'(<expression name="' + vista + r'">\s*\[\s*\$EXP\[IsPalantirVistas\]\s*\+)'
            
            # Verificamos si la vista existe en el archivo
            if re.search(pattern, content):
                # Añadimos la compatibilidad con Container.Content(videos) y Container.Content()
                replacement = r'\1\n\t\t\t[Container.Content(videos) | Container.Content()] |'
                new_content = re.sub(pattern, replacement, content)
                if new_content != content:
                    content = new_content
                    modified = True

        if modified:
            # Añadimos el marcador al principio o final para saber que ya está parcheado
            content = content.replace('<includes>', '<includes>\n\t' + patch_marker)
            
            with open(includes_xml, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Notificación al usuario
            xbmcgui.Dialog().notification('EspaDaily', 'Se han aplicado parches para hacer este addon compatible con Estuary Palantir', xbmcgui.NOTIFICATION_INFO, 5000)
            
            # Recargar el skin para que los cambios surtan efecto inmediatamente
            xbmc.executebuiltin('ReloadSkin()')
            return True

    except Exception as e:
        xbmc.log("Error en estuary_palantir_compatibility: " + str(e), xbmc.LOGERROR)
    
    return False

# Punto de entrada para ejecución directa o importación
if __name__ == '__main__':
    patch_palantir_skin()
