import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import json
import re
import base64
from urllib.parse import urlencode, parse_qsl, quote

# --- IMPORTS PARA SCRAPING ---
import requests
from bs4 import BeautifulSoup

# --- CONFIGURACIÓN GENERAL ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# --- ICONOS Y COLORES ---
ICON_AGENDA = xbmcaddon.Addon().getAddonInfo('path') + '/resources/agenda.png'
ICON_CHANNEL = xbmcaddon.Addon().getAddonInfo('path') + '/resources/channel.png'
COLOR_TIME = "FF87CEEB"
COLOR_SPORT_CATEGORY = "FF32CD32"
COLOR_GREEN = "FF00FF00"
COLOR_YELLOW = "FFFFFF00"

# --- URLS DE LA AGENDA ---
AGENDA_URLS = [
    "https://eventos-eight-dun.vercel.app/",
    "https://eventos-uvl7.vercel.app/"
]

# --- LISTA DE CHANNELS ---
CHANNELS = [
    # Motor
    {"title": "F1 TV", "id": ["f696f5a5f67fa9ee46f20b84b25dc57a6eb40934", "2758678e899ccf67ca134a6443cac017bf815dd9"]},

    # DAZN LaLiga
    {"title": "DAZN LaLiga", "id": ["acestream://eb4975702ceadca7ed74f8707e17a9f55569dbb9",
                                    "acestream://cc108ae39f92c48f6c946763047bd1c9b7b7d889",
                                    "acestream://a70a1605f69c8379e04094df96922a42adfbb431",
                                    "acestream://b63fcadc2390455d8a328f6c16b8b0a9adec21a3"]},

    # EUROSPORT
    {"title": "Eurosport 1", "id": ["acestream://a7b42f9d65636d1b1d9316d3e91ebe12b192658c",
                                    "acestream://48a589dbeab3544662fafd79888aada7d834cfe9",
                                    "acestream://0db68ab752b50e6bb257eef22d102c1d29cd92ea"]},
    {"title": "Eurosport 2", "id": ["acestream://5c910d614894635153a7d42de98cc2e4a958a53f",
                                    "acestream://24f940fef7e270b6b3ae5d9dc713a80c8345cfba",
                                    "acestream://f5908690485ae2facecf3074446ba4315f07a193"]},

    # HYPERMOTION
    {"title": "LaLiga TV Hypermotion", "id": ["acestream://1f75d92098580443857caa95a719103cb83781b0",
                                              "acestream://4636ed75106cb00e9c70cc2029edf0a4df7ad73f",
                                              "acestream://87bb542f974b6b9e89d0f2e20ed6dc93426f4be0"]},

    # MOVISTAR PLUS
    {"title": "MOVISTAR PLUS", "id": ["acestream://ed74406ccdb3c21941b919db6bffca7f1de015bb"]},

    # MOVISTAR DEPORTES
    {"title": "M+ Deportes", "id": ["acestream://6e031aed136bf97d8667fcd5fc49c73256928281",
                                    "acestream://2f3cfd199a49819cbd129689a840dc3d23ab93aa",
                                    "acestream://c6a824a81b36f6c3529826477caf2ad94b45776d",
                                    "acestream://6b15368775693c33c49fab02e7900c1976a5da90",
                                    "acestream://bfa01c11c5c6b7a616a516de4f2c769a89d26b25",
                                    "acestream://3774d8feab016ca766b35ea8488e7514ca30e0ee",
                                    "acestream://f0ee7a2b43c1df5ea9e4fac5bf876d5bef4372b0"]},

    # DEPORTES
    {"title": "Teledeporte", "id": ["acestream://b0d1489c9f3239349665ad5ab423363f2b02e5ae",
                                    "acestream://b35b3eb8e22365bf3469efd6d1f3b82618a6e18a",
                                    "acestream://3b50a1dca0977e3761d016edd79314ab797f74f6",
                                    "acestream://77cf022557c56cdf8d8115f50e61f846ad72ee05"]}
]

# --- FUNCIONES DE UTILIDAD ---
def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def clean_text(text):
    if not text: return ""
    return re.sub(r'\s+', ' ', text).strip()

def get_acestream_id(url):
    """Convierte cualquier URL AceStream en la ID pura"""
    if url.startswith("acestream://"):
        return url.replace("acestream://", "")
    return url

# --- PARSEO DE LA AGENDA ---
def fetch_html(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'es-ES,es;q=0.9',
    'Connection': 'keep-alive'
    }
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error fetch_html: {e}", xbmc.LOGERROR)
    return None

def parse_events(html):
    events = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        table = soup.find('table')
        if table:
            rows = table.find_all('tr')
            for row in rows:
                cols = row.find_all('td')
                if len(cols) < 6:
                    continue
                time = clean_text(cols[1].get_text())
                sport = clean_text(cols[2].get_text())
                competition = clean_text(cols[3].get_text())
                event_name = clean_text(cols[4].get_text())
                links_col = cols[5]

                links = []
                for link in links_col.find_all('a'):
                    href = link.get('href', '')
                    if 'acestream://' in href:
                        ace_id = get_acestream_id(href)
                        name = clean_text(link.get_text()).replace('▶','').strip()
                        links.append({'name': name, 'id': ace_id})

                if links:
                    title_display = f"[COLOR {COLOR_TIME}][{time}][/COLOR] [COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] {event_name} [I]({competition})[/I]"
                    events.append({'title': title_display, 'event_name': event_name, 'competition': competition, 'links': links})
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error parse_events: {e}", xbmc.LOGERROR)
    return events

# --- LISTADO DE AGENDA ---
def list_agenda_events():
    for url in AGENDA_URLS:
        html = fetch_html(url)
        if html:
            events = parse_events(html)
            if events:
                for item in events:
                    links = item['links']
                    # codificamos para pasar por URL
                    links_json = json.dumps(links).encode('utf-8')
                    links_b64 = base64.urlsafe_b64encode(links_json).decode('utf-8')
                    url_item = build_url({'action':'list_event_links','links': links_b64,'title': quote(item['event_name'])})
                    title_display = f"{item['title']} [COLOR {COLOR_YELLOW}]({len(links)} Canales)[/COLOR]"
                    li = xbmcgui.ListItem(label=title_display)
                    li.setInfo('video', {'title': item['event_name'], 'plot': f"{item['competition']} - Opciones: {len(links)}"})
                    li.setArt({'icon':'DefaultFolder.png'})
                    xbmcplugin.addDirectoryItem(addon_handle, url_item, li, True)
                break
    xbmcplugin.endOfDirectory(addon_handle)

# --- LISTADO DE ENLACES DEL EVENTO ---
def list_event_links(links_b64, event_title):
    try:
        links_json = base64.urlsafe_b64decode(links_b64.encode('utf-8')).decode('utf-8')
        links = json.loads(links_json)
        xbmcplugin.setContent(addon_handle,'videos')
        for link in links:
            display_name = f"[COLOR {COLOR_GREEN}]Ver en:[/COLOR] {link['name']}"
            url = build_url({'action':'play_channel','id':link['id']})
            li = xbmcgui.ListItem(label=display_name)
            li.setInfo('video', {'title': event_title})
            li.setProperty('IsPlayable','true')
            li.setArt({'icon':'DefaultVideo.png'})
            xbmcplugin.addDirectoryItem(addon_handle,url,li,False)
        xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error list_event_links: {e}",xbmc.LOGERROR)

# --- LISTADO DE CHANNELS ---
def list_channels():
    for ch in CHANNELS:
        ace_id = get_acestream_id(ch['id'])
        url_item = build_url({'action':'play_channel','id': ace_id})
        li = xbmcgui.ListItem(label=ch['title'])
        li.setInfo('video', {'title': ch['title']})
        li.setProperty('IsPlayable','true')
        li.setArt({'icon':'DefaultVideo.png'})
        xbmcplugin.addDirectoryItem(addon_handle, url_item, li, False)
    xbmcplugin.endOfDirectory(addon_handle)

# --- REPRODUCCIÓN SOLO HORUS ---
def play_channel(ace_id):
    try:
        horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
        li = xbmcgui.ListItem(path=horus_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, li)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error play_channel: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error","No se pudo reproducir el canal",xbmcgui.NOTIFICATION_ERROR)

# --- RUTEO PRINCIPAL ---
if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get('action')

    if action is None:
        # Menú principal con Agenda y Channels
        li1 = xbmcgui.ListItem(label="Agenda del Día")
        li1.setArt({'icon': ICON_AGENDA,'thumb': ICON_AGENDA})
        url1 = build_url({'action':'list_agenda'})
        xbmcplugin.addDirectoryItem(addon_handle, url1, li1, True)

        li2 = xbmcgui.ListItem(label="Channels")
        li2.setArt({'icon': ICON_CHANNEL,'thumb': ICON_CHANNEL})
        url2 = build_url({'action':'list_channels'})
        xbmcplugin.addDirectoryItem(addon_handle, url2, li2, True)

        xbmcplugin.endOfDirectory(addon_handle)

    elif action == 'list_agenda':
        list_agenda_events()
    elif action == 'list_event_links':
        links = args.get('links')
        title = args.get('title')
        list_event_links(links,title)
    elif action == 'list_channels':
        list_channels()
    elif action == 'play_channel':
        ace_id = args.get('id')
        play_channel(ace_id)
