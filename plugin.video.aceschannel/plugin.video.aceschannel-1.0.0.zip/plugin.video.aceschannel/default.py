import re
import urllib.request
import xbmcplugin
import xbmcgui
import sys

addon_handle = int(sys.argv[1])

def listar():
    url = "https://eventos-eight-dun.vercel.app/"

    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'Mozilla/5.0'}
    )

    html = urllib.request.urlopen(req).read().decode("utf-8")

    hashes = re.findall(r'acestream://([A-Za-z0-9]+)', html)

    for hash_id in hashes:
        stream_url = f"http://127.0.0.1:6878/ace/getstream?id={hash_id}"

        li = xbmcgui.ListItem(label=f"Stream {hash_id}")
        li.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=stream_url,
            listitem=li,
            isFolder=False
        )

    xbmcplugin.endOfDirectory(addon_handle)

listar()
