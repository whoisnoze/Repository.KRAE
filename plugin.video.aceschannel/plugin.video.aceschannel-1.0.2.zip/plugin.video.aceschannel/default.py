import sys
import urllib.request
import re
import xbmcgui
import xbmcplugin

addon_handle = int(sys.argv[1])

def scrapear_web():
    url = "https://TUWEB.com"

    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    html = urllib.request.urlopen(req).read().decode("utf-8")

    # Buscar todas las filas del tbody
    filas = re.findall(r'<tr>(.*?)</tr>', html, re.DOTALL)

    eventos = []

    for fila in filas:
        columnas = re.findall(r'<td.*?>(.*?)</td>', fila, re.DOTALL)

        if len(columnas) < 5:
            continue

        hora = re.sub(r'<.*?>', '', columnas[1]).strip()
        deporte = re.sub(r'<.*?>', '', columnas[2]).strip()
        torneo = re.sub(r'<.*?>', '', columnas[3]).strip()
        partido = re.sub(r'<.*?>', '', columnas[4]).strip()

        # Extraer enlaces dentro de td class="enlaces-acestream"
        enlaces_td = re.search(r'<td class="enlaces-acestream">(.*?)</td>', fila, re.DOTALL)
        if not enlaces_td:
            continue

        enlaces_html = enlaces_td.group(1)
        enlaces = re.findall(r'href="acestream://([A-Za-z0-9]+)".*?title="(.*?)"', enlaces_html, re.DOTALL)

        if not enlaces:
            continue

        eventos.append({
            "titulo": f"{hora} - {partido} ({deporte})",
            "canales": [{"nombre": nombre, "hash": hash_id} for hash_id, nombre in enlaces]
        })

    return eventos

def listar_eventos():
    eventos = scrapear_web()

    for idx, evento in enumerate(eventos):
        url_evento = f"{sys.argv[0]}?action=canales&evento={idx}"
        li = xbmcgui.ListItem(label=evento["titulo"])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_evento, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def listar_canales(evento_idx):
    eventos = scrapear_web()
    evento = eventos[int(evento_idx)]

    for canal in evento["canales"]:
        stream_url = f"http://127.0.0.1:6878/ace/getstream?id={canal['hash']}"
        li = xbmcgui.ListItem(label=canal["nombre"])
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

# Router simple
import urllib.parse
args = urllib.parse.parse_qs(sys.argv[2][1:])
action = args.get("action", [None])[0]

if action == "canales":
    listar_canales(args.get("evento", [0])[0])
else:
    listar_eventos()
