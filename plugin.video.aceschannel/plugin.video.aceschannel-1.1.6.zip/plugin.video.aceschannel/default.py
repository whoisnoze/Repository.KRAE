import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import json
import re
from urllib.parse import urlencode, parse_qsl, quote

import requests
from bs4 import BeautifulSoup

# --- CONFIGURACIÓN GENERAL ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# --- ICONOS Y COLORES ---
ICON_AGENDA = xbmcaddon.Addon().getAddonInfo('path') + '/resources/agenda.png'
COLOR_TIME = "FF87CEEB"
COLOR_SPORT_CATEGORY = "FF32CD32"
COLOR_GREEN = "FF00FF00"
COLOR_YELLOW = "FFFFFF00"

# --- URLS DE LA AGENDA ---
AGENDA_URLS = [
    "https://eventos-eight-dun.vercel.app/"
]

# --- FUNCIONES DE UTILIDAD ---

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def clean_text(text):
    if not text: return ""
    return re.sub(r'\s+', ' ', text).strip()

def get_acestream_id(url):
    if url.startswith("acestream://"):
        return url.replace("acestream://", "")
    return url

# --- PARSEO DE LA AGENDA ---

def fetch_html(url):
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error fetch_html: {e}", xbmc.LOGERROR)
    return None

def parse_events(html):
    events = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        tables = soup.find_all('table')

        for table in tables:
            rows = table.find_all('tr')

            for row in rows:
                cols = row.find_all('td')
                if len(cols) < 5:
                    continue

                time = clean_text(cols[1].get_text())
                sport = clean_text(cols[2].get_text())
                competition = clean_text(cols[3].get_text())
                event_name = clean_text(cols[4].get_text())

                # Buscar enlaces AceStream en toda la fila
                links = []
                seen_ids = set()

                for link in row.find_all('a'):
                    href = link.get('href', '')
                    if 'acestream://' in href:
                        ace_id = get_acestream_id(href)
                        if ace_id not in seen_ids:
                            seen_ids.add(ace_id)
                            name = clean_text(link.get_text()).replace('▶', '').strip()
                            links.append({
                                'name': name,
                                'id': ace_id
                            })

                # Ignorar eventos sin enlaces reales
                if not links:
                    continue

                title_display = (
                    f"[COLOR {COLOR_TIME}][{time}][/COLOR] "
                    f"[COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] "
                    f"{event_name} [I]({competition})[/I]"
                )

                events.append({
                    'title': title_display,
                    'event_name': event_name,
                    'competition': competition,
                    'links': links
                })

    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error parse_events: {e}", xbmc.LOGERROR)

    return events


# --- LISTADO DE LA AGENDA ---

def list_agenda_events():
    for url in AGENDA_URLS:
        html = fetch_html(url)
        if html:
            events = parse_events(html)
            if events:
                for item in events:
                    links = item['links']
                    if len(links) == 1:
                        url_item = build_url({'action':'play_channel','id':links[0]['id']})
                        li = xbmcgui.ListItem(label=item['title'])
                        li.setInfo('video', {'title': item['event_name'], 'plot': item['competition']})
                        li.setProperty('IsPlayable','true')
                        li.setArt({'icon':'DefaultVideo.png','thumb':'DefaultVideo.png'})
                        xbmcplugin.addDirectoryItem(addon_handle, url_item, li, False)
                    else:
                        links_json = json.dumps(links)
                        url_item = build_url({'action':'list_event_links','links':links_json,'title':item['event_name']})
                        title_display = f"{item['title']} [COLOR {COLOR_YELLOW}]({len(links)} Canales)[/COLOR]"
                        li = xbmcgui.ListItem(label=title_display)
                        li.setInfo('video', {'title': item['event_name'], 'plot': f"{item['competition']} - Opciones: {len(links)}"})
                        li.setArt({'icon':'DefaultFolder.png'})
                        xbmcplugin.addDirectoryItem(addon_handle, url_item, li, True)
    xbmcplugin.endOfDirectory(addon_handle)

# --- LISTADO DE ENLACES DEL EVENTO ---

def list_event_links(links_json, event_title):
    try:
        links = json.loads(links_json)
        xbmcplugin.setContent(addon_handle,'videos')
        for link in links:
            display_name = f"[COLOR {COLOR_GREEN}]Ver en:[/COLOR] {link['name']}"
            url = build_url({'action':'play_channel','id':link['id']})
            li = xbmcgui.ListItem(label=display_name)
            li.setInfo('video', {'title': event_title})
            li.setProperty('IsPlayable','true')
            li.setArt({'icon':'DefaultVideo.png'})
            xbmcplugin.addDirectoryItem(addon_handle,url,li,False)
        xbmcplugin.endOfDirectory(addon_handle)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error list_event_links: {e}", xbmc.LOGERROR)

# --- REPRODUCCIÓN ---

def play_channel(ace_id):
    try:
        use_horus = ADDON.getSetting('use_external_player') == 'true'
        if use_horus:
            horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
            li = xbmcgui.ListItem(path=horus_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, li)
        else:
            strm_content = f"http://127.0.0.1:6878/ace/getstream?id={ace_id}"
            strm_path = xbmc.translatePath('special://temp/temp_acestream.strm')
            with open(strm_path,'w') as f:
                f.write(strm_content)
            xbmc.Player().play(strm_path)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error play_channel: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error","No se pudo reproducir el canal",xbmcgui.NOTIFICATION_ERROR)

# --- RUTEO PRINCIPAL ---

if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get('action')

    if action is None:
        list_agenda_events()
        
    elif action == 'list_channels':
        category = args.get('category')
        if category == 'AGENDA':
            list_agenda_events()
    elif action == 'list_event_links':
        links = args.get('links')
        title = args.get('title')
        list_event_links(links,title)
    elif action == 'play_channel':
        ace_id = args.get('id')
        play_channel(ace_id)
