import os, json, time

CACHE_FILE = os.path.join(xbmcaddon.Addon().getAddonInfo("profile"), "cache.json")
CACHE_TIME = 24 * 3600  # 24 horas en segundos

def scrapear_web_con_cache():
    # Si existe cache y no ha pasado 24h
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r") as f:
            data = json.load(f)
        if time.time() - data["timestamp"] < CACHE_TIME:
            return data["eventos"]

    # Sino scrapear web
    eventos = scrapear_web()
    
    # Guardar cache
    with open(CACHE_FILE, "w") as f:
        json.dump({"timestamp": time.time(), "eventos": eventos}, f)

    return eventos
