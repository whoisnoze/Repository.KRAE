import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import json
import re
from urllib.parse import urlencode, parse_qsl, quote

import requests
from bs4 import BeautifulSoup

# --- CONFIGURACIÓN GENERAL ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# --- ICONOS Y COLORES ---
ICON_AGENDA = xbmcaddon.Addon().getAddonInfo('path') + '/resources/agenda.png'
COLOR_TIME = "FF87CEEB"
COLOR_SPORT_CATEGORY = "FF32CD32"
COLOR_GREEN = "FF00FF00"
COLOR_YELLOW = "FFFFFF00"

# --- URLS DE LA AGENDA ---
AGENDA_URLS = [
    "https://eventos-eight-dun.vercel.app/"
]

# --- FUNCIONES DE UTILIDAD ---

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def clean_text(text):
    if not text: return ""
    return re.sub(r'\s+', ' ', text).strip()

def get_acestream_id(url):
    if url.startswith("acestream://"):
        return url.replace("acestream://", "")
    return url

# --- PARSEO DE LA AGENDA ---

def fetch_html(url):
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error fetch_html: {e}", xbmc.LOGERROR)
    return None

def parse_events(html):
    events = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        table = soup.find('table')
        if table:
            rows = table.find_all('tr')
            for row in rows:
                cols = row.find_all('td')
                if len(cols) < 6:
                    continue
                time = clean_text(cols[1].get_text())
                sport = clean_text(cols[2].get_text())
                competition = clean_text(cols[3].get_text())
                event_name = clean_text(cols[4].get_text())
                links_col = cols[5]

                links = []
                for link in links_col.find_all('a'):
                    href = link.get('href', '')
                    if 'acestream://' in href:
                        ace_id = get_acestream_id(href)
                        name = clean_text(link.get_text()).replace('▶','').strip()
                        links.append({'name': name, 'id': ace_id})

                if links:
                    title_display = f"[COLOR {COLOR_TIME}][{time}][/COLOR] [COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] {event_name} [I]({competition})[/I]"
                    events.append({'title': title_display, 'event_name': event_name, 'competition': competition, 'links': links})
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] Error parse_events: {e}", xbmc.LOGERROR)
    return events

# --- LISTADO DE LA AGENDA ---

def list_agenda_events():
    for url in AGENDA_URLS:
        html = fetch_html(url)
        if html:
            events = parse_events(html)
            if events:
                for item in events:
                    # Todos los enlaces del mismo evento se agrupan
                    links_json = json.dumps(item['links'])
                    url_item = build_url({
                        'action': 'list_event_links',
                        'links': links_json,
                        'title': item['event_name']
                    })
                    title_display = f"{item['title']} [COLOR {COLOR_YELLOW}]({len(item['links'])} Canales)[/COLOR]"
                    li = xbmcgui.ListItem(label=title_display)
                    li.setInfo('video', {
                        'title': item['event_name'],
                        'plot': f"{item['competition']} - Opciones: {len(item['links'])}"
                    })
                    li.setArt({'icon': 'DefaultFolder.png'})
                    xbmcplugin.addDirectoryItem(addon_handle, url_item, li, True)
                break
    xbmcplugin.endOfDirectory(addon_handle)

# --- RUTEO PRINCIPAL ---

if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get('action')

    if action is None:
        # Al abrir el addon, lista directamente todos los eventos
        list_agenda_events()
    elif action == 'list_event_links':
        links = args.get('links')
        title = args.get('title')
        # Podrías eliminar esta acción si ya no es necesaria
        pass
    elif action == 'play_channel':
        ace_id = args.get('id')
        horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
        li = xbmcgui.ListItem(path=horus_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, li)
