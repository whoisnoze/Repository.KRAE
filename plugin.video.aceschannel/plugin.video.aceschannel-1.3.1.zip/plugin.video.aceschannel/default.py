# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import json
import re
import base64
from urllib.parse import urlencode, parse_qsl, quote

import requests
from bs4 import BeautifulSoup

# --- CONFIGURACIÓN GENERAL ---
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# --- ICONOS Y COLORES ---
ICON_AGENDA = ADDON.getAddonInfo('path') + '/resources/agenda.png'
COLOR_TIME = "FF87CEEB"
COLOR_SPORT_CATEGORY = "FF32CD32"
COLOR_GREEN = "FF00FF00"
COLOR_YELLOW = "FFFFFF00"

# --- URLS DE LA AGENDA ---
AGENDA_URLS = [
    "https://eventos-eight-dun.vercel.app/"
]

# --- CANALES ESTÁTICOS ---
STATIC_CHANNELS = [
        {
        "name": "DAZN F1",
        "links": [
            "f696f5a5f67fa9ee46f20b84b25dc57a6eb40934",
            "2758678e899ccf67ca134a6443cac017bf815dd9",
            "b04372b9543d763bd2dbd2a1842d9723fd080076"
        ]
    },
    {
        "name": "DAZN 1",
        "links": [
            "a116ce3ff95c41c60e987e2b1aa247007f707884",
            "9afc89481b721ce6c326c85e47148676077b8e62",
            "7ba1f321f4d0791b7ebd42f41a07c1cd1479e784"
        ]
    },
    {
        "name": "Eurosport 1",
        "links": [
            "48a589dbeab3544662fafd79888aada7d834cfe9",
            "0db68ab752b50e6bb257eef22d102c1d29cd92ea"
        ]
    },
    {
        "name": "Eurosport 2",
        "links": [
            "5c910d614894635153a7d42de98cc2e4a958a53f",
            "24f940fef7e270b6b3ae5d9dc713a80c8345cfba",
            "f5908690485ae2facecf3074446ba4315f07a193"
        ]
    },
    {
        "name": "M+ Liga de Campeones",
        "links": [
            "91b2a1fe85f5bb4a6cf9ef6d01cc65883d986920",
            "97df5b7824948972d041d8ca2a4d29c90b641bc9",
            "9db029dff6a9c637d1f670e78dbc1a479b9b406e"
        ]
    },
    {
        "name": "M+ Liga de Campeones 2",
        "links": [
            "47188da7d2e4beaee82cff174f223fdd23f78fa6",
            "8156912ae14f6174a19c8a4efcf36a06e847f632",
            "74ab4e4ec7e2da001f473ca40893b7307b8029c5",
            "bb26037a253866d341778181eff5c8637240d615"
        ]
    },
    {
        "name": "M+ Liga de Campeones 3",
        "links": [
            "5b7f54b12e0f96ceba1299f44eac4b0f97403e4e",
            "cfc371890bfb502737a26de5215e50929c52d0f9",
            "320bee0fbdf2a168d47810236985a7c40b4f85c9",
            "4416843c96b7f7a1bc55c476091a60fff0922bc7"
        ]
    },
    {
        "name": "M+ Liga de Campeones 4",
        "links": [
            "5ba9368d80d2f87ac1c6d71df4e7e6e26e6911f2",
            "91ac4585368992720ec17ffa5b4389368c6dcac1",
            "e9f4493d2d851f4636720f639113e05b4a21a74c"
        ]
    },
    {
        "name": "Movistar Plus",
        "links": [
            "d23497596720b47b096ec0f850d6d26a19d1a336",
            "ed74406ccdb3c21941b919db6bffca7f1de015bb",
            "1ab443f5b4beb6d586f19e8b25b9f9646cf2ab78"
        ]
    },
    {
        "name": "M+ Deportes",
        "links": [
            "6e031aed136bf97d8667fcd5fc49c73256928281",
            "2f3cfd199a49819cbd129689a840dc3d23ab93aa",
            "ebca4a63ce3bfda7b272964a1acc5227218184a4"
        ]
    },
    {
        "name": "M+ Deportes 2",
        "links": [
            "6b15368775693c33c49fab02e7900c1976a5da90",
            "bfa01c11c5c6b7a616a516de4f2c769a89d26b25",
            "3774d8feab016ca766b35ea8488e7514ca30e0ee"
        ]
    },
    {
        "name": "Bein Sports TR",
        "links": [
            "229419659a062e80a088bb049137dafa9c9952fe",
            "1e3451ef86d34c96aabece2ac7bcae70ba9ed767",
            "e7ddca738693a902ce34fb80788b220676c15801"
        ]
    },
    {
        "name": "ESPN 2 MX",
        "links": [
            "e623929791ba2c5a45ea28a31954caff89147ebc",
            "9dfd7e896ad0ff817eb71e3096f0cfa11d43169b"
        ]
    }
]

# ---------------------------------------------------
# ---------------- FUNCIONES BASE -------------------
# ---------------------------------------------------

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

def clean_text(text):
    if not text:
        return ""
    return re.sub(r'\s+', ' ', text).strip()

def get_acestream_id(url):
    if url.startswith("acestream://"):
        return url.replace("acestream://", "")
    return url

# ---------------------------------------------------
# ------------------ MENÚ PRINCIPAL -----------------
# ---------------------------------------------------

def main_menu():
    # Eventos del día
    url_agenda = build_url({'action': 'list_agenda'})
    li_agenda = xbmcgui.ListItem(label="📅 Eventos del día")
    li_agenda.setArt({'icon': ICON_AGENDA})
    xbmcplugin.addDirectoryItem(addon_handle, url_agenda, li_agenda, True)

    # Channels
    url_channels = build_url({'action': 'list_channels'})
    li_channels = xbmcgui.ListItem(label="📺 Channels")
    li_channels.setArt({'icon': 'DefaultFolder.png'})
    xbmcplugin.addDirectoryItem(addon_handle, url_channels, li_channels, True)

    xbmcplugin.endOfDirectory(addon_handle)

# ---------------------------------------------------
# ----------------- SCRAPING AGENDA -----------------
# ---------------------------------------------------

def fetch_html(url):
    headers = {
        'User-Agent': 'Mozilla/5.0',
        'Accept-Language': 'es-ES,es;q=0.9'
    }
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] fetch_html error: {e}", xbmc.LOGERROR)
    return None

def parse_events(html):
    events = []
    try:
        soup = BeautifulSoup(html, 'html.parser')
        table = soup.find('table')

        if not table:
            return events

        rows = table.find_all('tr')

        for row in rows:
            cols = row.find_all('td')
            if len(cols) < 6:
                continue

            time = clean_text(cols[1].get_text())
            sport = clean_text(cols[2].get_text())
            competition = clean_text(cols[3].get_text())
            event_name = clean_text(cols[4].get_text())
            links_col = cols[5]

            links = []
            for link in links_col.find_all('a'):
                href = link.get('href', '')
                if 'acestream://' in href:
                    ace_id = get_acestream_id(href)
                    name = clean_text(link.get_text()).replace('▶', '').strip()
                    links.append({'name': name, 'id': ace_id})

            if links:
                title_display = (
                    f"[COLOR {COLOR_TIME}][{time}][/COLOR] "
                    f"[COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] "
                    f"{event_name} [I]({competition})[/I]"
                )

                events.append({
                    'title': title_display,
                    'event_name': event_name,
                    'competition': competition,
                    'links': links
                })

    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] parse_events error: {e}", xbmc.LOGERROR)

    return events

# ---------------------------------------------------
# --------------- LISTADO AGENDA --------------------
# ---------------------------------------------------

def list_agenda_events():
    xbmcplugin.setContent(addon_handle, 'videos')

    for url in AGENDA_URLS:
        html = fetch_html(url)
        if not html:
            continue

        events = parse_events(html)
        if not events:
            continue

        for item in events:
            links_json = json.dumps(item['links']).encode('utf-8')
            links_b64 = base64.urlsafe_b64encode(links_json).decode('utf-8')

            url_item = build_url({
                'action': 'list_event_links',
                'links': links_b64,
                'title': quote(item['event_name'])
            })

            title_display = (
                f"{item['title']} "
                f"[COLOR {COLOR_YELLOW}]({len(item['links'])} Canales)[/COLOR]"
            )

            li = xbmcgui.ListItem(label=title_display)
            li.setArt({'icon': 'DefaultFolder.png'})
            xbmcplugin.addDirectoryItem(addon_handle, url_item, li, True)

        xbmcplugin.endOfDirectory(addon_handle)
        return

    xbmcgui.Dialog().notification("Error", "No se pudieron cargar eventos", xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.endOfDirectory(addon_handle)

# ---------------------------------------------------
# ----------- LISTADO ENLACES EVENTO ----------------
# ---------------------------------------------------

def list_event_links(links_b64, event_title):
    try:
        links_json = base64.urlsafe_b64decode(links_b64.encode('utf-8')).decode('utf-8')
        links = json.loads(links_json)

        xbmcplugin.setContent(addon_handle, 'videos')

        for link in links:
            display_name = f"[COLOR {COLOR_GREEN}]Ver en:[/COLOR] {link['name']}"
            url = build_url({'action': 'play_channel', 'id': link['id']})

            li = xbmcgui.ListItem(label=display_name)
            li.setProperty('IsPlayable', 'true')
            li.setArt({'icon': 'DefaultVideo.png'})

            xbmcplugin.addDirectoryItem(addon_handle, url, li, False)

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] list_event_links error: {e}", xbmc.LOGERROR)

# ---------------------------------------------------
# --------------- CANALES ESTÁTICOS -----------------
# ---------------------------------------------------

def list_static_channels():
    xbmcplugin.setContent(addon_handle, 'videos')

    for channel in STATIC_CHANNELS:
        # Codificamos los enlaces en base64
        links_json = json.dumps([{"name": f"Enlace {i+1}", "id": link} for i, link in enumerate(channel['links'])]).encode('utf-8')
        links_b64 = base64.urlsafe_b64encode(links_json).decode('utf-8')

        url_item = build_url({
            'action': 'list_event_links',
            'links': links_b64,
            'title': quote(channel['name'])
        })

        li = xbmcgui.ListItem(label=channel['name'])
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(addon_handle, url_item, li, True)

    xbmcplugin.endOfDirectory(addon_handle)

# ---------------------------------------------------
# ----------------- REPRODUCCIÓN --------------------
# ---------------------------------------------------

def play_channel(ace_id):
    try:
        horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
        li = xbmcgui.ListItem(path=horus_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, li)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] play_channel error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", "No se pudo reproducir", xbmcgui.NOTIFICATION_ERROR)

# ---------------------------------------------------
# -------------------- ROUTER -----------------------
# ---------------------------------------------------

if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get('action')

    if action is None:
        main_menu()

    elif action == 'list_agenda':
        list_agenda_events()

    elif action == 'list_event_links':
        list_event_links(args.get('links'), args.get('title'))

    elif action == 'list_channels':
        list_static_channels()

    elif action == 'play_channel':
        play_channel(args.get('id'))
