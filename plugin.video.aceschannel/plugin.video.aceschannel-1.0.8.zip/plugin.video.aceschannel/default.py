import sys
import urllib.request
import re
import xbmcgui
import xbmcplugin
import urllib.parse

addon_handle = int(sys.argv[1])

def scrapear_web():
    url = "https://eventos-eight-dun.vercel.app/"
    req = urllib.request.Request(
        url,
        headers={'User-Agent': 'Mozilla/5.0'}
    )
    html = urllib.request.urlopen(req).read().decode("utf-8")

    eventos = []

    filas = re.findall(r'<tr.*?>(.*?)</tr>', html, re.DOTALL)

    for fila in filas:
        columnas = re.findall(r'<td.*?>(.*?)</td>', fila, re.DOTALL)
        if len(columnas) < 5:
            continue

        hora = re.sub('<.*?>', '', columnas[1]).strip()
        deporte = re.sub('<.*?>', '', columnas[2]).strip()
        partido = re.sub('<.*?>', '', columnas[4]).strip()

        enlaces = re.findall(r'acestream://([A-Za-z0-9]+)', fila)

        canales = []
        for hash_id in enlaces:
            canales.append({
                "nombre": f"Canal {hash_id[:6]}",
                "hash": hash_id
            })

        if canales:
            eventos.append({
                "titulo": f"{hora} - {partido} ({deporte})",
                "canales": canales
            })

    return eventos

def listar_eventos():
    eventos = scrapear_web()
    for idx, evento in enumerate(eventos):
        url_evento = f"{sys.argv[0]}?action=canales&evento={idx}"
        li = xbmcgui.ListItem(label=evento["titulo"])
        xbmcplugin.addDirectoryItem(addon_handle, url_evento, li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def listar_canales(evento_idx):
    eventos = scrapear_web()
    evento = eventos[int(evento_idx)]

    for canal in evento["canales"]:
        stream_url = f"http://127.0.0.1:6878/ace/getstream?id={canal['hash']}"
        li = xbmcgui.ListItem(label=canal["nombre"])
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(addon_handle, stream_url, li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

# Router seguro
if len(sys.argv) > 2 and sys.argv[2]:
    args = urllib.parse.parse_qs(sys.argv[2][1:])
else:
    args = {}

action = args.get("action", [None])[0]

if action == "canales":
    listar_canales(args.get("evento", [0])[0])
else:
    listar_eventos()
