from bs4 import BeautifulSoup

def fetch_and_parse_events():
    """
    Recorre todas las URLs de AGENDA y devuelve lista de eventos con enlaces.
    """
    for url in AGENDA_URLS:
        if not url: continue
        html = fetch_html_content(url)
        if not html: continue

        try:
            soup = BeautifulSoup(html, 'html.parser')
            table = soup.find('table')
            if not table: continue

            events = []
            for row in table.find_all('tr'):
                cols = row.find_all('td')
                if len(cols) < 6: continue

                time = clean_text(cols[1].get_text())
                sport = clean_text(cols[2].get_text())
                competition = clean_text(cols[3].get_text())
                event_name = clean_text(cols[4].get_text())
                links_col = cols[5]

                links = []
                for link in links_col.find_all('a'):
                    href = link.get('href', '')
                    if 'acestream://' in href:
                        ace_id = get_acestream_id(href)
                        name = clean_text(link.get_text()).replace('▶','').strip()
                        links.append({'name': name, 'id': ace_id})

                if links:
                    events.append({
                        'title': f"[COLOR {COLOR_TIME}][{time}][/COLOR] [COLOR {COLOR_SPORT_CATEGORY}][{sport}][/COLOR] {event_name} [I]({competition})[/I]",
                        'event_name': event_name,
                        'competition': competition,
                        'links': links
                    })
            if events:
                return events
        except Exception as e:
            xbmc.log(f"[{ADDON_NAME}] Error parsing HTML: {e}", xbmc.LOGERROR)
    return []

def list_agenda_events():
    events = fetch_and_parse_events()
    if not events:
        xbmcgui.Dialog().notification("Error", "No se pudo obtener la agenda", xbmcgui.NOTIFICATION_ERROR)
        return

    for item in events:
        if len(item['links']) == 1:
            li = xbmcgui.ListItem(label=item['title'])
            li.setInfo('video', {'title': item['event_name'], 'plot': item['competition'], 'mediatype':'video'})
            li.setProperty('IsPlayable','true')
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'action':'play_channel','id':item['links'][0]['id']}),
                                        listitem=li,isFolder=False)
        else:
            li = xbmcgui.ListItem(label=f"{item['title']} [COLOR {COLOR_YELLOW}]({len(item['links'])} Canales)[/COLOR]")
            xbmcplugin.addDirectoryItem(handle=addon_handle,
                                        url=build_url({'action':'list_event_links','links':json.dumps(item['links']),
                                                       'title': item['event_name']}),
                                        listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def play_channel(ace_id):
    try:
        horus_url = f"plugin://script.module.horus/?action=play&id={ace_id}"
        li = xbmcgui.ListItem(path=horus_url)
        xbmcplugin.setResolvedUrl(addon_handle, True, li)
    except Exception as e:
        xbmc.log(f"[{ADDON_NAME}] ERROR reproduciendo AceStream: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Error", f"No se pudo reproducir {ace_id}", xbmcgui.NOTIFICATION_ERROR)
